using UnityEngine;
using System.Collections;

public class MagneticCollider : MonoBehaviour {

	public Transform kiwiTransform;
    Coin coinScript;

    Transform myTransform;
    public SphereCollider sphereCollider;
    public GameObject magneticColliderImage;

	void Start () 
    {
        this.transform.parent = null;
        myTransform = transform;

        float scale = (GameVariables.boosterMagnetRadius / 320.0f) * 3.6f;
        transform.localScale = new Vector3(scale, scale, scale);
        gameObject.active = false;
        if(magneticColliderImage)
            magneticColliderImage.active = false;
	
	}

    void FixedUpdate()
    {
        transform.position = kiwiTransform.position;
    }

    void OnTriggerEnter(Collider other)
    {
        print(other.name);
        if (other.tag == "Coin" || other.tag == "Super Coin" || other.tag == "Upper Coin")
        {           
            coinScript = other.GetComponent<Coin>();
           
            coinScript.enabled = true;
            coinScript.EnableLerp();
        }
    }
}
