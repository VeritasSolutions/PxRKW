using UnityEngine;
using System.Collections;
using System.IO;

public class Game : MonoBehaviour
{   

    public enum GameMode
    {
        Story,
        Challenging

    };

    public static GameMode gameMode = GameMode.Story;

    public enum GameState
    {
        None,
        Start,
        Playing,
        Pause,
        GameOver,
        Finish,
        
    };

    

    public static int currentLoadedLevelForStats = 0;

    public static Rockets currentlyEquippedRocket = Rockets.Rocket1;    
    
    public static bool goToTouchPosition = true;

    public static int currentlyEquippedRocketIndex = 0;

    public static int level1BuildSettingIndex = 2;

    public static int levelOffset = 1;

    public static GameState gameState;

    public static int currentZoneIndex = -1;

    public static int currentZonelevelIndex = -1;

    public static int numberOfZoneUnlocked = 1;

    public static int totalNumberOfCoinsCollected = 0;
    public static int totalNumberOfFeathersCollected = 0;

    public static int []numberOfExploredLevels = {1, 1 , 1, 1, 1, 1 };

    public static int[] distanceToCompleteZone =      { 5000,   5000,   5000,   -1,
                                                        5000,   5000,   5000,   -1,
                                                        5000,   5000,   5000,   -1,
                                                        5000,   5000,   5000,   -1,
                                                        5000,   5000,   5000,   -1,
                                                        5000,   5000,   5000,   -1,
                                                       };

    public static int totalNumberOfZones = 6;

    public static int numberOfLevelsInEachZone = 3;
    
    public static int[] levelsBestScore;

    public static int[] isFeatherRewarded;
   


    public static void Reset()
    {
        Game.numberOfZoneUnlocked = 1;
        Game.numberOfExploredLevels[0] = 1;
        Game.numberOfExploredLevels[1] = 1;
        Game.numberOfExploredLevels[2] = 1;
        Game.numberOfExploredLevels[3] = 1;
        Game.numberOfExploredLevels[4] = 1;
        Game.numberOfExploredLevels[5] = 1;

        isFeatherRewarded = new int[totalNumberOfZones * (numberOfLevelsInEachZone + 1)];

        levelsBestScore = new int[totalNumberOfZones * (numberOfLevelsInEachZone + 1)];
        SaveGameSettings();
    }

    internal static void LoadGameSettings()
    {
        totalNumberOfCoinsCollected = PlayerPrefs.GetInt("Total Coins Collected", totalNumberOfCoinsCollected);
        totalNumberOfFeathersCollected = PlayerPrefs.GetInt("Total Feathers Collected", totalNumberOfCoinsCollected); 
        numberOfZoneUnlocked = PlayerPrefs.GetInt("Number Of Zones Unlocked", numberOfZoneUnlocked);       
        levelsBestScore = PlayerPrefsX.GetIntArray("Level Best Scores", 0, totalNumberOfZones * (numberOfLevelsInEachZone + 1));
        isFeatherRewarded = PlayerPrefsX.GetIntArray("Is Feather Rewarded", 0, totalNumberOfZones * (numberOfLevelsInEachZone + 1));
        numberOfExploredLevels = PlayerPrefsX.GetIntArray("Explored Levels",1 ,4);       
    }

    internal static void SaveGameSettings()
    {
        PlayerPrefs.SetInt("Total Coins Collected", totalNumberOfCoinsCollected);
        PlayerPrefs.SetInt("Total Feathers Collected", totalNumberOfFeathersCollected);
        PlayerPrefs.SetInt("Number Of Zones Unlocked", numberOfZoneUnlocked);
        PlayerPrefsX.SetIntArray("Level Best Scores", levelsBestScore);
        PlayerPrefsX.SetIntArray("Is Feather Rewarded", isFeatherRewarded);
        PlayerPrefsX.SetIntArray("Explored Levels", numberOfExploredLevels);
    }

    public static float soundEffectVolume = 1f;
    public static float musicVolume = 1f;
    public static bool isMusicOn = true;
    public static bool isSoundOn = true;

    internal static void SetSoundSettings()
    {
        AudioSource[] sources = (AudioSource[])FindObjectsOfType(typeof(AudioSource));
        for (int i = 0; i < sources.Length; i++)
        {
            if (!sources[i].clip)
                continue;
            sources[i].volume = soundEffectVolume;
        }


    }

    public static AudioSource currentPlayingMusic = null;   


   
}
