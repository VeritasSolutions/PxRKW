using UnityEngine;
using System.Collections;

public class LevelStats : MonoBehaviour 
{
    public static bool rewardFeather = false;

    public static int currentLevelBestTime=0;
    public static int currentLevelHighScore=0;



    public static float distanceTravelled = 0;
 //   public static float distanceTravelledScore = 0;
 //   public static float otherScore = 0;
    public static int numberOfCoinsCollected = 0;
    public static int numberOfFuelsCollected = 0;

    public static int currentScore = 0;
    public static int timePassed = 0;

    public static bool levelComplete = false;



    void Start()  //set all the values to zero as game starts
    {
        
        levelComplete = false;
        distanceTravelled = 0;
   //     distanceTravelledScore = 0;
   //     otherScore = 0;
        numberOfCoinsCollected = 0;
        numberOfFuelsCollected = 0;
        currentScore = 0;
        timePassed = 0;
        
    }



	
}
