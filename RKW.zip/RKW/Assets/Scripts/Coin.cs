using UnityEngine;
using System.Collections;

public class Coin : MonoBehaviour 
{
    static Transform kiwiTransform;
    Transform myTransform;

    float speed = 10;

    internal bool lerp = false;

    public bool isUpperCoin = false;
    Vector3 initialPosition;

    internal void Disable()
    {       
        if (isUpperCoin)
        {
            transform.localPosition = initialPosition;
            gameObject.active = false;
        }
    }

	
	void Start () 
    {
        initialPosition = transform.localPosition;

        if (kiwiTransform == null)
        {
            kiwiTransform = GameObject.Find("Kiwi").transform;
            kiwiTransform = kiwiTransform.FindChild("Kiwi Image").transform;
        }

        if (isUpperCoin)
            speed = GameVariables.upperCoinLerpSpeed;
        else
            speed = GameVariables.lowerCoinLerpSpeed;


        myTransform = transform;

        this.enabled = false;
	}




    void FixedUpdate()
    {
        if (!lerp)
            return;

        if (isUpperCoin)
        {
            if (CameraZoom.isCameraInOriginalState)
                return;
        }

        myTransform.position = Vector3.Lerp(myTransform.position, kiwiTransform.position, speed * Time.deltaTime);




    }

    internal void EnableLerp()
    {
        if (!isUpperCoin)
        {
            transform.parent = kiwiTransform;
        }
       
        lerp = true;
    }

}
