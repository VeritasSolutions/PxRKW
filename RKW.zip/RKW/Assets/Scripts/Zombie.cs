using UnityEngine;
using System.Collections;

public class Zombie : MonoBehaviour {

    public PackedSprite myPackedSprite;

	void Start () 
    {
        InvokeRepeating("PlayRandomAnimation", 2, 4);
	
	}
    int i = 0;

    void PlayRandomAnimation()
    {
        if (i > 2)
            i = 0;

        myPackedSprite.PlayAnim(i);

        if (i == 2)
            myPackedSprite.winding = SpriteRoot.WINDING_ORDER.CCW;

        i++;
    }
	
	
}
