using UnityEngine;
using System.Collections;


public enum Rockets
{
    Rocket1,
    Rocket2,
    Rocket3,
    Rocket4,
    Rocket5,
    Rocket6,
    Rocket7
};

public class Rocket : MonoBehaviour 
{

    public Kiwi kiwiScript;
    GameObject jetFlame;
    ParticleEmitter smallParticles;
    ParticleEmitter bigParticles;


    public GameObject[] rockets;

    public static int currentRocketIndex = 0;


    public static float[] agility =     {1f,    1.3f,   1.1f,   .75f,   1.1f,   1.2f    };
    public static float[] capacity =    {1000,   80,     120,    180 ,   140,    150     };


    void Start()
    {
        for (int i = 0; i < rockets.Length; i++)
        {
            if (i == currentRocketIndex)
            {
                rockets[i].transform.FindChild("Jet").gameObject.active = true;
                jetFlame = rockets[i].transform.FindChild("Jet Flame").gameObject;
                smallParticles = rockets[i].transform.FindChild("Smoke Trail Small").GetComponent<ParticleEmitter>();
                bigParticles = rockets[i].transform.FindChild("Smoke Trail Big").GetComponent<ParticleEmitter>();

                continue;
            }

            Destroy(rockets[i]);
        }

        jetFlame.active = false;
        bigParticles.gameObject.active = true;
        smallParticles.gameObject.active = true;
        bigParticles.emit = false;
        smallParticles.emit = true;

        kiwiScript.jetFlame = jetFlame;
        kiwiScript.bigParticles = bigParticles;
        kiwiScript.smallParticles = smallParticles;

        kiwiScript.StartCheckingJetPackParticles();
    }
	
}
