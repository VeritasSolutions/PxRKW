using UnityEngine;
using System.Collections;

public class GameVariables : MonoBehaviour 
{

    //scoring stats
    public static int scorePerMeterTravelled = 20;

    public static int scorePerSmallCoinCollected = 5;
    public static int scorePerSuperCoinCollected = 25;    
    public static int scorePerFuelCollected = 20;

    public static int scorePerBoosterUsed = 100;

    public static int numberOfCoinsPerSuperCoin = 5;
    public static int amountOfFuelInFuelPack = 10;

    public static float belowSkyAirCurrentDuration = 6f;



    //Booster CoolDown

    public static float boosterSpeedDuration = 50;
    public static float boosterMagnetDuration = 25;
    public static float boosterSheildDuration = 35;

    public static float additionalSpeedBoosterSpeed = 7;

    public static float boosterMagnetRadius = 10;

    public static int basicFuelConsumptionRate = 5;  //5 unit per second



    public static float rocket1Acceleration = 10;


    //coin Lerp Speed
    public static float upperCoinLerpSpeed = 20f;
    public static float lowerCoinLerpSpeed = 10;



    //Rewards

    public static int[] featherRewards = { 1, 2, 3, 4, 5, 6 };



    //Environment Speed

    public static float []zonesGroundSpeed          =   { 1, 1, 1, 1, 1, 1 };
    public static float []zonesFrontMountainSpeed   =   { 1, 1, 1, 1, 1, 1 };
    public static float []zonesBackMountainSpeed    =   { 1, 1 ,1, 1, 1, 1 };
    public static float []zonesCloudSpeed           =   { 1, 1, 1, 1, 1, 1 };
    public static float []zonesAtmosphereSpeed      =   { 1, 1, 1, 1, 1, 1 };
    


	
}
