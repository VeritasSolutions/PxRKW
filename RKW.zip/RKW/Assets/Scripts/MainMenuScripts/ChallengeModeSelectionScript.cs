using UnityEngine;
using System.Collections;

public class ChallengeModeSelectionScript : MonoBehaviour {

    public Transform mainMenuCameraPosition;
    

    GameObject GUICamera;

    UIController uiController;
    

    public GameObject[] buttonContainers;

    UIButton[] levelButtons;
    TextMesh[] levelTexts;
    TextMesh[] highScoreTexts;

    void Start()
    {
        uiController = GameObject.Find("UIController").GetComponent<UIController>();
        GUICamera = GameObject.Find("GUICamera");

        levelButtons = new UIButton[buttonContainers.Length];
        levelTexts = new TextMesh[buttonContainers.Length];
        highScoreTexts = new TextMesh[buttonContainers.Length];

        for (int i = 0; i < buttonContainers.Length; i++)
        {
            levelButtons[i] = buttonContainers[i].GetComponentInChildren<UIButton>();
            levelTexts[i] = buttonContainers[i].transform.FindChild("Text").GetComponent<TextMesh>();
            highScoreTexts[i] = buttonContainers[i].transform.FindChild("High Score Text").GetComponent<TextMesh>();
        }

    }

    internal void PrepareZones()
    {
        int numberOfChallengingZonesUnlocked = 0;

        if (Game.numberOfZoneUnlocked == Game.totalNumberOfZones)
        {
            if (Game.numberOfExploredLevels[Game.totalNumberOfZones - 1] == Game.numberOfLevelsInEachZone)
                numberOfChallengingZonesUnlocked = Game.numberOfZoneUnlocked;
            else
                numberOfChallengingZonesUnlocked = Game.numberOfZoneUnlocked - 1;
        }
        else
        {
            numberOfChallengingZonesUnlocked = Game.numberOfZoneUnlocked - 1;
        }

        int i = 0;
        for (; i < numberOfChallengingZonesUnlocked; i++)
        {
            levelButtons[i].SetControlState(UIButton.CONTROL_STATE.NORMAL);
            levelTexts[i].gameObject.active = true;
            highScoreTexts[i].text = "High Score : " + Game.levelsBestScore[(i * (Game.numberOfLevelsInEachZone + 1) + 3)].ToString();
        }
        for (; i < buttonContainers.Length; i++)
        {
            levelButtons[i].SetControlState(UIButton.CONTROL_STATE.DISABLED);
            levelTexts[i].gameObject.active = false;
            highScoreTexts[i].text = "High Score : 0";
        }

    }

    void BackButtonClicked()
    {

        uiController.FadeInFader();

        Invoke("BackClicked", uiController.timeDelayBetweenCameraMovement);
    }

    void BackClicked()
    {
        Vector3 newCameraPosition;

        newCameraPosition = new Vector3(mainMenuCameraPosition.position.x, mainMenuCameraPosition.position.y, GUICamera.transform.position.z);

        GUICamera.transform.position = newCameraPosition;
    }

    int levelToLoad = 0;
    int clickedZoneIndex = 0;

    void Zone1ButtonClicked()
    {
        Game.currentZoneIndex = 0;
        ZoneClicked();
    }

    void Zone2ButtonClicked()
    {
        Game.currentZoneIndex = 1;
        ZoneClicked();
    }

    void Zone3ButtonClicked()
    {
        Game.currentZoneIndex = 2;
        ZoneClicked();
    }

    void Zone4ButtonClicked()
    {
        Game.currentZoneIndex = 3;
        ZoneClicked();
    }

    void Zone5ButtonClicked()
    {
        Game.currentZoneIndex = 4;
        ZoneClicked();
    }

    void Zone6ButtonClicked()
    {
        Game.currentZoneIndex = 5;
        ZoneClicked();
    }

    void ZoneClicked()
    {
        Game.currentZonelevelIndex = 3;

        levelToLoad = Game.currentZoneIndex * (Game.numberOfLevelsInEachZone + 1) + Game.currentZonelevelIndex + Game.level1BuildSettingIndex;

        Game.currentLoadedLevelForStats = levelToLoad - Game.level1BuildSettingIndex;

        uiController.JustFadeInFader();

        Invoke("LoadLevel", uiController.timeDelayBetweenCameraMovement);

    }

    void LoadLevel()
    {
        Application.LoadLevel(levelToLoad);
    }
}
