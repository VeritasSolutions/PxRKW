using UnityEngine;
using System.Collections;

public class ScrollerZoom : MonoBehaviour 
{

    public Transform []buttonsTransform;
    Vector3 centerPositon = Vector3.zero;

    int numberOfObjects;

    public float maxBoxSize = 1.2f;
    public float minBoxSize = .8f;

    void Start()
    {
        numberOfObjects = buttonsTransform.Length;
        centerPositon = transform.parent.position;

        if (numberOfObjects == 0)
            this.enabled = false;
    }
	
	void Update () 
    {
        for (int i = 0; i < numberOfObjects; i++)
            {
                float distance = Mathf.Abs(buttonsTransform[i].position.x - centerPositon.x);
                float scale = 0;

                scale = maxBoxSize - distance / 8f;


                if (scale > minBoxSize)
                {
                    buttonsTransform[i].localScale = new Vector3(scale, scale, .1f);
                }
                else
                    buttonsTransform[i].localScale = new Vector3(minBoxSize, minBoxSize, .1f);

            }
       
	
	}
}
