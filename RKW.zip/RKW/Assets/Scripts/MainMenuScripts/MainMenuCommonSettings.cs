using UnityEngine;
using System.Collections;

public class MainMenuCommonSettings : MonoBehaviour {

    AudioSource mainMenuMusic;
    public AudioSource startingMusic;
    public GameObject mainMenuMusicPrefab;
    public static bool isStarting = true;

    bool isGameCenterAvailable = false;

    UIController uiController;


    public void Awake()
    {
#if UNITY_IPHONE
                iPhoneKeyboard.autorotateToLandscapeLeft = false;
                iPhoneKeyboard.autorotateToLandscapeRight = false;
                iPhoneKeyboard.autorotateToPortrait = false;
                iPhoneKeyboard.autorotateToPortraitUpsideDown = false;
                ((UIManager)(GameObject.Find("UIManager").GetComponent("UIManager"))).pointerType = UIManager.POINTER_TYPE.TOUCHPAD;
                ((UIManager)(GameObject.Find("UIManager").GetComponent("UIManager"))).autoRotateKeyboardLandscapeLeft = false;
				((UIManager)(GameObject.Find("UIManager").GetComponent("UIManager"))).autoRotateKeyboardLandscapeRight =false;
		        ((UIManager)(GameObject.Find("UIManager").GetComponent("UIManager"))).autoRotateKeyboardPortrait = false;
		        ((UIManager)(GameObject.Find("UIManager").GetComponent("UIManager"))).autoRotateKeyboardPortraitUpsideDown = false;
				iPhoneSettings.screenCanDarken = false;
                Input.multiTouchEnabled = false;                
 
#endif

         
    }

    

    void CheckGameCenterAvailability()
    {
        if (!isGameCenterAvailable)
            return;

        if (GameCenterBinding.isGameCenterAvailable())
            GameCenterBinding.authenticateLocalPlayer();

    }

    void Start()
    {
        uiController = GameObject.Find("UIController").GetComponent<UIController>();
        Invoke("CheckGameCenterAvailability", 1f);
        mainMenuMusic = GameObject.FindGameObjectWithTag("Music").GetComponent<AudioSource>();
        SetInitialSoundSettings();
        isStarting = false;

    }

   

    void SetInitialSoundSettings()
    {
        Game.SetSoundSettings();

        if (!Game.isSoundOn)
        {
            soundText.text = "SOUND  OFF";
            soundButton.SetState(1);

        }

        if (Game.isMusicOn)
        {
            musicButton.SetState(0);

            mainMenuMusic.volume = Game.musicVolume;

        }
        else
        {
            musicText.text = "MUSIC  OFF";
            musicButton.SetState(1);
            mainMenuMusic.volume = 0;
        }
    }

    public TextMesh soundText;
    public TextMesh musicText;
    public UIStateToggleBtn soundButton;
    public UIStateToggleBtn musicButton;

    void MusicONOFFButtonClicked()
    {
        if (Game.isMusicOn)
        {
            musicButton.SetState(1);
            Game.isMusicOn = false;
            musicText.text = "MUSIC  OFF";
        }
        else
        {
            musicButton.SetState(0);
            Game.isMusicOn = true;
            musicText.text = "MUSIC   ON";
        }

        if (Game.isMusicOn)
            mainMenuMusic.volume = Game.musicVolume;
        else
            mainMenuMusic.volume = 0;
    }

    void SoundONOFFButtonClicked()
    {
        if (Game.isSoundOn)
        {
            soundButton.SetState(1);
            Game.isSoundOn = false;
            Game.soundEffectVolume = 0;
            soundText.text = "SOUND  OFF";
        }
        else
        {
            soundButton.SetState(0);
            Game.isSoundOn = true;
            Game.soundEffectVolume = 1;
            soundText.text = "SOUND   ON";
        }
        Game.SetSoundSettings();

        if (Game.isMusicOn)
        {
            mainMenuMusic.volume = Game.musicVolume;
        }
        else
            mainMenuMusic.volume = 0;
    }

    public UIPanel settingsPanel;

    

    void SettingsBackClicked()
    {
        settingsPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
    }

    void LeaderBoardButtonClicked()
    {

        if (GameCenterBinding.isPlayerAuthenticated())
        {
            UpdateLeaderBoard();
            GameCenterBinding.showLeaderboardWithTimeScope(GameCenterLeaderboardTimeScope.AllTime);
        }

    }

    private void UpdateLeaderBoard()
    {
        int totalScore = 0;

        for (int i = 0; i < Game.levelsBestScore.Length; i++)
        {
            totalScore = totalScore + Game.levelsBestScore[i];
        }

       // GameCenterBinding.reportScore(Game.highScore, Variables.leaderboardIdentifier);
    }
}
