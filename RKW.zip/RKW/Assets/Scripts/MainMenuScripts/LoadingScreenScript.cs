using UnityEngine;
using System.Collections;

public class LoadingScreenScript : MonoBehaviour 
{
    public GameObject fader;

    void Awake()
    {
        fader.active = false;
        
    }

    IEnumerator Start()
    {
        AsyncOperation async = Application.LoadLevelAsync(1);
        yield return async;
        Debug.Log("Loading complete");
    }
}
