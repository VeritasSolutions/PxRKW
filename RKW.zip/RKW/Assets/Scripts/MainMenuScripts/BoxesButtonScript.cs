using UnityEngine;
using System.Collections;

public class BoxesButtonScript : MonoBehaviour {

    ScrollablePanel scrollablepanelScript;

	
	void Start () 
    {
        scrollablepanelScript = transform.parent.parent.GetComponent<ScrollablePanel>();
	
	}

    void Update()
    {
        foreach (Touch evt in Input.touches)
        {
            if (evt.phase == TouchPhase.Moved)
                OnMouseDrag();
            else if (evt.phase == TouchPhase.Ended)
                OnMouseUp();

        }

    }

    Vector3 touchInitiatedPos;
    Vector3 touchEndedPos;
    float dragThresold = 10f;


    void OnMouseDown()
    {
        
        touchInitiatedPos = Input.mousePosition;
        scrollablepanelScript.OnMouseDown();
    }

    void OnMouseDrag()
    {
        touchEndedPos = Input.mousePosition;
        float distanceMoved = Mathf.Abs(touchInitiatedPos.x - touchEndedPos.x);
//        print(distanceMoved);
        if (distanceMoved < dragThresold)
            return;

        scrollablepanelScript.OnMouseDrag();
    }

    void OnMouseUp()
    {
        touchEndedPos = Input.mousePosition;
        if (Mathf.Abs(touchInitiatedPos.x - touchEndedPos.x) < dragThresold)
            return;

        scrollablepanelScript.OnMouseUp();
    }
}
