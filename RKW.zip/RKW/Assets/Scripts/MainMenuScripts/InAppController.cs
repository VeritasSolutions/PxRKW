using UnityEngine;
using System.Collections;

public class InAppController : MonoBehaviour 
{
    public static string unlockAllBoardsInAppIdentifier = "com.sunstorm.snowboarding.unlockAllBoards";
    public static string coinPack1InAppIdentifier = "com.sunstorm.snowboarding.coinpack1";
    public static string coinPack2InAppIdentifier = "com.sunstorm.snowboarding.coinpack2";
    public static string coinPack3InAppIdentifier = "com.sunstorm.snowboarding.coinpack3";


    public enum InAppsType
    {
        None,
        UnlockAllBoards,
        CoinPack1,
        CoinPack2,
        CoinPack3
    };

    public static InAppsType currentInAppType = InAppsType.None;

   // string currentProcessingInapp = "none";

    public GameObject processingIcon;

    UIController uiController;

   


	void Start () 
    {
        InAppsType currentInAppType = InAppsType.None;
        uiController=GameObject.Find("UIController").GetComponent<UIController>();
	
	}

    void FixedUpdate()
    {
        if (currentInAppType == InAppsType.None)
            return;

        if (StoreKitEventListener.isPurchased)
        {
            if (currentInAppType == InAppsType.CoinPack1)
            {
                Game.totalNumberOfCoinsCollected += 1000;                
            }
            else if (currentInAppType == InAppsType.CoinPack2)
            {
                Game.totalNumberOfCoinsCollected += 5000;
            }
            else if (currentInAppType == InAppsType.CoinPack3)
            {
                Game.totalNumberOfCoinsCollected += 10000;
            }
            else if (currentInAppType == InAppsType.UnlockAllBoards)
            {
               // Game.numberOfBoardUnlocked = 6;
               // boardSelectionScript.PrepareButtons();
            }

            Game.SaveGameSettings();

          //  uiController.UpdateTotalNumberOfCoins();


            currentInAppType = InAppsType.None;
            uiController.FadeOutFader();
            processingIcon.active = false;

            StoreKitEventListener.isPurchased = false;
        }

        if (StoreKitEventListener.purchaseUnderProcess == false)
        {
            print("Unsuccessful");
            currentInAppType = InAppsType.None;
            processingIcon.active = false;
            uiController.FadeOutFader();
        }

    }

    public void BuyCoinPack1Clicked()
    {
        if (StoreKitEventListener.purchaseUnderProcess)
            return;

        currentInAppType = InAppsType.CoinPack1;

        uiController.FadeInFader();

        processingIcon.active = true;
        StoreKitEventListener.purchaseUnderProcess = true;
        StoreKitBinding.purchaseProduct(coinPack1InAppIdentifier, 1);
    }

    public void BuyCoinPack2Clicked()
    {
        if (StoreKitEventListener.purchaseUnderProcess)
            return;

        currentInAppType = InAppsType.CoinPack2;

        uiController.FadeInFader();

        processingIcon.active = true;
        StoreKitEventListener.purchaseUnderProcess = true;
        StoreKitBinding.purchaseProduct(coinPack2InAppIdentifier, 1);
    }

    public void BuyCoinPack3Clicked()
    {
        if (StoreKitEventListener.purchaseUnderProcess)
            return;

        currentInAppType = InAppsType.CoinPack3;

        uiController.FadeInFader();

        processingIcon.active = true;
        StoreKitEventListener.purchaseUnderProcess = true;
        StoreKitBinding.purchaseProduct(coinPack3InAppIdentifier, 1);
    }

    public void UnlockAllBoardButtonClicked()
    {
        if (StoreKitEventListener.purchaseUnderProcess)
            return;

        currentInAppType = InAppsType.UnlockAllBoards;

        uiController.FadeInFader();

        processingIcon.active = true;
        StoreKitEventListener.purchaseUnderProcess = true;
        StoreKitBinding.purchaseProduct(unlockAllBoardsInAppIdentifier, 1);
    }
}
