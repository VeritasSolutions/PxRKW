using UnityEngine;
using System.Collections;

public class StoryModeZoneSelectionScript : MonoBehaviour {

    GameObject GUICamera;

    public Transform zoneSelectionCameraPosition;
    public Transform zoneSelectionCameraPosition2;
    public StoryModeLevelSelectionScript levelSelectionScript;

    public Transform levelSelectionCameraPosition;

    UIController uiController;

    public GameObject[] buttonContainers;

    UIButton[] zoneButtons;
    TextMesh[] zoneTexts;

    public GameObject backButton;

    Vector3 backButtonInitialPosition;

	void Start () 
    {
        backButtonInitialPosition = backButton.transform.position;

        uiController = GameObject.Find("UIController").GetComponent<UIController>();
        GUICamera = GameObject.Find("GUICamera");

        zoneButtons = new UIButton[buttonContainers.Length];
        zoneTexts = new TextMesh[buttonContainers.Length];

        for (int i = 0; i < buttonContainers.Length; i++)
        {
            zoneButtons[i] = buttonContainers[i].GetComponentInChildren<UIButton>();
            zoneTexts[i] = buttonContainers[i].GetComponentInChildren<TextMesh>();
        }
	
	}

    internal void PrepareZones()
    {
        int i = 0;
        for (; i < Game.numberOfZoneUnlocked; i++)
        {
            zoneButtons[i].SetControlState(UIButton.CONTROL_STATE.NORMAL);
            zoneTexts[i].gameObject.active = true;
        }
        for (; i < buttonContainers.Length; i++)
        {
            zoneButtons[i].SetControlState(UIButton.CONTROL_STATE.DISABLED);
            zoneTexts[i].gameObject.active = false;
        }
    }

    void BackButtonClicked()
    {
        uiController.FadeInFader();

        Invoke("BackClicked", uiController.timeDelayBetweenCameraMovement);
    }

    void BackClicked()
    {
        backButton.transform.parent = gameObject.transform;
        backButton.transform.position = backButtonInitialPosition;

        uiController.OptionsBackClicked();
    }

    void NextButtonClicked()
    {
        backButton.transform.parent = GUICamera.transform;

        iTween.Defaults.easeType = iTween.EaseType.linear;
        Vector3 newCameraPosition;
        newCameraPosition = new Vector3(zoneSelectionCameraPosition2.position.x, zoneSelectionCameraPosition2.position.y, GUICamera.transform.position.z);
        iTween.MoveTo(GUICamera, newCameraPosition, .5f);
    }

    void PreviousButtonClicked()
    {
        Vector3 newCameraPosition;
        newCameraPosition = new Vector3(zoneSelectionCameraPosition.position.x, zoneSelectionCameraPosition.position.y, GUICamera.transform.position.z);
        iTween.MoveTo(GUICamera, newCameraPosition, .5f);
    }

    void Zone1ButtonClicked()
    {
        Game.currentZoneIndex = 0;
        ZoneButtonClicked();
    }

    void Zone2ButtonClicked()
    {
        Game.currentZoneIndex = 1;
        ZoneButtonClicked();
    }

    void Zone3ButtonClicked()
    {
        Game.currentZoneIndex = 2;
        ZoneButtonClicked();
    }

    void Zone4ButtonClicked()
    {
        Game.currentZoneIndex = 3;
        ZoneButtonClicked();
    }

    void Zone5ButtonClicked()
    {
        Game.currentZoneIndex = 4;
        ZoneButtonClicked();
    }

    void Zone6ButtonClicked()
    {
        Game.currentZoneIndex = 5;
        ZoneButtonClicked();
    }

    void ZoneButtonClicked()
    {
        levelSelectionScript.PrepareLevels();
        uiController.FadeInFader();

        Invoke("ZoneClicked", uiController.timeDelayBetweenCameraMovement);
    }

    void ZoneClicked()
    {
        Vector3 newCameraPosition;
        newCameraPosition = new Vector3(levelSelectionCameraPosition.position.x, levelSelectionCameraPosition.position.y, GUICamera.transform.position.z);
        GUICamera.transform.position = newCameraPosition;
    }
    
}
