using UnityEngine;
using System.Collections;

public class ScrollerContainerScript : MonoBehaviour 
{
    public Transform[] buttonsTransform;
    public ScrollablePanel scrollScript;
    int numberOfObjects = 0;
    float buttonGap;
	
	void Start () 
    {
        buttonGap = scrollScript.boxSpacing;

        numberOfObjects = buttonsTransform.Length;

        float xPos = (int)((int)numberOfObjects / 2) * buttonGap;

        print(xPos);

        
        for (int i = 0; i < numberOfObjects ; i++)
        {
            buttonsTransform[i].localPosition = new Vector3(xPos, buttonsTransform[i].localPosition.y, buttonsTransform[i].localPosition.z);
            xPos -= buttonGap;
        }

        leftMostObject = buttonsTransform[0].gameObject;
        rightMostObject = buttonsTransform[numberOfObjects - 1].gameObject;

        maxLeftPos = (numberOfObjects / 2 ) * buttonGap + 1;
        maxRightPos = (numberOfObjects / 2) * buttonGap + 1;
       

        InvokeRepeating("CheckSwipe", 0, .1f);
        
	
	}

    float maxLeftPos;
    float maxRightPos;

    public GameObject leftMostObject;
    public GameObject rightMostObject;

    void CheckSwipe()
    {
        if (leftMostObject.transform.localPosition.x + transform.localPosition.x > maxLeftPos && scrollScript.swipeDirection == ScrollablePanel.SwipeDirection.Left)
            SwipedLeft();

        if (rightMostObject.transform.localPosition.x + transform.localPosition.x < -maxRightPos && scrollScript.swipeDirection == ScrollablePanel.SwipeDirection.Right)
            SwipedRight();
        

    }

    internal void SwipedLeft()
    {
      
        leftMostObject = buttonsTransform[0].gameObject;
        rightMostObject = buttonsTransform[numberOfObjects - 1].gameObject;

        leftMostObject.transform.localPosition = new Vector3(rightMostObject.transform.localPosition.x - buttonGap, leftMostObject.transform.localPosition.y, leftMostObject.transform.localPosition.z);


        
        Transform tempTransfrom = buttonsTransform[0];

        for (int i = 0; i < numberOfObjects -1 ; i++)
        {
            buttonsTransform[i] = buttonsTransform[i+1];            
        }

        buttonsTransform[numberOfObjects-1] = tempTransfrom;

        leftMostObject = buttonsTransform[0].gameObject;
        rightMostObject = buttonsTransform[numberOfObjects - 1].gameObject;

    }


    internal void SwipedRight()
    {
       
        leftMostObject = buttonsTransform[0].gameObject;
        rightMostObject = buttonsTransform[numberOfObjects - 1].gameObject;

     //   print(leftMostObject.transform.localPosition.x + buttonGap);

        rightMostObject.transform.localPosition = new Vector3(leftMostObject.transform.localPosition.x + buttonGap, rightMostObject.transform.localPosition.y, rightMostObject.transform.localPosition.z);



        Transform tempTransfrom = buttonsTransform[numberOfObjects - 1];

        for (int i = numberOfObjects-1; i > 0; i--)
        {
            buttonsTransform[i] = buttonsTransform[i - 1];
        }

        buttonsTransform[0] = tempTransfrom;

        leftMostObject = buttonsTransform[0].gameObject;
        rightMostObject = buttonsTransform[numberOfObjects - 1].gameObject;
    }
	
}
