using UnityEngine;
using System.Collections;

public class RocketSelectionScript : MonoBehaviour {

    UIController uiController;
	void Start () 
    {
        uiController = GameObject.Find("UIController").GetComponent<UIController>();
	
	}


    void Rocket1Clicked()
    {
        Rocket.currentRocketIndex = 0;
        RocketSelected();
    }

    void Rocket2Clicked()
    {
        Rocket.currentRocketIndex = 1;
        RocketSelected();
    }

    void Rocket3Clicked()
    {
        Rocket.currentRocketIndex = 2;
        RocketSelected();
    }

    void Rocket4Clicked()
    {
        Rocket.currentRocketIndex = 3;
        RocketSelected();
    }

    void Rocket5Clicked()
    {
        Rocket.currentRocketIndex = 4;
        RocketSelected();
    }

    void Rocket6Clicked()
    {
        Rocket.currentRocketIndex = 5;
        RocketSelected();
    }


    void RocketSelected()
    {
        Application.LoadLevel(2);
    }
}
