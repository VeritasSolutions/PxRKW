using UnityEngine;
using System.Collections;

public class ScrollablePanel : MonoBehaviour 
{
    public enum SwipeDirection
    {
        Left,
        Right,
        None
    };

    internal SwipeDirection swipeDirection = SwipeDirection.None;

    Camera GUICamera;

    bool trackPath = false;

    float initialXPos = 0f;
    

    bool autoMove = false;

    Vector3 targetPosition = Vector3.zero;

    Transform myTransform;
    public float boxSpacing = 6;

    public ScrollerContainerScript scrollerContainerScript;
    public Transform scrollerContianerTransform;
    public BoxCollider  scrollerBoxCollider;

    ShopItemUIManager shopItemUIManager;



    void Start()
    {
        shopItemUIManager = GameObject.Find("ShopItemSelectionContent").GetComponent<ShopItemUIManager>();
        GUICamera = GameObject.Find("GUICamera").camera;       

        scrollerContianerTransform.parent = transform.parent;        
        
        myTransform = transform;
    }


    void Update()
    {
        scrollerContianerTransform.position = transform.position;

        if (autoMove)
            Update1();
    }

   void FixedUpdate()
   {
       scrollerBoxCollider.center = new Vector3(-transform.localPosition.x, 0, 0);
   }

    void Update1()
    {

        myTransform.localPosition = Vector3.Lerp(myTransform.localPosition, targetPosition, Time.deltaTime * 3);


        float dist = Mathf.Abs(myTransform.localPosition.x - targetPosition.x);

        if (dist < .01f)
        {
            swipeDirection = SwipeDirection.None;

            autoMove = false;            
        }

    }


    float touchInitiatedTime;
    Vector3 touchInitiatedPos;
    float touchEndedTime;
    Vector3 touchEndedPos;

    float swipeUpThresold = 2f;
    

    public void OnMouseDown()
    {        
        if (autoMove)
        {
            autoMove = false;            
        }

        touchInitiatedTime = Time.realtimeSinceStartup;
        touchInitiatedPos = Input.mousePosition;
        Vector3 tempPos = GUICamera.ScreenToWorldPoint(Input.mousePosition);
        initialXPos = tempPos.x;
        trackPath = true;
    }    

    public void OnMouseDrag()
    {

        if (!trackPath)
            return;
        
        Vector3 tempPos = GUICamera.ScreenToWorldPoint(Input.mousePosition);
        float newXPos = tempPos.x;

        myTransform.localPosition = new Vector3(myTransform.localPosition.x + (newXPos - initialXPos), myTransform.localPosition.y, myTransform.localPosition.z);
        initialXPos = newXPos;
    }

    public void OnMouseUp()
    {

        if (!trackPath)
            return;       

        trackPath = false;

        touchEndedTime = Time.realtimeSinceStartup;
        touchEndedPos = Input.mousePosition;

        

        if (touchEndedTime - touchInitiatedTime > .5f) //not swiped
        {
            NotSwiped();
        }
        else
        {
          //  print(Mathf.Abs(touchEndedPos.x - touchInitiatedPos.x));
            if (touchEndedPos.y - touchInitiatedPos.y > swipeUpThresold && Mathf.Abs(touchEndedPos.x - touchInitiatedPos.x) < 5f)
            {
                SwipeUP();
                return;
            }
            else if (touchEndedPos.y - touchInitiatedPos.y < -swipeUpThresold && Mathf.Abs(touchEndedPos.x - touchInitiatedPos.x) < 5f)
            {
                SwipeDown();
                return;
            }

            if (touchEndedPos.x < touchInitiatedPos.x)
                SwipeLeft();
            else
                SwipeRight();
        }

        

        
    }    
    
    internal void SwipeLeft()  //0,4,8,12
    {
      //  print("Swipe Left");
        swipeDirection = SwipeDirection.Left;

        float currentX = transform.localPosition.x;
        float targetX = 0;
        if(currentX > 0)
            targetX = ((int)currentX / (int)boxSpacing + 1) * boxSpacing;
        else
            targetX = ((int)currentX / (int)boxSpacing) * boxSpacing;

        targetPosition = new Vector3(targetX, transform.localPosition.y, transform.localPosition.z);

        print(targetPosition);
        autoMove = true;
        
    }

    internal void SwipeRight() // 0,-4,-8
    {
      //  print("Swipe Right");
        swipeDirection = SwipeDirection.Right;

        float currentX = transform.localPosition.x;
        float targetX = 0;

        if(currentX >0)
            targetX = ((int)currentX / (int)boxSpacing) * boxSpacing;
        else
            targetX = ((int)currentX / (int)boxSpacing - 1) * boxSpacing;

        targetPosition = new Vector3(targetX, transform.localPosition.y, transform.localPosition.z);
        
        autoMove = true;
    }

    void SwipeUP()
    {
       // print("Swipe UP");
        shopItemUIManager.NextButtonClicked();
    }

    void SwipeDown()
    {
      //  print("Swipe Down");
        shopItemUIManager.PreviousButtonClicked();
    }
   
    private void NotSwiped()
    {

        float currentX = transform.position.x;

        float leftX = ((int)currentX / (int)boxSpacing + 1) * boxSpacing;
        float rightX= ((int)currentX / (int)boxSpacing) * boxSpacing;

        float leftDelta = Mathf.Abs(currentX - leftX);
        float rightDelta = Mathf.Abs(currentX - rightX);

        if (leftDelta < rightDelta)
            SwipeLeft();
        else
            SwipeRight();
        
    }


    int currentRocketIndex=0;
    int numberOfRockets=0;

    internal void BringCurrentRocketToCenter(int _currentRocketIndex,int _numberOfRockets)
    {
        currentRocketIndex = _currentRocketIndex;
        numberOfRockets = _numberOfRockets;

        Invoke("BringToCenter", .5f);

    }

    void BringToCenter()
    {
        print(currentRocketIndex);

        float deltaX = 0;

        if (currentRocketIndex > numberOfRockets / 2)
        {
            swipeDirection = ScrollablePanel.SwipeDirection.Left;
            deltaX = (currentRocketIndex - numberOfRockets / 2) * boxSpacing;
        }
        else
        {
            swipeDirection = ScrollablePanel.SwipeDirection.Right;
            deltaX = (currentRocketIndex - numberOfRockets / 2) * boxSpacing;
        }

        targetPosition = new Vector3(deltaX, transform.localPosition.y, transform.localPosition.z);

        autoMove = true;
    }
    
}
