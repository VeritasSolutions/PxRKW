using UnityEngine;
using System.Collections;

public class StatsAdjustment : MonoBehaviour 
{

    public TextMesh rocket1AgilityValueText;

    
    

    
	
	void Start () 
    {
        rocket1AgilityValueText.text = GameVariables.rocket1Acceleration.ToString();

        kiwiBaseSpeedText.text = KiwiSpeedController.initialSpeed.ToString();
	}

    void Rocket1AgilityUp()
    {
        GameVariables.rocket1Acceleration += .5f;
        rocket1AgilityValueText.text = GameVariables.rocket1Acceleration.ToString();
    }

    void Rocket1AgilityDown()
    {
        GameVariables.rocket1Acceleration -= .5f;
        rocket1AgilityValueText.text = GameVariables.rocket1Acceleration.ToString();
    }

    public TextMesh kiwiBaseSpeedText;


    void BaseSpeedUp()
    {
      //  if (KiwiSpeedController.initialSpeed >= 12)
       //     return;

        KiwiSpeedController.initialSpeed += 1f;
        kiwiBaseSpeedText.text = KiwiSpeedController.initialSpeed.ToString();
    }

    void BaseSpeedDown()
    {
        if (KiwiSpeedController.initialSpeed <= 1)
            return;

        KiwiSpeedController.initialSpeed -= 1f;
        kiwiBaseSpeedText.text = KiwiSpeedController.initialSpeed.ToString();
    }
	
	
}
