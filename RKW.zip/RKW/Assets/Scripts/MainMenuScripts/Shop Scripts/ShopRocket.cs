using UnityEngine;
using System.Collections;

public class ShopRocket : MonoBehaviour 
{
    public enum RocketState
    {
        Available,
        Locked,
        Equiped,
    };

    public GameObject availableBorderPrefab;
    public GameObject equippedBorderPrefab;
    public GameObject lockedBorderPrefab;
    public GameObject newRocketSparklesPrefab;

    public Rockets rocketIdentifier;

    

    internal RocketState rocketState= RocketState.Locked;

    GameObject newLabel;
    UIButton equippedButton;
    TextMesh equippedButtonText;
    TextMesh rocketNameText;

    public RocketSelectionPage rocketSelectionPageScript;

    ArrayList tempObjects;


    internal void Reset()
    {
        for (int i = 0; i < tempObjects.Count; i++)
        {
            Destroy((GameObject)tempObjects[i]);
        }
    }
   	
	void Start () 
    {
        tempObjects = new ArrayList();
        rocketSelectionPageScript = GameObject.Find("Rocket Selection Page").GetComponent<RocketSelectionPage>();

        newLabel = gameObject.transform.FindChild("New Label").gameObject;

        equippedButton = gameObject.transform.FindChild("Equip Button").GetComponent<UIButton>();
        equippedButton.scriptWithMethodToInvoke = rocketSelectionPageScript;
        equippedButton.methodToInvoke = rocketIdentifier.ToString() + "ButtonClicked";

        equippedButtonText = equippedButton.transform.FindChild("Equip Text").GetComponent<TextMesh>();

        rocketNameText = transform.FindChild("Rocket Name").GetComponent<TextMesh>();
        rocketNameText.text = rocketIdentifier.ToString();


        newLabel.active = false;

        
	
	}

    internal void PrepareRocketFrame()
    {
        Reset();

        if (rocketState == RocketState.Equiped)
            EnableEquipedSetting();
        else if (rocketState == RocketState.Available)
            EnableAvailableSetting();
        else if (rocketState == RocketState.Locked)
            EnableLockedSetting();
    }

    void EnableAvailableSetting()
    {
        GameObject temp = (GameObject)Instantiate(availableBorderPrefab, Vector3.zero, Quaternion.identity);
        temp.transform.localScale = transform.localScale;
        temp.transform.parent = transform;
        temp.transform.localPosition = new Vector3(0, 0, .1f);
        tempObjects.Add(temp);

        equippedButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
        equippedButtonText.text = "Equip";
    }

    void EnableLockedSetting()
    {
        GameObject temp = (GameObject)Instantiate(lockedBorderPrefab, Vector3.zero, Quaternion.identity);
        temp.transform.localScale = transform.localScale;
        temp.transform.parent = transform;
        temp.transform.localPosition = new Vector3(0, 0, .1f);
        tempObjects.Add(temp);

        equippedButton.gameObject.active = false;
        equippedButtonText.gameObject.active = false;

        temp = (GameObject)Instantiate(newRocketSparklesPrefab, Vector3.zero, Quaternion.identity);
        temp.transform.localScale = transform.localScale;
        temp.transform.parent = transform;
        temp.transform.localPosition = new Vector3(0, .4f, 1f);
        tempObjects.Add(temp);
    }

    void EnableEquipedSetting()
    {
        GameObject temp = (GameObject)Instantiate(equippedBorderPrefab, Vector3.zero, Quaternion.identity);
        temp.transform.localScale = transform.localScale;
        temp.transform.parent = transform;
        temp.transform.localPosition = new Vector3(0, 0, .1f);
        tempObjects.Add(temp);

        equippedButton.SetControlState(UIButton.CONTROL_STATE.DISABLED);
        equippedButtonText.text = "Equipped";
    }

   
	
	
}
