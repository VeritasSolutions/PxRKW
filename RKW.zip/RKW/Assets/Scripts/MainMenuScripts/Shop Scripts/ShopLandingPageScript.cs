using UnityEngine;
using System.Collections;

public class ShopLandingPageScript : MonoBehaviour 
{

    public enum CurrentSelectedShopItem
    {
        None,
        Rocket,
        Booster,
        Coins

    }

    public static CurrentSelectedShopItem currentSelectedShopItem = CurrentSelectedShopItem.None;

    public Transform mainMenuCameraPosition;
    public Transform itemSelectionPageCameraPosition;

    MainMenuCameraMovement mainMenuCameraMovement;

    public GameObject rocketSection;
    public GameObject coinPackSection;

    public ShopItemUIManager shopItemUIManager;


	void Start () 
    {
        mainMenuCameraMovement = GameObject.Find("GUICamera").GetComponent<MainMenuCameraMovement>();
	
	}

    void BackButtonClicked()
    {
        mainMenuCameraMovement.MoveTo(mainMenuCameraPosition.position);
    }

    void RocketButtonClicked()
    {
       
        currentSelectedShopItem = CurrentSelectedShopItem.Rocket;
        shopItemUIManager.PreperShopUI();

        iTween.PunchScale(rocketSection, new Vector3(.2f, .2f, .2f), 1f);

        mainMenuCameraMovement.MoveTo(itemSelectionPageCameraPosition.position, .5f);
    }

    void CoinPackButtonClicked()
    {
        currentSelectedShopItem = CurrentSelectedShopItem.Coins;
        shopItemUIManager.PreperShopUI();

        iTween.PunchScale(coinPackSection, new Vector3(.2f, .2f, .2f), 1f);

        mainMenuCameraMovement.MoveTo(itemSelectionPageCameraPosition.position, .5f);
    }
	
	
}
