using UnityEngine;
using System.Collections;

public class RocketSelectionPage : MonoBehaviour 
{
    ShopItemUIManager shopUIManager;
    public ShopRocket[] shopRocketScripts;
    public ScrollablePanel scrollScript;

    void Start()
    {
        shopUIManager = GameObject.Find("ShopItemSelectionContent").GetComponent<ShopItemUIManager>();
        PrepareRocketsButtons();
    }

    internal void PrepareRocketsButtons()
    {
        int currentRocketIndex = 0;
        
        for (int i = 0; i < shopRocketScripts.Length; i++)
        {

            if (shopRocketScripts[i].rocketIdentifier == Game.currentlyEquippedRocket)
            {
                shopRocketScripts[i].rocketState = ShopRocket.RocketState.Equiped;
                currentRocketIndex = i;
            }
            else
                shopRocketScripts[i].rocketState = ShopRocket.RocketState.Available;

            shopRocketScripts[i].PrepareRocketFrame();

        }

        scrollScript.BringCurrentRocketToCenter(currentRocketIndex, shopRocketScripts.Length);
    }

    

    void Rocket1ButtonClicked()
    {
        Game.currentlyEquippedRocket = Rockets.Rocket1;
        RocketSelected();
    }

    void Rocket2ButtonClicked()
    {
        Game.currentlyEquippedRocket = Rockets.Rocket2;
        RocketSelected();
    }

    void Rocket3ButtonClicked()
    {
        Game.currentlyEquippedRocket = Rockets.Rocket3;
        RocketSelected();
    }

    void Rocket4ButtonClicked()
    {
        Game.currentlyEquippedRocket = Rockets.Rocket4;
        RocketSelected();
    }

    void Rocket5ButtonClicked()
    {
        Game.currentlyEquippedRocket = Rockets.Rocket5;
        RocketSelected();
    }

    void Rocket6ButtonClicked()
    {
        Game.currentlyEquippedRocket = Rockets.Rocket6;
        RocketSelected();
    }

    void RocketSelected()
    {
        PrepareRocketsButtons();
        Rocket.currentRocketIndex = int.Parse(Game.currentlyEquippedRocket.ToString().Substring(6)) - 1;
        print("Current Rocket Index " + Rocket.currentRocketIndex);
    }


    
	
	
}
