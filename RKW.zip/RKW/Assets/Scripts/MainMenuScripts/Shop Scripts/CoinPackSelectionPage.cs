using UnityEngine;
using System.Collections;

public class CoinPackSelectionPage : MonoBehaviour 
{
    ShopItemUIManager shopUIManager;

    void Start()
    {
        shopUIManager = GameObject.Find("ShopItemSelectionContent").GetComponent<ShopItemUIManager>();
    }

    void CoinPack1Clicked()
    {
        Game.totalNumberOfCoinsCollected += 10000;
        CoinPackClicked();
    }

    void CoinPack2Clicked()
    {
        Game.totalNumberOfCoinsCollected += 20000;
        CoinPackClicked();
    }

    void CoinPack3Clicked()
    {
        Game.totalNumberOfCoinsCollected += 50000;
        CoinPackClicked();
    }

    void CoinPack4Clicked()
    {
        Game.totalNumberOfCoinsCollected += 100000;
        CoinPackClicked();
    }

    void CoinPack5Clicked()
    {
        Game.totalNumberOfCoinsCollected += 200000;
        CoinPackClicked();
    }

    void CoinPackClicked()
    {
        Game.SaveGameSettings();
        shopUIManager.UpdateStats();
    }

    
	
	
}
