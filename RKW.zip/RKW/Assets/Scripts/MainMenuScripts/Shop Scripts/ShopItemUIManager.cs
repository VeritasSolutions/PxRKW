using UnityEngine;
using System.Collections;

public class ShopItemUIManager : MonoBehaviour 
{
    public ShopLandingPageScript.CurrentSelectedShopItem []shopItemSequence;

    MainMenuCameraMovement mainMenuCameraMovement;
    public Transform shopLandingCameraPosition;
    public TextMesh title;


    public Transform rocketSelectionPageTransform;
    public Transform coinsSelectionPageTransform;
    public Transform boostersSelectionPageTransform;

    public TextMesh coinText;
    public TextMesh featherText;

    int shopItemIndex = 0;

    void Start()
    {
        shopItemSequence = new ShopLandingPageScript.CurrentSelectedShopItem[4];

        shopItemSequence[0] = ShopLandingPageScript.CurrentSelectedShopItem.Rocket;
        shopItemSequence[1] = ShopLandingPageScript.CurrentSelectedShopItem.Coins;
        shopItemSequence[2] = ShopLandingPageScript.CurrentSelectedShopItem.Rocket;
        shopItemSequence[3] = ShopLandingPageScript.CurrentSelectedShopItem.Coins;




        mainMenuCameraMovement = GameObject.Find("GUICamera").GetComponent<MainMenuCameraMovement>();

    }


    internal void PreperShopUI()
    {
        coinText.text = Game.totalNumberOfCoinsCollected.ToString();
        featherText.text = Game.totalNumberOfFeathersCollected.ToString();


        SendEverythingBack();

        if (ShopLandingPageScript.currentSelectedShopItem == ShopLandingPageScript.CurrentSelectedShopItem.Rocket)
        {
            shopItemIndex = 0;
            rocketSelectionPageTransform.position = new Vector3(rocketSelectionPageTransform.position.x, 0, rocketSelectionPageTransform.position.z);
            title.text = "Rocket";
        }

        else if (ShopLandingPageScript.currentSelectedShopItem == ShopLandingPageScript.CurrentSelectedShopItem.Coins)
        {
            shopItemIndex = 1;
            coinsSelectionPageTransform.position = new Vector3(coinsSelectionPageTransform.position.x, 0, coinsSelectionPageTransform.position.z);
            title.text = "Coin Packs";
        }

        else if (ShopLandingPageScript.currentSelectedShopItem == ShopLandingPageScript.CurrentSelectedShopItem.Booster)
        {
            shopItemIndex = 2;
            boostersSelectionPageTransform.position = new Vector3(boostersSelectionPageTransform.position.x, 0, boostersSelectionPageTransform.position.z);
            title.text = "Booster";
        }
    }

    private void SendEverythingBack()
    {
        rocketSelectionPageTransform.position = new Vector3(rocketSelectionPageTransform.position.x, 20, rocketSelectionPageTransform.position.z);
        coinsSelectionPageTransform.position = new Vector3(coinsSelectionPageTransform.position.x, 20, coinsSelectionPageTransform.position.z);
       // boostersSelectionPageTransform.position = new Vector3(boostersSelectionPageTransform.position.x, 50, boostersSelectionPageTransform.position.z);
    }

    void BackButtonClicked()
    {
        mainMenuCameraMovement.MoveTo(shopLandingCameraPosition.position);
        rocketSelectionPageTransform.GetComponent<RocketSelectionPage>().PrepareRocketsButtons();
    }

    internal void NextButtonClicked()
    {
        shopItemIndex++;
        if (shopItemIndex >= shopItemSequence.Length)
            shopItemIndex = 0;

        ShopLandingPageScript.currentSelectedShopItem = shopItemSequence[shopItemIndex];
        PreperShopUI();
    }

    internal void PreviousButtonClicked()
    {
        shopItemIndex--;
        if (shopItemIndex < 0)
            shopItemIndex = shopItemSequence.Length - 1;

        ShopLandingPageScript.currentSelectedShopItem = shopItemSequence[shopItemIndex];
        PreperShopUI();
    }

    internal void UpdateStats()
    {
        coinText.text = Game.totalNumberOfCoinsCollected.ToString();
        featherText.text = Game.totalNumberOfFeathersCollected.ToString();
    }
}
