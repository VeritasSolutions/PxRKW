using UnityEngine;
using System.Collections;

public class StoryModeLevelSelectionScript : MonoBehaviour 
{

    public Transform zoneSelectionCameraPosition;
    public Transform zoneSelectionCameraPosition2;

    GameObject GUICamera;

    UIController uiController;

    public TextMesh infoText;

    public GameObject[] buttonContainers;

    UIButton[] levelButtons;
    TextMesh[] levelTexts;
    TextMesh[] highScoreTexts;

    void Start()
    {
        uiController = GameObject.Find("UIController").GetComponent<UIController>();
        GUICamera = GameObject.Find("GUICamera");

        levelButtons = new UIButton[buttonContainers.Length];
        levelTexts = new TextMesh[buttonContainers.Length];
        highScoreTexts = new TextMesh[buttonContainers.Length];

        for (int i = 0; i < buttonContainers.Length; i++)
        {
            levelButtons[i] = buttonContainers[i].GetComponentInChildren<UIButton>();
            levelTexts[i] = buttonContainers[i].transform.FindChild("Text").GetComponent<TextMesh>();
            highScoreTexts[i] = buttonContainers[i].transform.FindChild("High Score Text").GetComponent<TextMesh>();

        }

    }

    internal void PrepareLevels()
    {

        infoText.text = "Zone " + (Game.currentZoneIndex + 1).ToString();

        int numberOfLevelsUnlocked = Game.numberOfExploredLevels[Game.currentZoneIndex];

        int i = 0;
        for (; i < numberOfLevelsUnlocked; i++)
        {
            levelButtons[i].SetControlState(UIButton.CONTROL_STATE.NORMAL);
            levelTexts[i].gameObject.active = true;
            highScoreTexts[i].text = "High Score : " + Game.levelsBestScore[(Game.currentZoneIndex * (Game.numberOfLevelsInEachZone + 1) + i)].ToString();
            
        }
        for (; i < buttonContainers.Length; i++)
        {
            levelButtons[i].SetControlState(UIButton.CONTROL_STATE.DISABLED);
            levelTexts[i].gameObject.active = false;
            highScoreTexts[i].text = "High Score : 0";
        }

    }

    void BackButtonClicked()
    {
        
        uiController.FadeInFader();

        Invoke("ZoneClicked", uiController.timeDelayBetweenCameraMovement);
    }

    void ZoneClicked()
    {
        Vector3 newCameraPosition;
        if(Game.currentZoneIndex < 3)
            newCameraPosition = new Vector3(zoneSelectionCameraPosition.position.x, zoneSelectionCameraPosition.position.y, GUICamera.transform.position.z);
        else
            newCameraPosition = new Vector3(zoneSelectionCameraPosition2.position.x, zoneSelectionCameraPosition2.position.y, GUICamera.transform.position.z);

        GUICamera.transform.position = newCameraPosition;
    }

    int levelToLoad = 0;
    int clickedLevelIndex = 0;

    void Level1ButtonClicked()
    {
        
        clickedLevelIndex = 0;
        LevelButtonClicked();
        
    }

    void Level2ButtonClicked()
    {
        clickedLevelIndex = 1;
        LevelButtonClicked();
    }

    void Level3ButtonClicked()
    {
        clickedLevelIndex = 2;
        LevelButtonClicked();
    }

    void LevelButtonClicked()
    {
        Game.currentZonelevelIndex = clickedLevelIndex;

        levelToLoad = Game.currentZoneIndex * (Game.numberOfLevelsInEachZone + 1) + clickedLevelIndex + Game.level1BuildSettingIndex;

        Game.currentLoadedLevelForStats = levelToLoad - Game.level1BuildSettingIndex;

        uiController.JustFadeInFader();

        Invoke("LoadLevel", uiController.timeDelayBetweenCameraMovement);

    }

    void LoadLevel()
    {
        Application.LoadLevel(levelToLoad);   
    }
}
