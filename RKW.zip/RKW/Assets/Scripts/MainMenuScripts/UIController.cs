using UnityEngine;
using System.Collections;
using System.IO;

public class UIController : MonoBehaviour 
{
    public GameObject GUICamera;

    public Transform mainMenuPosition;
    public Transform aboutScreenPosition;
    
    public AudioSource startingMusic;

    internal float timeDelayBetweenCameraMovement = .5f;

    Color fadeOutColor = new Color(1, 1, 1, 0);
    Color fadeInColor = new Color(1, 1, 1, .9f);   //.9 == 230


    public UIManager uiManager;
    AudioSource mainMenuMusic;    

    public Transform optionsCameraPosition;
    public Transform zoneSelectionCameraPosition;
    public Transform challengeModeCameraposition;
    public Transform shopLandingCameraPosition;
    public StoryModeZoneSelectionScript storyModeSelectionScript;


    public ChallengeModeSelectionScript challengeModeSelectionScript;

    public MainMenuCameraMovement mainMenuCameraMovement;

    public UIPanel faderPanel;
    
    void CheckForInitailChartboostAd()
    {
        MoreGamesBinding.DisplayInterstial();
    }

    

	void Start () 
    {
        Game.goToTouchPosition = true;

        faderPanel.gameObject.active = true;

        mainMenuCameraMovement = GUICamera.GetComponent<MainMenuCameraMovement>();
        GUICamera.transform.position = new Vector3(mainMenuPosition.position.x, mainMenuPosition.position.y, GUICamera.transform.position.z);

      //  PlayerPrefs.DeleteAll();
      //  Game.Reset();

        Game.LoadGameSettings();

        Game.numberOfZoneUnlocked = 6;

        Game.numberOfExploredLevels[0] = 3;
        Game.numberOfExploredLevels[1] = 3;
        Game.numberOfExploredLevels[2] = 3;
        Game.numberOfExploredLevels[3] = 3;
        Game.numberOfExploredLevels[4] = 3;
        Game.numberOfExploredLevels[5] = 3;

        timeDelayBetweenCameraMovement = timeAfterWhichToInvoke + fadeInOutTime;        
        CheckCameraPosition();
	}
   



    void CheckCameraPosition()
    {
        if (Game.currentZoneIndex == -1)
            Invoke("FadeOutFader", fadeInOutTime);
        else
        {
            if (Game.gameMode == Game.GameMode.Story)
                StoryModeButtonClicked();
            else
                ChallengeModeButtonClicked();
        }


    }
    public TextMesh controlText;

    void ToggleControlButtonClicked()
    {        
        Game.goToTouchPosition = !Game.goToTouchPosition;
        if (Game.goToTouchPosition)
            controlText.text = "Move To Position";
        else
            controlText.text = "Classical";
    }

    void MoreGamesButtonClicked()
    {
        MoreGamesBinding.MoreGames();
    }

    float timeAfterWhichToInvoke = .1f;
    float fadeInOutTime = .2f;

    

   

    public void JustFadeInFader()
    {
        uiManager.blockInput = true;

        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

    }

    public void FadeInFader()
    {
        uiManager.blockInput = true;

        if (InAppController.currentInAppType == InAppController.InAppsType.None)
        {
            faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);
            Invoke("FadeOutFader", timeAfterWhichToInvoke + fadeInOutTime);
        }
        else
        {
            faderPanel.StartTransition(UIPanelManager.SHOW_MODE.DismissForward);
        }
    }

    internal void FadeOutFader()
    {
        uiManager.blockInput = false;
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
    }

    
    int mapIndexToLoad = 0;

    void OptionsButtonClicked()
    {
        mainMenuCameraMovement.MoveTo(optionsCameraPosition.position);
    }
   
    void StoryModeButtonClicked()
    {
        Game.gameMode = Game.GameMode.Story;

        storyModeSelectionScript.PrepareZones();
        mainMenuCameraMovement.MoveTo(zoneSelectionCameraPosition.position);
    }
    
    void ShopButtonClicked()
    {
        mainMenuCameraMovement.MoveTo(shopLandingCameraPosition.position);
    }

    void ChallengeModeButtonClicked()
    {
        Game.gameMode = Game.GameMode.Challenging;

        challengeModeSelectionScript.PrepareZones();
        mainMenuCameraMovement.MoveTo(challengeModeCameraposition.position);        
    }

    void QuickStartButtonClicked()
    {
        FadeInFader();
        Invoke("QuickStartClicked", timeDelayBetweenCameraMovement);
    }

    void QuickStartClicked()
    {
        Application.LoadLevel(2);
    }

    void OptionsBackButtonClicked()
    {
        mainMenuCameraMovement.MoveTo(mainMenuPosition.position);   
       
    }

    internal void OptionsBackClicked()
    {
        Vector3 newCameraPosition;
        newCameraPosition = new Vector3(mainMenuPosition.position.x, mainMenuPosition.position.y, GUICamera.transform.position.z);
        GUICamera.transform.position = newCameraPosition;
    }


    public void BoxButtonClicked()
    {
        FadeInFader();
        Invoke("BoxClicked", timeDelayBetweenCameraMovement);
    }

    

    void BoxBackButtonClicked()
    {        
        FadeInFader();
        Invoke("BoxBackClicked", timeDelayBetweenCameraMovement);
    }

    void BoxBackClicked()
    {
        Vector3 newCameraPosition = new Vector3(mainMenuPosition.position.x, mainMenuPosition.position.y, GUICamera.transform.position.z);
        GUICamera.transform.position = newCameraPosition;
    }

    public ScrollablePanel scrollablePanelScript;

    void LoadLevel()
    {
        Application.LoadLevel(1);
    }

    void LevelBackButtonClicked()
    {       
        FadeInFader();
       // scrollablePanelScript.SetBoxesPosition();
        Invoke("LevelBackClicked", timeDelayBetweenCameraMovement);
        
    }

    void LevelBackClicked()
    {
        Vector3 newCameraPosition = new Vector3(zoneSelectionCameraPosition.position.x, zoneSelectionCameraPosition.position.y, GUICamera.transform.position.z);
        GUICamera.transform.position = newCameraPosition;
    }

    void HomeClicked()
    { 
        Vector3 newCameraPosition = new Vector3(mainMenuPosition.position.x, mainMenuPosition.position.y, GUICamera.transform.position.z);
        GUICamera.transform.position = newCameraPosition;
    }

    void ResetButtonClicked()
    {        
        Game.Reset();
       // PreparePuzzleButtons();
        Application.LoadLevel(0);
        
    }

    void LoadMap()
    {
        Application.LoadLevel(mapIndexToLoad);
    }


}
