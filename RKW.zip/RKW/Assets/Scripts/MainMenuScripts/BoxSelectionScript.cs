using UnityEngine;
using System.Collections;

public class BoxSelectionScript : MonoBehaviour {

    public UIController uiController;
    public static int[] coinsToUnlockMap = { 0, 1000, 1500, 2000 };

    public UIButton[] mapButtons;


    public GameObject[] lockedImages;

    int numberOfBoxUnlocked = 2;



    //make it for ... keep 0 and 1 same

    void Start()
    {
        
        DoButtonsSettings();

        Invoke("PrepareButtons", .1f);

    }

    void DoButtonsSettings()
    {
        AudioSource buttonClickAudio = GameObject.Find("Button Tap Sound").GetComponent<AudioSource>();

    }

    public void PrepareButtons()
    {
        int i = 0;
        for (; i < numberOfBoxUnlocked; i++)
        {            

            lockedImages[i].active = false;

            mapButtons[i].SetControlState(UIButton.CONTROL_STATE.NORMAL);
            
        }

        
        for (; i < mapButtons.Length; i++)
        {

            lockedImages[i].active = true;
            mapButtons[i].SetControlState(UIButton.CONTROL_STATE.DISABLED);

        }
    }


    //unlock buttons

    int currentMapIndex = 0;

    void Map1UnlockClicked()
    {
        currentMapIndex = 0;
        UnlockButtonClicked();
    }

    void Map2UnlockClicked()
    {
        currentMapIndex = 1;
        UnlockButtonClicked();
    }

    void Map3UnlockClicked()
    {
        currentMapIndex = 2;
        UnlockButtonClicked();
    }

    void Map4UnlockClicked()
    {
        currentMapIndex = 3;
        UnlockButtonClicked();
    }

    public GameObject inAppYesNoObjectPrefab;

    void UnlockButtonClicked()
    {

    }
}
