using UnityEngine;
using System.Collections;

public class AirCurrentNodeController : MonoBehaviour {

   
    public int currentActivatedNodeIndex;
    public Transform[] flowPoints;
    

	void Awake() 
    {
        
        flowPoints = transform.GetComponentsInChildren<Transform>();

        for (int i = 1; i < flowPoints.Length; i++)
        {
            for (int j = 1; j < flowPoints.Length-1; j++)
			{
                if (int.Parse(flowPoints[j].gameObject.name) > int.Parse(flowPoints[j + 1].gameObject.name))
                {
                    Transform temp = flowPoints[j];
                    flowPoints[j] = flowPoints[j + 1];
                    flowPoints[j + 1] = temp;
                }
			 
			}
            
        }
	
	}
}
