using UnityEngine;
using System.Collections;

public class Variables : MonoBehaviour 
{

    public static string appID = "111105792295244";
    public static string bundleIdentifier = "";
    
    public static string moreGamesLink = "www.lambentapps.com";

    public static string skipPackInAppIdentifier = "com.sunstorm.lightbulbs.skip";
    public static string removeAdInAppIdentifier = "com.sunstorm.lightbulbs.remove";
   

    public static string chartBoostID = "4e935fa15e2b94351400001a";
    public static string chartBoostSignature = "370b602e0f61c07580e4a07ad2bbd1abcef92a93";

    public static string leaderboardIdentifier = "com.sunstorm.myleaderboard";

    
}
