using UnityEngine;
using System.Collections;

public class GameFinishPopupScript : MonoBehaviour 
{
    GameUIController gameUIController;

    public GameObject featherRewardPopupPrefab;

    public UIPanel myUIPanel;

    public TextMesh distanceText;
    public TextMesh coinText;
    public TextMesh fuelText;
    public TextMesh totalScoreText;

    int totalScore;
    int tempScore = 0;
    int scrollStep = 100;
    int scrollingTime = 10;
    float interval = .02f;

	void Start () 
    {
        gameUIController = GameObject.Find("GUI Stuff").GetComponent<GameUIController>();

        distanceText.gameObject.active = false;
        coinText.gameObject.active = false;
        fuelText.gameObject.active = false;
        totalScoreText.gameObject.active = false;

        
	
	}

    int CalculateTotalScore()
    {
        tempScore = 0;

        totalScore = GameUIController.GetTotalScore();

        scrollStep = (int)(totalScore/((.6f / interval) * scrollingTime));

        return totalScore;

    }

    internal void ShowGameFinishPopup()
    {
        CalculateTotalScore();
        myUIPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        Invoke("DisplayDistanceText", 1f);
        Invoke("DisplayCoinText", 2f);
        Invoke("DisplayFuelText", 3f);
        Invoke("DisplayTotalScore", 4f);
    }

    void DisplayDistanceText()
    {
        distanceText.gameObject.active = true;
        distanceText.text = "Distance Travelled : " + ((int)LevelStats.distanceTravelled).ToString();
    }

    void DisplayCoinText()
    {
        coinText.gameObject.active = true;
        coinText.text = "Coins Collected  :" + LevelStats.numberOfCoinsCollected.ToString();
    }

    void DisplayFuelText()
    {
        fuelText.gameObject.active = true;
        fuelText.text = "Fuel Collected : " + LevelStats.numberOfFuelsCollected.ToString();
    }

   

    void DisplayTotalScore()
    {
        totalScoreText.gameObject.active = true;
        totalScoreText.text = "Total Score : " + tempScore.ToString();
        InvokeRepeating("ScrollTotalText", .2f, interval);
    }

    

    void ScrollTotalText()
    { 
        tempScore += scrollStep;

        if (tempScore >= totalScore)
        {
            tempScore = totalScore;
            CheckForFeatherReward();
            CancelInvoke("ScrollTotalText");
        }

        totalScoreText.text = "Total Score : " + tempScore.ToString();
    }

    GameObject featherPopup;

    private void CheckForFeatherReward()
    {
        print("Check for Feather Reward");

        if (LevelStats.rewardFeather)
        {
            featherPopup = (GameObject)Instantiate(featherRewardPopupPrefab, new Vector3(-50, 20, 4), Quaternion.identity);
            featherPopup.GetComponentInChildren<FeatherRewardPopup>().BringItForward();
        }
    }



    void NextLevelButtonClicked()
    {
        myUIPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        gameUIController.NextLevelButtonClicked();
    }

    void HomeButtonClicked()
    {
        myUIPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        gameUIController.HomeButtonClicked();
    }

    void PlayAgainButtonClicked()
    {
        myUIPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        gameUIController.PlayAgainButtonClicked();
    }
	
	
}
