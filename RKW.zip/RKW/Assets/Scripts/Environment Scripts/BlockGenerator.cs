using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BlockGenerator : MonoBehaviour 
{
    TextMesh blockNameText;

    public GameObject emptyBlock;
    public GameObject []coinBlockPrefab;
    public GameObject[] enemyBlockPrefab;
    public GameObject[] fuelBlockPrefab;
    public GameObject[] airCurrentBlockPrefab;

    List<GameObject> currentObjectList;
	
	void Start () 
    {

        blockNameText = GameObject.Find("Block Name Text").GetComponent<TextMesh>();
        currentObjectList = new List<GameObject>();
	
	}

    void ClearObjects()
    {
       // xPos = initialStartingXPos;
        for (int i = 0; i < currentObjectList.Count; i++)
        {
            Destroy((GameObject)currentObjectList[i]);
        }
        currentObjectList = new List<GameObject>();
    }

    internal void GenerateBlock()
    {
        return;

        ClearObjects();

        if (LevelStats.levelComplete == true)
        {
            GenerateEmptyBlock();
            return;
        }


        int val = Random.Range(1, 100);
        if (val < 20)
        {
            GenerateCoinPack();
        }
        else if (val >= 20 && val < 45)
        {
            GenerateEnemyBlock();
        }
        else if (val >= 45 && val < 55)
        {
            GenerateAirCurrentBlock();
          //  GenerateEnemyBlock();
        }
        else if (val >= 55 && val < 70)
        {
            GenerateAirCurrentBlock();
           // GenerateEnemyBlock();
        }
        else if (val >= 70 && val <= 100)
        {
            GenerateAirCurrentBlock();
        }
    }

    private void GenerateEmptyBlock()
    {
        Vector3 pos = new Vector3(0, 0, 0);

        tempObject = (GameObject)Instantiate(emptyBlock, pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

        blockNameText.text = tempObject.name;
    }
    
   
    GameObject tempObject;

    void GenerateAirCurrentBlock()
    {
        Vector3 pos = new Vector3(0, 0, 0);

        int index = Random.Range(0, airCurrentBlockPrefab.Length + 1);
        if (index >= airCurrentBlockPrefab.Length)
            index = airCurrentBlockPrefab.Length - 1;


        tempObject = (GameObject)Instantiate(airCurrentBlockPrefab[index], pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

        blockNameText.text = tempObject.name;
    }

    void GenerateEnemyBlock()
    {
        Vector3 pos = new Vector3(0, 0, 0);

        int index = Random.Range(0, enemyBlockPrefab.Length + 1);
        if (index >= enemyBlockPrefab.Length)
            index = enemyBlockPrefab.Length - 1;


        tempObject = (GameObject)Instantiate(enemyBlockPrefab[index], pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

        blockNameText.text = tempObject.name;
    }

    void GenerateCoinPack()
    {
        Vector3 pos = new Vector3(0, 0, 0);

        int index = Random.Range(0, coinBlockPrefab.Length + 1);
        if (index >= coinBlockPrefab.Length)
            index = coinBlockPrefab.Length - 1;


        tempObject = (GameObject)Instantiate(coinBlockPrefab[index], pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

        blockNameText.text = tempObject.name;
    }
	
	
}
