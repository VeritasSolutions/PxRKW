using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BlockGenerationNew : MonoBehaviour 
{

    TextMesh blockNameText;

    public GameObject emptyBlock;
    public GameObject[] coinBlockPrefab;
    public GameObject[] enemyBlockPrefab;
    public GameObject[] fuelBlockPrefab;
    public GameObject[] airCurrentBlockPrefab;

    public List<GameObject> currentObjectList;

    int blockCounter = 0;
    float startingXPos = 0;
    float currentXPos = 0;
    float blockLength = 32.5f;

    int totalNumberOfBlocks = 20;

    void Start()
    {

        blockNameText = GameObject.Find("Block Name Text").GetComponent<TextMesh>();
        currentObjectList = new List<GameObject>();
        

        

    }

    internal void GenerateFirstBlock()
    {
        startingXPos = GameObject.Find("Kiwi").transform.position.x - blockLength;
        currentXPos = startingXPos;

        GenerateBlock();
    }

    void ClearObjects() //0 = previous , 1 = current , 2 = comming
    {
        if (currentObjectList.Count < 3)
            return;
        
        
        Destroy((GameObject)currentObjectList[0]);
        currentObjectList.RemoveAt(0);

      //  currentObjectList = new List<GameObject>();
    }

    internal bool emptyBlockGenerated = false;

    internal void GenerateBlock()
    {

        if (blockCounter >= totalNumberOfBlocks)
        {
            emptyBlockGenerated = true;
            GenerateEmptyBlock();

            currentObjectList.Add(tempObject);
            ClearObjects();
            
            return;
        }
        
        int val = Random.Range(1, 100);

        

        if (val < 20)
        {
            GenerateAirCurrentBlock();
        }
        else if (val >= 20 && val < 45)
        {
            GenerateAirCurrentBlock();
        }
        else if (val >= 45 && val < 55)
        {
            GenerateAirCurrentBlock();            
        }
        else if (val >= 55 && val < 70)
        {
            GenerateAirCurrentBlock();
        }
        else if (val >= 70 && val <= 100)
        {
            GenerateAirCurrentBlock();
        }

        currentObjectList.Add(tempObject);
        ClearObjects();

        blockCounter++;
        currentXPos = startingXPos - blockCounter * blockLength;
    }

    private void GenerateEmptyBlock()
    {
        Vector3 pos = new Vector3(currentXPos, 0, 10);

        tempObject = (GameObject)Instantiate(emptyBlock, pos, Quaternion.identity);
        

        blockNameText.text = tempObject.name;
    }


    GameObject tempObject;

    void GenerateAirCurrentBlock()
    {
        Vector3 pos = new Vector3(currentXPos, 0, 10);

        int index = Random.Range(0, airCurrentBlockPrefab.Length + 1);
        if (index >= airCurrentBlockPrefab.Length)
            index = airCurrentBlockPrefab.Length - 1;


        tempObject = (GameObject)Instantiate(airCurrentBlockPrefab[index], pos, Quaternion.identity);
       

        blockNameText.text = tempObject.name;
    }

    void GenerateEnemyBlock()
    {
        Vector3 pos = new Vector3(currentXPos, 0, 10);

        int index = Random.Range(0, enemyBlockPrefab.Length + 1);
        if (index >= enemyBlockPrefab.Length)
            index = enemyBlockPrefab.Length - 1;


        tempObject = (GameObject)Instantiate(enemyBlockPrefab[index], pos, Quaternion.identity);
        

        blockNameText.text = tempObject.name;
    }

    void GenerateCoinPack()
    {
        Vector3 pos = new Vector3(currentXPos, 0, 10);

        int index = Random.Range(0, coinBlockPrefab.Length + 1);
        if (index >= coinBlockPrefab.Length)
            index = coinBlockPrefab.Length - 1;


        tempObject = (GameObject)Instantiate(coinBlockPrefab[index], pos, Quaternion.identity);       

        blockNameText.text = tempObject.name;
    }
}
