using UnityEngine;
using System.Collections;

public class Frame : MonoBehaviour 
{
    //public GameObject startingZigZag;
    public GameObject []endingZigZag;
    GameObject parentZigZag;

    public GameObject leftBackGround;
    public GameObject rightBackGround;
    GameObject leftInner;

    GameObject topCollider;
    GameObject topSkyCollider;

    public static bool stopEnvironment = false;

	
	void Start () 
    {
        leftInner = GameObject.Find("Left Inner");
        topCollider = GameObject.Find("Top");
        topSkyCollider = GameObject.Find("Sky Top");

        parentZigZag = endingZigZag[0].transform.parent.gameObject;
        stopEnvironment = false;

        leftBackGround.active = false;
        rightBackGround.active = false;

        for (int i = 0; i < endingZigZag.Length; i++)
        {
            endingZigZag[i].active = false;
        }
        
	
	}

    internal void HideRightLeftStuffs()
    {
        leftBackGround.active = false;
        rightBackGround.active = false;
    }

    internal void ShowRightLeftStuffs()
    {
        leftBackGround.active = true;
        rightBackGround.active = true;
    }

    internal void ShowLeftStuffs()
    {
        leftBackGround.active = true;
        leftInner.active = false;
    }

    internal void EnableEndMask()
    {
        topCollider.active = false;
        topSkyCollider.active = false;
        for (int i = 0; i < endingZigZag.Length; i++)
        {
            endingZigZag[i].active = true;
        }  
        
    }
}
