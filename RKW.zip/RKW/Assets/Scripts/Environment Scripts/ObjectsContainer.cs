using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ObjectsContainer : MonoBehaviour 
{

    enum ObjectType
    {
        Enemy,
        Star,

    };

    public GameObject []enemyPrefabs;
    public GameObject[] airCurrentPrefabs;
    public GameObject[] coinPackPrefabs;
    public GameObject fuelPrefab;

    public GameObject superCoinPrefab;
    //public GameObject magnetPrefab;

    public Transform startTransform;
    public Transform endTransform;
    public Transform backObject;

    int numberOFObjects = 5;
    float gap = 0;

    float xPos = 0;
    float zPos = 0;

    GameObject tempObject;
    float initialStartingXPos;

    
    List<GameObject> currentObjectList;

    public bool generateObjectIntheBeginning = true;
    
    
	void Start ()
    {
        currentObjectList = new List<GameObject>();
        gap = (endTransform.localPosition.x - startTransform.localPosition.x) / (numberOFObjects-1);
     //   print(gap);
        xPos = startTransform.localPosition.x;
        initialStartingXPos = xPos;

        Destroy(endTransform.gameObject);
        Destroy(startTransform.gameObject);
      

        if(generateObjectIntheBeginning)
            GenerateObjects();
        
        
	
	}

    void ClearObjects()
    {
        xPos = initialStartingXPos;
        for (int i = 0; i < currentObjectList.Count; i++)
        {
            Destroy((GameObject)currentObjectList[i]);
        }
        currentObjectList = new List<GameObject>();
    }

    bool coinGenerated = false;

    internal void GenerateObjects()
    {
        return;

        ClearObjects();

        for (int i = 0; i < numberOFObjects; i++)
        {
            if (i == numberOFObjects / 2)
                GenerateCoinPack();
            else
            {
                int val = Random.Range(1, 100);
                if (val < 20)
                {
                    GenerateEnemy();
                }
                else if (val >= 20 && val < 45)
                {
                    GenerateFuelPack();
                }
                else if (val >= 45 && val < 55)
                {

                    GenerateSuperCoin();
                }
                else if (val >= 55 && val < 80)
                {
                    GenerateEnemy();
                }
                else if (val >= 80 && val <= 100)
                {
                    GenerateAirCurrent();
                }

                
            }
            xPos += gap;
        }
    }

    void GenerateSuperCoin()
    {

        float yPos = Random.Range(-2f, 2.4f);

        Vector3 pos = new Vector3(xPos, yPos, zPos);

        tempObject = (GameObject)Instantiate(superCoinPrefab, pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

    }


    void GenerateEnemy()
    {
        float yPos = Random.Range(-2f, 2.4f);


        Vector3 pos = new Vector3(xPos, yPos, zPos);

        //   if (Random.value > .5f)
        {
            tempObject = (GameObject)Instantiate(enemyPrefabs[0], pos, Quaternion.identity);
            tempObject.transform.parent = transform;
            tempObject.transform.localPosition = pos;
            currentObjectList.Add(tempObject);
        }
    }

    void GenerateCoinPack()
    {
        float yPos = Random.Range(0, 0);

        Vector3 pos = new Vector3(xPos, yPos, zPos);

        int index = Random.Range(0, coinPackPrefabs.Length + 1);
        if (index >= coinPackPrefabs.Length)
            index = coinPackPrefabs.Length - 1;


        tempObject = (GameObject)Instantiate(coinPackPrefabs[index], pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

    }


    void GenerateFuelPack()
    {

        
        float yPos = Random.Range(-2f, 2.4f);
        

        Vector3 pos = new Vector3(xPos, yPos, zPos);

      //  if (Random.value > .5f)
        {
            tempObject = (GameObject)Instantiate(fuelPrefab, pos, Quaternion.identity);
            tempObject.transform.parent = transform;
            tempObject.transform.localPosition = pos;
            currentObjectList.Add(tempObject);
        }
    }
   

    void GenerateAirCurrent()
    {
        float yPos = Random.Range(-1f, 2f);
        yPos = .5f;
        Vector3 pos = new Vector3(xPos, yPos, zPos);

        int index = Random.Range(0, airCurrentPrefabs.Length);

        if (index >= airCurrentPrefabs.Length)
            index = airCurrentPrefabs.Length - 1;


        tempObject = (GameObject)Instantiate(airCurrentPrefabs[index], pos, Quaternion.identity);
        tempObject.transform.parent = transform;
        tempObject.transform.localPosition = pos;
        currentObjectList.Add(tempObject);

    }
}
