using UnityEngine;
using System.Collections;

public class StarParticlesAudioManager : MonoBehaviour {

    public AudioSource[] audioSources;
    int index = 0;

    bool play = true;

    internal void PlayStarSound(int numberOfStartParticlesInScene)
    {
      //  if (!play)
      //      return;

      //  play = false;
     //   Invoke("EnablePlay", .1f);

    //    if (audioSources[index].isPlaying)
    //        return;

        audioSources[index++].Play();

        if (index >= audioSources.Length)
            index = 0;
    }

    void EnablePlay()
    {
        play = true;
    }
}
