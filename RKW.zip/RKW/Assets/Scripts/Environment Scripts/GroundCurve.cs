using UnityEngine;
using System.Collections;

public class GroundCurve : MonoBehaviour {

    private IRageSpline rageSpline;

    float initialYPosOfNode;

    void Awake()
    {
        // Store the instance of RageSpline to avoid calling it every frame for speed/convenience.
        // Cast to IRageSpline for cleaner API access
        rageSpline = GetComponent(typeof(RageSpline)) as IRageSpline;
    }

	void Start () 
    {

        if (rageSpline.GetPointCount() > 0)
            initialYPosOfNode = rageSpline.GetPosition(0).y;

        RefresCurvature();
	
	}

    internal void RefresCurvature()
    {

        for (int index = 1; index < rageSpline.GetPointCount() - 1; index++)
        {
            Vector3 currentPositon = rageSpline.GetPosition(index);
            Vector3 initialPosition = new Vector3(currentPositon.x,initialYPosOfNode,currentPositon.z);
            rageSpline.SetPoint(index, initialPosition);
        }


        int sign = 1;
        if (Random.value > .5f)
            sign = 1;
        else
            sign = -1;



        for (int index = 1; index < rageSpline.GetPointCount() - 1; index++)
        {
            Vector3 oldPosition = rageSpline.GetPosition(index);
            sign = -sign;

            float val = Random.Range(.1f, .3f) * sign;
            
            Vector3 shakeVector = new Vector3(val, val, 0f);
            rageSpline.SetPoint(index, oldPosition + shakeVector);
        }

        rageSpline.RefreshMesh(true, true, true);
    }
	
	
}
