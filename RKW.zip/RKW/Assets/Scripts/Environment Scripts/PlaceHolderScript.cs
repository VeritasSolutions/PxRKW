using UnityEngine;
using System.Collections;

public class PlaceHolderScript : MonoBehaviour {

    public GameObject placeHolder;
    GameObject tempObject;

	void Start () 
    {
        tempObject = (GameObject)Instantiate(placeHolder, transform.position, Quaternion.identity);
        tempObject.transform.parent = transform.parent;
        Destroy(gameObject);

	
	}
	
	
}
