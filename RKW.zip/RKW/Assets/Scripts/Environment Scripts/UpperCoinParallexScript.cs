using UnityEngine;
using System.Collections;

public class UpperCoinParallexScript : MonoBehaviour {

    public int numberOfObjects = 3;

    float[] initialObjectPositions;

    public Transform[] objects;

    public float percentageSpeed = 100f;

    
    string gameObjectTag;



    void Start()
    {

        gameObjectTag = gameObject.tag;

        objects = new Transform[numberOfObjects];
        initialObjectPositions = new float[numberOfObjects];

        for (int i = 0; i < numberOfObjects; i++)
        {
            objects[i] = transform.GetChild(i);

        }

        Transform temp;

        for (int i = 0; i < numberOfObjects; i++)
        {
            for (int j = 0; j < numberOfObjects - 1; j++)
            {
                if (objects[j].position.x < objects[j + 1].position.x)
                {
                    temp = objects[j + 1];

                    objects[j + 1] = objects[j];
                    objects[j] = temp;
                }
            }
        }

        for (int i = 0; i < numberOfObjects; i++)
        {
            initialObjectPositions[i] = objects[i].position.x;
            
        }

        initialObject0Position = initialObjectPositions[0];

        Destroy(objects[objects.Length - 1].gameObject);

        speed = KiwiSpeedController.kiwiCurrentSpeed * percentageSpeed * .01f;

        Optimise();

        InvokeRepeating("Optimise", .1f, .1f);

       // InvokeRepeating("FixedUpdate1", .1f, .1f);

    }

    float initialObject0Position;

    float speed = 0;

    void Optimise()
    {
        speed = KiwiSpeedController.kiwiCurrentSpeed * percentageSpeed * .01f;

    }



    void FixedUpdate()
    {
        if (CameraZoom.isCameraInOriginalState == true)
            return;

        if (Frame.stopEnvironment)
            return;

        if (objects[0].position.x >= initialObject0Position)
        {
            SendToBack();
        }

        for (int i = 0; i < numberOfObjects - 1; i++)
        {
            objects[i].position = new Vector3(objects[i].position.x + speed * Time.deltaTime, objects[i].position.y, objects[i].position.z);
        }


    }



    private void SendToBack()
    {
        objects[0].position = new Vector3(initialObjectPositions[numberOfObjects - 1], objects[0].position.y, objects[0].position.z);

        objects[0].GetComponent<UpperCoinScript>().Refresh();
        Transform temp;

        temp = objects[0];

        int i = 0;
        for (; i < numberOfObjects - 2; i++)
        {
            objects[i] = objects[i + 1];
        }

        objects[i] = temp;

        float error = objects[0].position.x - initialObjectPositions[1];
        objects[numberOfObjects - 2].position += new Vector3(error, 0, 0);

        


    }
}
