using UnityEngine;
using System.Collections;

public class RandomGroundSetting : MonoBehaviour {

	
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    internal void GenerateCurvature(Transform groundTransform)
    {
        GroundCurve groundCurve = groundTransform.GetComponentInChildren<GroundCurve>();
        groundCurve.RefresCurvature();
    }
}
