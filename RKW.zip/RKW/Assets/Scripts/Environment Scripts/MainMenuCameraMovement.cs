using UnityEngine;
using System.Collections;

public class MainMenuCameraMovement : MonoBehaviour 
{
    float cameraTransactionDuration = .2f;
    public static UIManager uiManager;

    public UIPanel faderPanel;

    Vector3 newCameraPosition = Vector3.zero;

    void Start()
    {
        faderPanel = transform.FindChild("Fader").GetComponent<UIPanel>();
        uiManager = GameObject.Find("UIManager").GetComponent<UIManager>();
    }

    public void MoveTo(Vector3 newPosition, float delay)
    {
        newCameraPosition = newPosition;
        Invoke("MoveTo", delay);
    }

    public void MoveTo()
    {
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        Invoke("MoveToStart", cameraTransactionDuration);
    }

    public void MoveTo(Vector3 newPosition)
    {
        newCameraPosition = newPosition;

        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        Invoke("MoveToStart", cameraTransactionDuration);
    }


    void MoveToStart()
    {
        uiManager.blockInput = false;
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        transform.position = new Vector3(newCameraPosition.x, newCameraPosition.y, transform.position.z);

    }

	
}
