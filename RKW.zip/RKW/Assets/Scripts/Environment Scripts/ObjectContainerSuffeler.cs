using UnityEngine;
using System.Collections;

public class ObjectContainerSuffeler : MonoBehaviour {

    
	internal void RegenerateObjects(Transform currentObjectTransform)
    {
        currentObjectTransform.GetComponent<BlockGenerator>().GenerateBlock();
       // currentObjectTransform.GetComponent<ObjectsContainer>().GenerateObjects();
    }
}
