using UnityEngine;
using System.Collections;

public class ProceduralGround : MonoBehaviour {

    private IRageSpline rageSpline;

    public RageSpline myRageSpline;

    float initialYPosOfNode;

    void Awake()
    {
        // Store the instance of RageSpline to avoid calling it every frame for speed/convenience.
        // Cast to IRageSpline for cleaner API access
        rageSpline = GetComponent(typeof(RageSpline)) as IRageSpline;
    }

    void Start()
    {

        if (rageSpline.GetPointCount() > 0)
            initialYPosOfNode = rageSpline.GetPosition(0).y;

        myRageSpline.physics = RageSpline.Physics.None;
        myRageSpline.RefreshPhysics();

        //RefresCurvature();

        InvokeRepeating("TogglePhysics", 1, 1);

       // AddPoint();

    }
    bool toggle = true;

    void TogglePhysics()
    {
        if (toggle)
        {
            myRageSpline.physics = RageSpline.Physics.None;
        }
        else
        {
            myRageSpline.physics = RageSpline.Physics.Boxed;
        }

        myRageSpline.RefreshPhysics();
        toggle = !toggle;
    }

    int pos = -20;

    ArrayList pointsPosition;

    private void AddPoint()
    {
        pointsPosition = new ArrayList();

        int numberOfPoints = rageSpline.GetPointCount();

        for (int i = 0; i < gameObject.transform.GetChildCount(); i++)
        {
            Destroy(gameObject.transform.GetChild(i).gameObject);
        }

        for (int index = 0; index < rageSpline.GetPointCount(); index++)
        {
            Vector3 currentPositon = rageSpline.GetPosition(index);

            rageSpline.SetPoint(index, currentPositon - new Vector3(6, 0, 0));

            print(currentPositon);
           // Vector3 initialPosition = new Vector3(currentPositon.x, initialYPosOfNode, currentPositon.z);
           // rageSpline.SetPoint(index, initialPosition);
        }

        rageSpline.RefreshMesh(true, true, true);
    }

    internal void RefresCurvature()
    {

        for (int index = 1; index < rageSpline.GetPointCount() - 1; index++)
        {
            Vector3 currentPositon = rageSpline.GetPosition(index);
            Vector3 initialPosition = new Vector3(currentPositon.x, initialYPosOfNode, currentPositon.z);
            rageSpline.SetPoint(index, initialPosition);
        }


        int sign = 1;
        if (Random.value > .5f)
            sign = 1;
        else
            sign = -1;



        for (int index = 1; index < rageSpline.GetPointCount() - 1; index++)
        {
            Vector3 oldPosition = rageSpline.GetPosition(index);
            sign = -sign;

            float val = Random.Range(.1f, .3f) * sign;
            Vector3 shakeVector = new Vector3(val, val, 0f);
            rageSpline.SetPoint(index, oldPosition + shakeVector);
        }

        rageSpline.RefreshMesh(true, true, true);
    }
}
