using UnityEngine;
using System.Collections;

public class ObjectParallexScript : MonoBehaviour 
{
    public int numberOfObjects = 3;

    float []initialObjectPositions;

    public Transform[] objects;

    public float percentageSpeed = 100f;

    

    RandomObjectSetting randomObjectSetting;
    RandomGroundSetting randomGroundSetting;
    ObjectContainerSuffeler objectContainerSuffeler;

    string gameObjectTag;

    KiwiSpeedController kiwiSpeedController;


    void Awake()
    {
        if (Game.currentZoneIndex == -1)
        {
            Game.currentZoneIndex = 0;
            Game.currentZonelevelIndex = 0;
        }
    }

    void AssignEnvironmentSpeed()
    {        

        if (gameObject.name == "Front Ground Manager")
        {
                percentageSpeed = GameVariables.zonesGroundSpeed[Game.currentZoneIndex] * 100;
        }

        else if (gameObject.name == "Front Mountain Manager")
        {
                percentageSpeed = GameVariables.zonesFrontMountainSpeed[Game.currentZoneIndex] * 100;
        }

        else if (gameObject.name == "Back Mountain Manager")
        {
                percentageSpeed = GameVariables.zonesBackMountainSpeed[Game.currentZoneIndex] * 100;
        }

        else if (gameObject.name == "Cloud Manager")
        {
                percentageSpeed = GameVariables.zonesCloudSpeed[Game.currentZoneIndex] * 100;
        }

        else if (gameObject.name == "Atmosphere Manager")
        {
            percentageSpeed = GameVariables.zonesAtmosphereSpeed[Game.currentZoneIndex] * 100;
        }
    }
	
	void Start () 
    {
        AssignEnvironmentSpeed();

        kiwiSpeedController = GameObject.Find("Kiwi").GetComponent<KiwiSpeedController>();

        gameObjectTag = gameObject.tag;

        randomObjectSetting=GetComponent<RandomObjectSetting>();
        objectContainerSuffeler = GetComponent<ObjectContainerSuffeler>();

        objects = new Transform[numberOfObjects];
        initialObjectPositions = new float[numberOfObjects];        

        for (int i = 0; i < numberOfObjects; i++)
        {
            objects[i] = transform.GetChild(i);
            
        }

        Transform temp;

        for (int i = 0; i < numberOfObjects; i++)
        {
            for (int j = 0; j < numberOfObjects - 1; j++)
            {
                if (objects[j].position.x < objects[j + 1].position.x)
                {
                    temp = objects[j + 1];

                    objects[j + 1] = objects[j];
                    objects[j] = temp;
                }
            }
        }

        for (int i = 0; i < numberOfObjects; i++)
        {
            initialObjectPositions[i] = objects[i].position.x;
            //objectScript[i] = objects[i].GetComponent<ParallexObjectScript>();
        }

        initialObject0Position = initialObjectPositions[0];

        Destroy(objects[objects.Length - 1].gameObject);

      //  speed = KiwiSpeedController.kiwiCurrentSpeed * percentageSpeed * .01f;

        Optimise();

        InvokeRepeating("Optimise", .1f, .1f);

      //  InvokeRepeating("FixedUpdate1", 0, .02f);
	
	}

    float initialObject0Position;

    float speed = 0;

    void Optimise()
    {
        speed = KiwiSpeedController.kiwiCurrentSpeed * percentageSpeed * .01f;


        if (gameObjectTag == "Mesh Environment")
        {
            for (int i = 1; i < objects.Length - 2; i++)
            {
                objects[i].gameObject.active = true;
            }

            if (CameraZoom.isCameraInOriginalState && Game.gameState != Game.GameState.GameOver)
            {
                objects[0].gameObject.active = false;
                objects[objects.Length - 2].gameObject.active = false;
            }
            else
            {
                objects[0].gameObject.active = true;
                objects[objects.Length - 2].gameObject.active = true;
            }
        }
        else if (gameObjectTag == "Sprite Environment")
        {
            for (int i = 0; i < objects.Length -2 ; i++)
            {
                objects[i].GetComponent<ParallexObjectScript>().Activate();                
            }

            if (CameraZoom.isCameraInOriginalState && Game.gameState != Game.GameState.GameOver)
            {
                objects[objects.Length - 2].GetComponent<ParallexObjectScript>().DeActivate();
            }
            else
            {
                objects[objects.Length - 2].GetComponent<ParallexObjectScript>().Activate();
            }
        }


    }



    void FixedUpdate()
    {
       // return;

        if (Frame.stopEnvironment)
            return;

        if (Game.gameState == Game.GameState.Finish)
        {
            kiwiSpeedController.miscSpeed = -KiwiSpeedController.initialSpeed;
        }

        if (objects[0].position.x >= initialObject0Position)
        {            
             SendToBack();
        }

        for (int i = 0; i < numberOfObjects - 1; i++)
        {
            //objects[i].position = new Vector3(objects[i].position.x + speed * Time.deltaTime, objects[i].position.y, objects[i].position.z);
            objects[i].position += new Vector3(speed * Time.deltaTime, 0, 0);
        }        
	}

    

    private void SendToBack()
    {
        objects[0].position = new Vector3(initialObjectPositions[numberOfObjects -1], objects[0].position.y, objects[0].position.z);

        Transform temp;

        temp = objects[0];

        int i = 0;
        for (; i < numberOfObjects - 2; i++)
        {
            objects[i] = objects[i + 1];
        }

        objects[i] = temp;

        float error = objects[0].position.x - initialObjectPositions[1];
        objects[numberOfObjects - 2].position += new Vector3(error, 0, 0);

        if (randomObjectSetting)
        {
            randomObjectSetting.ReSize(objects[i]);
        }
        else if (randomGroundSetting)
            randomGroundSetting.GenerateCurvature(objects[i]);

        else if (objectContainerSuffeler)
        {
            objectContainerSuffeler.RegenerateObjects(objects[i]);
        }
       
        
    }
}
