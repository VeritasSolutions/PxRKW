using UnityEngine;
using System.Collections;

public class RandomObjectSetting : MonoBehaviour 
{

    PackedSprite[] objectsSprites;
    int numberOfAnimations;

    float initialWidth;
    float initialHeight;

    float initialYPosition;

    string objectTag;
	
	void Start () 
    {
        objectsSprites = transform.GetComponentsInChildren<PackedSprite>();

        if (objectsSprites.Length > 0)
        {
            numberOfAnimations=objectsSprites[0].animations.Length;
            initialWidth = objectsSprites[0].transform.localScale.x;
            initialHeight = objectsSprites[0].transform.localScale.y;
            initialYPosition = objectsSprites[0].transform.position.y;
            objectTag = objectsSprites[0].tag;
        }

        if (objectTag == "Cloud")
        {
            for (int i = 0; i < objectsSprites.Length; i++)
            {
                ReSizeCloud(objectsSprites[i].transform);
            }
        }

        if (objectTag == "Mountain")
        {
            for (int i = 0; i < objectsSprites.Length; i++)
            {
                ReSizeMountain(objectsSprites[i].transform);
            }
        }
	
	}


    internal void ReSize(Transform currentObjectTransform)
    {
        if (currentObjectTransform.tag == "Cloud")
            ReSizeCloud(currentObjectTransform);

        else if (currentObjectTransform.tag == "Mountain")
            ReSizeMountain(currentObjectTransform);

        
    }

    private void ReSizeMountain(Transform currentObjectTransform)
    {
        PackedSprite currentSprite;
        if (currentObjectTransform.GetComponent<PackedSprite>())
        {
            currentSprite = currentObjectTransform.GetComponent<PackedSprite>();
            if (Random.value > .5f)
                currentSprite.winding = SpriteRoot.WINDING_ORDER.CCW;
            else
                currentSprite.winding = SpriteRoot.WINDING_ORDER.CW;

            int val = Random.Range(0, numberOfAnimations);

            if (val < numberOfAnimations)
                currentSprite.PlayAnim(val);

            float randomVal = Random.Range(-initialHeight / 5f, initialHeight / 5f);

            currentObjectTransform.localScale = new Vector3(initialWidth + randomVal, initialHeight + randomVal, currentObjectTransform.localScale.z);
        }
    }

    private void ReSizeCloud(Transform currentObjectTransform)
    {
        PackedSprite currentSprite;
        if (currentObjectTransform.GetComponent<PackedSprite>())
        {
            currentSprite = currentObjectTransform.GetComponent<PackedSprite>();

            if (Random.value > .5f)
                currentSprite.winding = SpriteRoot.WINDING_ORDER.CCW;
            else
                currentSprite.winding = SpriteRoot.WINDING_ORDER.CW;

            int val = Random.Range(0, numberOfAnimations);
            

            if (val < numberOfAnimations)
                currentSprite.PlayAnim(val);

            float randomVal = Random.Range(-initialHeight / 3f, initialHeight / 3f);

            currentObjectTransform.localScale = new Vector3(initialWidth + randomVal, initialHeight + randomVal, currentObjectTransform.localScale.z);

            randomVal = Random.Range(-initialHeight / 5f, initialHeight / 5f);

            currentObjectTransform.position = new Vector3(currentObjectTransform.position.x, initialYPosition + randomVal, currentObjectTransform.position.z);
        }
    }
	
	
	
}

