using UnityEngine;
using System.Collections;

public class ParallexObjectScript : MonoBehaviour 
{
   GameObject[] childObjects;

    Vector3[] objectsPosition;

    int numberOfObjects;

    bool destroyObject = true;

    Transform environmentTransform;
    Transform parentTransform;

    bool isActivated = true;

	void Start () 
    {
        numberOfObjects = transform.GetChildCount();
        childObjects = new GameObject[numberOfObjects];
        objectsPosition = new Vector3[numberOfObjects];
        for (int i = 0; i < numberOfObjects; i++)
        {
            childObjects[i] = transform.GetChild(i).gameObject;
            objectsPosition[i] = childObjects[i].transform.localPosition;
           
        }
        environmentTransform = transform.parent.parent;
        parentTransform = transform.parent;
	
	}

    internal void Activate()
    {
        if (isActivated)
            return;

        isActivated = true;

        for (int i = 0; i < numberOfObjects; i++)
        {
            if (destroyObject)
            {
                childObjects[i].transform.parent = transform;
                childObjects[i].transform.localPosition = objectsPosition[i];
            }
            childObjects[i].active = true;
        }
    }

    internal void DeActivate()
    {
        if (!isActivated)
            return;

        isActivated = false;

        for (int i = 0; i < numberOfObjects; i++)
        {
            if(destroyObject)
                childObjects[i].transform.parent = environmentTransform;

            childObjects[i].active = false;
        }

        
    }
}

