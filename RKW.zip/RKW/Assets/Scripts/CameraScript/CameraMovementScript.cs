using UnityEngine;
using System.Collections;

public class CameraMovementScript : MonoBehaviour {

    
    float topColliderYPos;
    Transform myTransform;
    Transform birdTransform;
    float birdInitialXPosition;


    float cameraUPSpeed = 5f;
    
    float birdBackToInitialSpeed = 1f;

    float maxCameraHeight = 4.2f;

    float maxBirdHeight = 11f;

    float backToZeroCameraSpeed = 3;

    Transform kiwiCameraTransform;

	void Start () 
    {
        kiwiCameraTransform = GameObject.Find("Kiwi Camera").transform;
        myTransform = transform;
        birdTransform = GameObject.FindGameObjectWithTag("Kiwi").transform;
        birdInitialXPosition = birdTransform.position.x;
        this.enabled = false;
	}

    Vector3 targetTransform;
	
	void FixedUpdate ()
    {
        if (BirdStateScript.birdState == BirdStateScript.BirdState.None)
        {
            targetTransform = new Vector3(myTransform.position.x, 0, myTransform.position.z);
            myTransform.position = Vector3.Lerp(myTransform.position, targetTransform, backToZeroCameraSpeed * Time.deltaTime);
            kiwiCameraTransform.position = new Vector3(kiwiCameraTransform.position.x, myTransform.position.y, kiwiCameraTransform.position.z);

            if (myTransform.position.y < .01f)
            {
                this.enabled = false;
            }

           // targetTransform = new Vector3(myTransform.position.x, 0, myTransform.position.z);
          //  myTransform.position = Vector3.Lerp(myTransform.position, targetTransform, cameraUPSpeed * Time.deltaTime);
          //  return;
        }

        float cameraHeight = 0;

        cameraHeight = maxCameraHeight * birdTransform.position.y / maxBirdHeight;
       // cameraHeight = maxCameraHeight;

        if (BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyGoingUp || BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingUp)
        {
            targetTransform = new Vector3(myTransform.position.x, cameraHeight, myTransform.position.z);
            myTransform.position = Vector3.Lerp(myTransform.position, targetTransform, cameraUPSpeed * Time.deltaTime);
        }

        if (BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingDown)
        {
            targetTransform = new Vector3(myTransform.position.x, cameraHeight, myTransform.position.z);
            myTransform.position = Vector3.Lerp(myTransform.position, targetTransform, cameraUPSpeed * Time.deltaTime);
        }

        if (BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingDown)
        {
          //  birdTransform.position = Vector3.Lerp(birdTransform.position, new Vector3(birdInitialXPosition, birdTransform.position.y, birdTransform.position.z), birdBackToInitialSpeed * Time.deltaTime);
        }

        kiwiCameraTransform.position = new Vector3(kiwiCameraTransform.position.x, myTransform.position.y, kiwiCameraTransform.position.z);
	
	}

    internal void RevertCameraMovement()
    {
        BirdStateScript.birdState = BirdStateScript.BirdState.None;
    }

}
