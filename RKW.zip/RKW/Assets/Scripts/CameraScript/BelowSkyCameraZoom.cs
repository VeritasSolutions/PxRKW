using UnityEngine;
using System.Collections;

public class BelowSkyCameraZoom : MonoBehaviour 
{

    float maxCameraSize = 5f;
    float maxCameraHeight = 1.1f;
    Camera mainCamera;
    Transform mainCameraTransform;

    Frame frameScript;
    float cameraSize;

    bool zoomCamera = false;

    float backToZeroCameraSpeed = 2f;
    float cameraZoomSpeed = 2f;

    float cameraUPSpeed = 2f;

    void Start()
    {
        frameScript = GameObject.Find("Environment Frame").GetComponent<Frame>();
        CameraZoom.isCameraInOriginalState = true;

        mainCamera = camera;
        mainCameraTransform = mainCamera.transform;

        this.enabled = false;
      //  Invoke("StartZoomEffect", 2f);
    }

    bool getCameraToZero = false;

    void Update()
    {
        if (getCameraToZero)
        {
            mainCamera.orthographicSize = Mathf.MoveTowards(mainCamera.orthographicSize, 3.6f, backToZeroCameraSpeed * Time.deltaTime);
            mainCameraTransform.position = Vector3.MoveTowards(mainCameraTransform.position, new Vector3(mainCameraTransform.position.x, 0, mainCameraTransform.position.z), cameraUPSpeed * Time.deltaTime);
            if (mainCamera.orthographicSize == 3.6f && mainCameraTransform.position.y == 0)
            {                
                frameScript.HideRightLeftStuffs();
                CameraZoom.isCameraInOriginalState = true;
                getCameraToZero = false;
                this.enabled = false;
            }
        }

        if (!zoomCamera)
            return;

        mainCamera.orthographicSize = Mathf.MoveTowards(mainCamera.orthographicSize, maxCameraSize, cameraZoomSpeed * Time.deltaTime);
        mainCameraTransform.position = Vector3.MoveTowards(mainCameraTransform.position, new Vector3(mainCameraTransform.position.x, maxCameraHeight, mainCameraTransform.position.z), cameraUPSpeed * Time.deltaTime);
        if (maxCameraSize - mainCamera.orthographicSize < .1f)
        {
            zoomCamera = false;
            getCameraToZero = true;
        }


    }


    internal void StartZoomEffect()
    {
        frameScript.ShowRightLeftStuffs();

        CameraZoom.isCameraInOriginalState = false;
        getCameraToZero = false;

        zoomCamera = true;


    }
}
