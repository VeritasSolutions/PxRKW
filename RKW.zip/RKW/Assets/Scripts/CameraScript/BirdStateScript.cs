using UnityEngine;
using System.Collections;

public class BirdStateScript : MonoBehaviour {

    public enum BirdState
    {
        None,
        BelowSkyGoingUp,
        AboveSkyGoingUp,
        AboveSkyGoingDown,
        BelowSkyGoingDown,
        BelowSkyNotGoingUp

    };

    Transform birdTransform;
    Rigidbody birdRigidBody;

    public static BirdState birdState = BirdState.None;

    public static bool hasReachedTop = false;

    bool trackBird = false;

    BoxCollider topCollider;    
    Transform topColliderTransform;

    BoxCollider innerLeftCollider;
    Transform innerLeftTransform;

    public BirdState tempBirdState;
    KiwiSpeedController kiwiSpeedController;

    public static float gravityDecreasingFactor = .8f;
    Kiwi kiwiScript;


	void Start () 
    {
        
        birdTransform = GameObject.FindGameObjectWithTag("Kiwi").transform;
        birdRigidBody = birdTransform.rigidbody;

        topColliderTransform = GameObject.Find("Top").transform;
        topCollider = topColliderTransform.GetComponent<BoxCollider>();

        innerLeftTransform = GameObject.Find("Left Inner").transform;
        innerLeftCollider = innerLeftTransform.GetComponent<BoxCollider>();

        kiwiSpeedController = birdTransform.GetComponent<KiwiSpeedController>();
        kiwiScript = GameObject.Find("Kiwi").GetComponent<Kiwi>();

        
	
	}


    void TrackBird() 
    {
        tempBirdState = birdState;
        if (!trackBird)
            return;

        if (birdState == BirdState.BelowSkyGoingUp)
        {
            if (birdTransform.position.y > topColliderTransform.position.y)
            {
                birdState = BirdState.AboveSkyGoingUp;
               // Time.timeScale = .8f;
            }
        }

        if (birdState == BirdState.AboveSkyGoingUp)
        {

            if (birdRigidBody.velocity.y < 0)
            {
                Physics.gravity = Physics.gravity * gravityDecreasingFactor;
              //  kiwiScript.rigidbody.useGravity = false;
                birdState = BirdState.AboveSkyGoingDown;
                kiwiScript.StartShutingDownJetPack();
               // kiwiScript.DeActivateWorldTrail();
            }
        }

        if (birdState == BirdState.AboveSkyGoingDown)
        {
            if (birdTransform.position.y < topColliderTransform.position.y)
            {
                Physics.gravity = Physics.gravity / gravityDecreasingFactor;
                
                kiwiSpeedController.SubtractAirCurrentSpeed();
                Time.timeScale = 1;
                topCollider.enabled = true;
                innerLeftCollider.enabled = true;
                Kiwi.isInControlOfAirCurrent = false;
                birdState = BirdState.None;
                trackBird = false;
                CancelInvoke("TrackBird");

                Invoke("EgniteJetPack", .5f);
            }
        }

	
	}

    void EgniteJetPack()
    {
        kiwiScript.EgniteJetPack();
    }

    bool bringBackToInitialPosition = false;
    public static float birdBackToInitialSpeed = .5f;

    public void StopTrackingBird()
    {
        topCollider.enabled = true;
        innerLeftCollider.enabled = true;        
        birdState = BirdState.None;
        trackBird = false;
        CancelInvoke("TrackBird");
    }

    public void StartTrackingBirdPosition()
    {
        topCollider.enabled = false;
        innerLeftCollider.enabled = false;
        trackBird = true;
        InvokeRepeating("TrackBird", 0, .1f);

    }

    public void InstantlyAddHalfAirCurrentSpeed(bool half)
    {
        kiwiSpeedController.QucklyAddAirCurrentSpeed(half);
    }

    

    void SubtractAirCurrentSpeed()
    {
        //birdState = BirdState.None;
        kiwiSpeedController.SubtractAirCurrentSpeed();
    }



}
