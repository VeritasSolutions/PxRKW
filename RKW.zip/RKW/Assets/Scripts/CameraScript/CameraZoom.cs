using UnityEngine;
using System.Collections;

public class CameraZoom : MonoBehaviour 
{

    public static bool isCameraInOriginalState = true;

    Transform birdTransform;

    float minCameraSize = 3.6f;
    float maxCameraSize = 7.2f;
    Camera mainCamera;

    Frame frameScript;
    
    float cameraSize;

    float maxBirdHeight = 10f;

    float birdHeight;

    bool zoomCamera = false;
    

    BoxCollider topCollider;
    Transform topColliderTransform;
    float topColliderYPos;
    float spaceYPosition;

    float backToZeroCameraSpeed = 1.5f;

    Camera kiwiCamera;


	void Start () 
    {
        birdTransform = GameObject.Find("Kiwi").transform;
        frameScript = GameObject.Find("Environment Frame").GetComponent<Frame>();
        kiwiCamera = GameObject.Find("Kiwi Camera").GetComponent<Camera>();

        isCameraInOriginalState = true;

        mainCamera = camera;
        topCollider=GameObject.Find("Top").GetComponent<BoxCollider>();
        topColliderTransform = topCollider.transform;
        topColliderYPos = topCollider.transform.position.y - .2f;
        spaceYPosition = topColliderYPos + 1f;
        

        this.enabled = false;
	}

    bool getCameraToZero = false;

    void Update()
    {
        if (getCameraToZero)
        {
            mainCamera.orthographicSize = Mathf.MoveTowards(mainCamera.orthographicSize, 3.6f, backToZeroCameraSpeed * Time.deltaTime);
            kiwiCamera.orthographicSize = mainCamera.orthographicSize;

            if (mainCamera.orthographicSize == 3.6f)
            {
              //  print("Disabled");
                frameScript.HideRightLeftStuffs();
                isCameraInOriginalState = true;
                getCameraToZero =false;
                this.enabled = false;
            }
        }

        if (!zoomCamera)
            return;

        //if (birdTransform.position.y < 0 && BirdStateScript.birdState == BirdStateScript.BirdState.None)
        if (BirdStateScript.birdState == BirdStateScript.BirdState.None)
        {
            getCameraToZero = true;
            zoomCamera = false;
            
        }
        else
        {
            cameraSize = minCameraSize + (maxCameraSize - minCameraSize) * birdTransform.position.y / maxBirdHeight;
           // cameraSize = maxCameraSize;
        }

        if (cameraSize < minCameraSize)
            cameraSize = minCameraSize;
        if (cameraSize > maxCameraSize)
            cameraSize = maxCameraSize;

        mainCamera.orthographicSize = Mathf.MoveTowards(mainCamera.orthographicSize, cameraSize, 4 * Time.deltaTime);
        kiwiCamera.orthographicSize = mainCamera.orthographicSize;

        


    }

    internal void StartZoomEffect()
    {
        frameScript.ShowRightLeftStuffs();

        isCameraInOriginalState = false;
        getCameraToZero = false;  
        zoomCamera = true;
        

    }

    internal void RevertZoomEffect()
    {
        zoomCamera = false;
        getCameraToZero = true;
    }
        
}
