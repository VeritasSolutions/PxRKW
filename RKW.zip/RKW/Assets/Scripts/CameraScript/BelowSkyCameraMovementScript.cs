using UnityEngine;
using System.Collections;

public class BelowSkyCameraMovementScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	
}
