using UnityEngine;
using System.Collections;

public class FrameCalculator : MonoBehaviour 
{

    bool upd = true;

    float fps;
    float m_fps;

    

    void UpdateFPS()
    {
        upd = true;
        fps = m_fps;
    }


    void Update()
    {

        m_fps = 1 / Time.deltaTime;

    }

    void OnGUI()
    {

        GUI.Label(new Rect(0, 0, 30, 20), fps.ToString());

        if (!upd)
            return;

        upd = false;
        Invoke("UpdateFPS", .5f);

    }



    
}
