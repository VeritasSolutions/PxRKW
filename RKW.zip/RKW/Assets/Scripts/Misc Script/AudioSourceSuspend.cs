using UnityEngine;
using System.Collections;

public class AudioSourceSuspend : MonoBehaviour {
    private class AudioSourceInfo {
        public AudioSource audioSource;
        public float time;
        public bool wasPlaying;
    }


    
    
    private AudioSourceInfo[] sourcesToBeResumed;


    void Start()
    {
       // InvokeRepeating("CheckForAudioMalFunction",2f, 2f);
   
	}

    void CheckForAudioMalFunction()
    {
        if (Game.currentPlayingMusic)
        {
            if (!Game.currentPlayingMusic.isPlaying)
            {
                 Game.currentPlayingMusic.Play();
            }
        }    
    }
    #if UNITY_IPHONE
    void OnApplicationPause(bool pause)
    {
        if (pause)
        {
            

            print(" Application is pausing");
            // Save infos about the audio sources in the scene
            AudioSource[] sources = (AudioSource[])FindObjectsOfType(typeof(AudioSource));
            if (sources != null && sources.Length > 0)
            {

                // Create array of sources for resume
                sourcesToBeResumed = new AudioSourceInfo[sources.Length];

                for (int i = 0; i < sourcesToBeResumed.Length; i++)
                {
                    // Store informations about the sources
                    sourcesToBeResumed[i] = new AudioSourceSuspend.AudioSourceInfo();
                    sourcesToBeResumed[i].audioSource = sources[i];
                    sourcesToBeResumed[i].time = sources[i].time;

                    // For some reason, sources[i].isPlaying always returns false, even if the source is actually playing.
                    // We have to check the time instead.
                    if (sources[i].time > 0)
                    {
                        sourcesToBeResumed[i].wasPlaying = true;
                    }
                    else
                    {
                        sourcesToBeResumed[i].wasPlaying = false;
                    }

                    // Stop the source
                    sources[i].Stop();
                }
            }
            else
            {
                sourcesToBeResumed = null;
            }
        }
        else if (sourcesToBeResumed != null && sourcesToBeResumed.Length > 0)
        {
            print(" Application is Resuming");
            

            foreach (AudioSourceInfo ainfo in sourcesToBeResumed)
            {
                if (ainfo.wasPlaying)
                {
                    ainfo.audioSource.time = ainfo.time;
                    ainfo.audioSource.Play();
                }
            }
            CheckForAudioMalFunction();
        }


    }


#endif
}