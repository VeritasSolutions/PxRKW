using UnityEngine;
using System.Collections;

public class UVScroller : MonoBehaviour {

    public float speedFactorPercentage = 1;
    Transform myTransform;

    public float scrollSpeed = 0;
    Renderer myRenderer;

    void Start()
    {
        myTransform = transform;
        myRenderer = renderer;
        
    }

    float offset;
    void FixedUpdate()
    {
        scrollSpeed = KiwiSpeedController.kiwiCurrentSpeed * speedFactorPercentage * .001f;

        offset = Time.time * scrollSpeed;

        myRenderer.material.SetTextureOffset("_MainTex", new Vector2(offset, 0));
        
    }

    
}
