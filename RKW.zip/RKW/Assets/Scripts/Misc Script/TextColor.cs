using UnityEngine;
using System.Collections;

public class TextColor : MonoBehaviour {

    public TextMesh[] blackTexts;
    public TextMesh[] blueTexts;
    public TextMesh[] redTexts;
	void Start () 
    {
        for (int i = 0; i < blackTexts.Length; i++)
        {
            blackTexts[i].renderer.material.color = Color.black;

        }

        for (int i = 0; i < blueTexts.Length; i++)
        {
            blueTexts[i].renderer.material.color = Color.blue;
        }

        for (int i = 0; i < redTexts.Length; i++)
        {
            redTexts[i].renderer.material.color = Color.red;
        }
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
