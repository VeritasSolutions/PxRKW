using UnityEngine;
using System.Collections;

public class UpperCoinScriptNew : MonoBehaviour {

    float oneScreenWidth = 10.8f;
    public GameObject coinPrefab;

    float rowGap = .3f;
    float columnGap = 1.1f;  //dont change

    float numberOfCoinsInARow = 150;
    float xPos;
    float yPos;

    GameObject temp;

    ArrayList coins;
    ArrayList coinsPosition;
    ArrayList coinScriptArrayList;

    BirdStateScript birdStateScript;

    GameObject kiwiCamera;

    void Start()
    {

        kiwiCamera=GameObject.Find("Kiwi Camera Frame");

        columnGap = (2 * 30) / 960.0f * oneScreenWidth;
        print(columnGap);

        //  columnGap = columnGap * 5f / numberOfCoinsInARow;
        //  print(columnGap);

        coins = new ArrayList();
        coinsPosition = new ArrayList();
        coinScriptArrayList = new ArrayList();

        xPos = gameObject.transform.position.x;
        yPos = gameObject.transform.position.y;

        for (int i = 0; i < 1; i++)
        {
            xPos = gameObject.transform.position.x;

            for (int j = 0; j < numberOfCoinsInARow; j++)
            {
                temp = (GameObject)Instantiate(coinPrefab, new Vector3(xPos, yPos, 10), Quaternion.identity);
                temp.transform.parent = transform;
                coins.Add(temp);
                coinsPosition.Add(temp.transform.localPosition);
                coinScriptArrayList.Add(temp.GetComponent<Coin>());
                xPos -= columnGap;
            }

            yPos += rowGap;
        }
    }

    internal void UpdatePosition()
    {
        Refresh();
        transform.position = new Vector3(kiwiCamera.transform.position.x - 20f, transform.position.y, transform.position.z);
    }

    internal void Refresh()
    {
        for (int i = 0; i < coins.Count; i++)
        {
            ((GameObject)coins[i]).active = true;
            ((GameObject)coins[i]).transform.localPosition = (Vector3)coinsPosition[i];
            ((Coin)coinScriptArrayList[i]).lerp = false;
        }
    }
}
