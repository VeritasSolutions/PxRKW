using UnityEngine;
using System.Collections;

public class FuelMeter : MonoBehaviour 
{

    float maximumCapacity;
    internal float remainingFuel;

    float rateOfFuelConsumption; 

    float updateInterval = .1f;

    public Transform circularFuelMeter;

    float value = 1;

	void Start () 
    {
        rateOfFuelConsumption = GameVariables.basicFuelConsumptionRate;

        maximumCapacity = Rocket.capacity[Rocket.currentRocketIndex];
        remainingFuel = maximumCapacity;
        rateOfFuelConsumption = rateOfFuelConsumption * updateInterval;

        InvokeRepeating("ConsumeFuel", 1, updateInterval);
	
	}

    float targetAngle = 90;

    internal void ConsumeFuel()
    {
        if (Game.gameState != Game.GameState.Playing)
        {            
            return;
        }

        if (remainingFuel <= 0)
        {
            remainingFuel = 0;            
            targetAngle = 180;
           // circularFuelMeter.eulerAngles = new Vector3(0, 0, targetAngle);
            return;
        }

        if (Kiwi.isJetPackOn)
        {
            remainingFuel -= rateOfFuelConsumption;
            value = remainingFuel / maximumCapacity;

            targetAngle = 180 - value * 90;

           // circularFuelMeter.eulerAngles = new Vector3(0, 0, targetAngle);

        }
    }
	
	
	void FixedUpdate()
    {
        circularFuelMeter.eulerAngles = Vector3.Lerp(circularFuelMeter.eulerAngles, new Vector3(0, 0, targetAngle), .1f);    
	}

    internal void AddFuel(float quantity)
    {
        remainingFuel += quantity;

        if (remainingFuel >= maximumCapacity)
            remainingFuel = maximumCapacity;
    }

    internal void DecreaseFuel(float quantity)
    {
        remainingFuel -= quantity;

        if (remainingFuel <= 0)
            remainingFuel = 0;
    }
}
