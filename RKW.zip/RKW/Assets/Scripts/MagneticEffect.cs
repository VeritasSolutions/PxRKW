using UnityEngine;
using System.Collections;

public class MagneticEffect : MonoBehaviour 
{
    public UIPanel uiPanel;

    bool isForward = true;

    void StartFadingEffect() 
    {
        if (isForward)
            uiPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        else
            uiPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        isForward = !isForward;
	
	}

    void OnEnable()
    {
        InvokeRepeating("StartFadingEffect", 0, .5f);
    }

    void OnDisable()
    {
        CancelInvoke("StartFadingEffect");
    }
}
