using UnityEngine;
using System.Collections;

public class AirCurrent : MonoBehaviour 
{

    public enum AirCurrentKind
    {
        WillThrowUp,
        WillNotThrowUpDontUseGravity,
        WillNotThrowUpUseGravity
    };

    public AirCurrentKind airCurrentkind = AirCurrentKind.WillThrowUp;

    public FlyObject parentFlyingObjectScript;
    AirCurrentNodeController airNodeController;
    
    Transform[] flowPoints;
    

    

    int currentNodeIndex = 1;
    int targetNodeIndex = 1;

  //  public Transform targetNodeTransform;

    Vector3 targetNodePosition = Vector3.zero;

    float targetAngle;

    static Camera mainCamera;

    float maximumCurrentForce = 20f;

    int currentNodeNumber;

    float airCurrentSpeed = 18;  //15

    static CameraZoom cameraZoomScript;
    static BelowSkyCameraZoom belowSkyCameraZoomScript;

    static CameraMovementScript cameraMovementScript;
    static BirdStateScript birdStateScript;
    static InputScript inputScript;
    static KiwiSpeedController kiwiSpeedController;

    static Transform kiwiTransform;
    static Rigidbody kiwiRigidBody;

    static BoxCollider airCurrentLevelCollider;


    float angle;

    public float []targetAngleArray;

    public Vector3[] nodesPosition;

    

    int flowPointsLength;
    float speedIncreamentPerNode = 0;
    
	void Start () 
    {
        if(airCurrentLevelCollider == null)
            airCurrentLevelCollider = GameObject.Find("Air Current Collider").GetComponent<BoxCollider>();

        airNodeController = transform.parent.GetComponent<AirCurrentNodeController>();

        flowPoints = airNodeController.flowPoints;

        flowPointsLength = flowPoints.Length;

        currentNodeNumber = int.Parse(name);

        angle = Vector2.Angle((flowPoints[flowPoints.Length - 1].position - flowPoints[flowPoints.Length - 2].position), -Vector2.right);

      
        nodesPosition = new Vector3[flowPoints.Length];

        for (int i = 0; i < flowPoints.Length; i++)
        {
            nodesPosition[i] = flowPoints[i].localPosition;
        }

        for (int i = 2; i < flowPoints.Length; i++)
        {
            Destroy(flowPoints[i].gameObject);
        }

        if (mainCamera == null)
        {
            kiwiTransform = GameObject.Find("Kiwi").transform;
            kiwiRigidBody = kiwiTransform.rigidbody;

            kiwiSpeedController = kiwiTransform.GetComponent<KiwiSpeedController>();

            mainCamera = Camera.mainCamera;
            cameraZoomScript = mainCamera.GetComponent<CameraZoom>();
            belowSkyCameraZoomScript = mainCamera.GetComponent<BelowSkyCameraZoom>();
            cameraMovementScript = mainCamera.GetComponent<CameraMovementScript>();
            birdStateScript = mainCamera.GetComponent<BirdStateScript>();

            inputScript = GameObject.Find("Screen Input").GetComponent<InputScript>();
            

            
        }

        speedIncreamentPerNode = kiwiSpeedController.maximumAirCurrentSpeedBelowSky/( nodesPosition.Length - 1);
      //  print(speedIncreamentPerNode);
        
	
	}

    void OnTriggerEnter(Collider other)
    {
        if (Game.gameState != Game.GameState.Playing)
            return;
        
        if (Kiwi.isSpeedBoosterOn)
            return;

        if (other.tag == "Kiwi")
        {
            
            if (Kiwi.isInsideAirCurrent)
                return;

            airCurrentLevelCollider.enabled = false;

            CancelInvoke("DisableJustCameOutOfAirCurrent");
            Kiwi.justCameOutOfAirCurrent = false;

            if(Game.goToTouchPosition)
               inputScript.enabled = false; 

            airCurrentSpeed = airCurrentSpeed * KiwiSpeedController.kiwiCurrentSpeed / 7f;

            currentNodeIndex = currentNodeNumber;
           
            Kiwi.isInControlOfAirCurrent = true;
            Kiwi.isInsideAirCurrent = true;
            Kiwi.justCameOutOfAirCurrent = true;

            kiwiRigidBody.useGravity = false;
            kiwiRigidBody.isKinematic = true;

            targetNodeIndex = currentNodeIndex + 1;
          
            targetNodePosition = nodesPosition[targetNodeIndex];

            kiwiTransform.parent = transform.parent;
           
        }
    }

    

    void FixedUpdate()
    {
        if (targetNodePosition == Vector3.zero)
            return;

        kiwiTransform.localPosition = Vector3.MoveTowards(kiwiTransform.localPosition, targetNodePosition, airCurrentSpeed * Time.deltaTime);

        if (Mathf.Abs(kiwiTransform.localPosition.x - targetNodePosition.x) < .1f)
        {
            if (Vector2.Distance(kiwiTransform.localPosition, targetNodePosition) < .1f)
            {
                if (airCurrentkind != AirCurrentKind.WillThrowUp)
                {
                    kiwiSpeedController.currentAirCurrentSpeed += speedIncreamentPerNode;
                    airCurrentSpeed = airCurrentSpeed * KiwiSpeedController.kiwiCurrentSpeed / 7f;

                }

                currentNodeIndex++;
                targetNodeIndex = currentNodeIndex + 1;

                if (targetNodeIndex >= flowPointsLength)
                {
                    targetNodePosition = Vector3.zero;
                    Jump();
                }
                else
                {                  
                    targetNodePosition = nodesPosition[targetNodeIndex];

                    

                    targetAngle = Vector2.Angle((targetNodePosition - nodesPosition[currentNodeIndex]), -Vector2.right);

                    if (targetNodePosition.y > nodesPosition[currentNodeIndex].y)
                        kiwiTransform.eulerAngles = new Vector3(0, 0, -targetAngle);
                    else
                        kiwiTransform.eulerAngles = new Vector3(0, 0, targetAngle);

                }
            }
        }

    }

    float minimumForce = 10f;
    

    private void Jump()
    {
        if(Game.goToTouchPosition)
            inputScript.enabled = true;

        kiwiTransform.parent = null;

        Kiwi.isInsideAirCurrent = false;
        kiwiRigidBody.isKinematic = false;
        kiwiRigidBody.useGravity = true;

        float force = maximumCurrentForce ;

      //  print(transform.parent.parent.name);
      //  print(transform.parent.parent.parent.name);

        if(transform.parent.parent.name == "Air Current 5(Clone)" && transform.parent.parent.parent.name == "Air Current 204(Clone)")
            force = force * KiwiSpeedController.kiwiCurrentSpeed / 7f;

        if (angle < 0)
            angle = 0;

        force = force * Mathf.Sin(angle * Mathf.PI / 180f);

        print(force);




        if (airCurrentkind == AirCurrentKind.WillThrowUp)
        {
           
            kiwiRigidBody.AddForce(new Vector3(0, force, 0), ForceMode.Impulse);

            airCurrentLevelCollider.enabled = true;
            BirdStateScript.birdState = BirdStateScript.BirdState.BelowSkyGoingUp;

            //cameraMovementScript.enabled = true;
            //cameraZoomScript.enabled = true;
            //cameraZoomScript.StartZoomEffect();

            //kiwiSpeedController.AddAirCurrentSpeed();

            //birdStateScript.StartTrackingBirdPosition();
            Invoke("DisableJustCameOutOfAirCurrent", .2f);
        }
        else
        {
            if(airCurrentkind == AirCurrentKind.WillNotThrowUpDontUseGravity)
                kiwiRigidBody.useGravity = false;
           

            Kiwi.isInControlOfAirCurrent = false;
                
         //   kiwiRigidBody.AddForce(new Vector3(-maximumCurrentForce * 1000f, 0, 0), ForceMode.VelocityChange);
            BirdStateScript.birdState = BirdStateScript.BirdState.BelowSkyNotGoingUp;

            cameraMovementScript.RevertCameraMovement();
            cameraZoomScript.RevertZoomEffect();

            kiwiSpeedController.AddAirCurrentSpeedBelowSky();

            birdStateScript.StopTrackingBird();
            
            Invoke("DisableJustCameOutOfAirCurrent", .2f);
        }

        
        
    }

    void DisableJustCameOutOfAirCurrent()
    {
        Kiwi.justCameOutOfAirCurrent = false;
    }
}
