using UnityEngine;
using System.Collections;

public class FeatherRewardPopup : MonoBehaviour 
{

    public UIPanel popUpPanel;
    public TextMesh featherText;
    internal int numberOfFeathersRewarded = 0;

	
	void Start () 
    {
        numberOfFeathersRewarded = GameVariables.featherRewards[Game.currentZoneIndex];
        popUpPanel.gameObject.transform.localScale = new Vector3(0, 0, 1);
        Invoke("BringItForward", 1f);
	
	}

    internal void BringItForward()
    {
        featherText.text = "X " + numberOfFeathersRewarded.ToString();
        popUpPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);
    }

    void BringItBack()
    {
        popUpPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
    }

    void CloseButtonClicked()
    {
        BringItBack();
        Destroy(popUpPanel.gameObject, 1f);
    }
}
