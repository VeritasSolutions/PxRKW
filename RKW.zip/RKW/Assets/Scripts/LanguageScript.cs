﻿using UnityEngine;
using System.Collections;

public class LanguageScript : MonoBehaviour 
{
    public class LanguageInstance
    {
        public string English;
        public string Chinese;

        public LanguageInstance(string english, string chinese)
        {
            English = english;
            Chinese = chinese;
        }
    }


    public LanguageInstance[] languageObjects;

    ArrayList stringList;

    TextMesh[] textMeshes;

    public Font chineseFont;
    public Material chineseFontMaterial;
	
	void Start () 
    {

       

        stringList = new ArrayList();

        stringList.Add(new LanguageInstance("Start","开始"));
        stringList.Add(new LanguageInstance("Story Mode", "故事模式"));
        stringList.Add(new LanguageInstance("Shop", "购物"));
        stringList.Add(new LanguageInstance("Challenge Mode", "挑战模式"));

        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));
        stringList.Add(new LanguageInstance("Start", "开始"));


        

        if (Application.systemLanguage.ToString() == "Chinese")
            SetFontToChinese();
        else if (Application.systemLanguage.ToString() == "Japanese")
            SetFontToJapanese();

	}

    void SetFontToJapanese()
    {

    }

    void SetFontToChinese()
    {
        textMeshes = (TextMesh[])FindObjectsOfType(typeof(TextMesh));
        
        
        
        for (int i = 0; i < textMeshes.Length; i++)
        {
            textMeshes[i].font = chineseFont;
            textMeshes[i].renderer.material = chineseFontMaterial;

            string tempString = textMeshes[i].text;

            textMeshes[i].text = ReturnChinese(tempString);

        }
    }

    private string ReturnChinese(string tempString)
    {
        for (int i = 0; i < stringList.Count; i++)
        {
            if (((LanguageInstance)stringList[i]).English == tempString)
                return ((LanguageInstance)stringList[i]).Chinese;
        }

        return tempString;
    }
}
