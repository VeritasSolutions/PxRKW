using UnityEngine;
using System.Collections;

public class GameUIController : MonoBehaviour {

    public Camera guiCamera;
    
    public UIPanel pauseMenuPanel;
    public UIPanel gameFinishPanel;
    
    GameObject[] musics;
    public TextMesh timeText;

    public TextMesh levelInfoText;

    public UIPanel faderPanel;

    public UIStateToggleBtn soundButton;
    public UIStateToggleBtn musicButton;
    

    public GameObject pauseButtonObject;
    
    
    public GameObject fader;
    Kiwi kiwiScript;

    public Transform backButtonTransform;
    public Transform restartButtonTransform;

    public TextMesh speedText;
    public TextMesh scoreText;

    public UIPanel blackScreenUp;
    public UIPanel blackScreenDown;
    ObjectParallexScript objectContainerParallexScript;

    Frame frameScript;

    public GameFinishPopupScript gameFinishPopupScript;
    public GameOverPopupScript gameOverPopupScript;

    UIManager uiManager;

    BlockGenerationNew blockGenerationScript;
    
    
    void Awake()
    {
        #if UNITY_IPHONE
            iPhoneKeyboard.autorotateToLandscapeLeft = false;
            iPhoneKeyboard.autorotateToLandscapeRight = false;
            iPhoneKeyboard.autorotateToPortrait = false;
            iPhoneKeyboard.autorotateToPortraitUpsideDown = false;

            ((UIManager)(GameObject.Find("UIManager").GetComponent("UIManager"))).pointerType = UIManager.POINTER_TYPE.TOUCHPAD;
            iPhoneSettings.screenCanDarken = false;
            Input.multiTouchEnabled = false;

        #endif
        
    }

	void Start () 
    {
        uiManager = GameObject.Find("UIManager").GetComponent<UIManager>();
        uiManager.uiCameras[0].camera = Camera.mainCamera;
        uiManager.uiCameras[1].camera = guiCamera;

        levelInfoText.text = Application.loadedLevelName;
        objectContainerParallexScript = GameObject.Find("Object Container Manager").GetComponent<ObjectParallexScript>();

        blockGenerationScript = GameObject.Find("Block Generation").GetComponent<BlockGenerationNew>();

        Game.gameState = Game.GameState.Start;
        LevelStats.currentScore = 0;
        
      //  MoreGamesBinding.RequestInterstial();

        frameScript = GameObject.Find("Environment Frame").GetComponent<Frame>();
        kiwiScript = GameObject.Find("Kiwi").GetComponent<Kiwi>();

        fader.active = true;
        fader.renderer.enabled = true;
        AudioSettings();
        InvokeRepeating("UpdateTime", 0f, 1f);
        InvokeRepeating("UpdateGUI", 0f, .1f);

               

        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        counterPackedSprite.transform.localScale = new Vector3(0, 0, 1);

      //  blackScreenUp.transform.localPosition = new Vector3(blackScreenUp.transform.localPosition.x, 2.6f, blackScreenUp.transform.localPosition.z);
      //  blackScreenDown.transform.localPosition = new Vector3(blackScreenDown.transform.localPosition.x, -2.6f, blackScreenDown.transform.localPosition.z);
      //  Invoke("StartCounter", 1f);
        StartGame();
	
	}

    public PackedSprite counterPackedSprite;
    public AudioSource readyAudio;
    public AudioSource goAudio;


    private void StartCounter()
    {

        iTween.ScaleTo(counterPackedSprite.gameObject, new Vector3(1, 1, 1), .2f);
        readyAudio.Play();
        Invoke("Zoom1", .5f);
        Invoke("Zoom1", 1f);
        Invoke("Go", 1.6f);
    }

    void Zoom1()
    {
        iTween.PunchScale(counterPackedSprite.gameObject, new Vector3(.5f, .5f, .5f), .2f);
    }

    void Go()
    {
        iTween.ScaleFrom(counterPackedSprite.gameObject, new Vector3(0, 0, 0), .2f);
        counterPackedSprite.PlayAnim(1);
        goAudio.Play();
        Invoke("RemoveGo", .5f);
    }

    void RemoveGo()
    {
        blackScreenUp.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        blackScreenDown.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        iTween.ScaleTo(counterPackedSprite.gameObject, new Vector3(0, 0, 0), .2f);
        
        Invoke("StartGame", .4f);
    }

    

    void StartGame()
    {
        if (Game.goToTouchPosition == false)
        {
            GameObject.Find("Kiwi").rigidbody.useGravity = true;
            
        }

        blockGenerationScript.GenerateFirstBlock();

        objectContainerParallexScript.enabled = true;
        counterPackedSprite.gameObject.active = false;
        Game.gameState = Game.GameState.Playing;
    }


    public bool updateTime = true;
    
    void UpdateTime()
    {
        if (Game.gameState != Game.GameState.Playing)
            return;

        if (!updateTime)
            return;

        LevelStats.timePassed++;

        
    }

    public TextMesh distanceText;

    void UpdateGUI()
    {
        distanceText.text = ((int)(LevelStats.distanceTravelled)).ToString() + " m";
        speedText.text = "Speed : " + Mathf.RoundToInt(KiwiSpeedController.kiwiCurrentSpeed).ToString() + " m/s";
        //scoreText.text = "Score : " + Mathf.RoundToInt(LevelStats.distanceTravelledScore + LevelStats.otherScore).ToString();
        
    }



   

    Game.GameState previousState = Game.GameState.None;

    

    void PauseButtonClicked()
    {
        
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        previousState = Game.gameState;
        Game.gameState = Game.GameState.Pause;
        Time.timeScale = 0f;
        pauseMenuPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);
    }

    void ContinueButtonClicked()
    {
        Game.gameState = previousState;
        
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        pauseMenuPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        Time.timeScale = 1f;
    }

    internal void PlayAgainButtonClicked()
    {
        Time.timeScale = 1;
        pauseMenuPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.DismissForward);
        Invoke("PlayAgainClicked", 1f);
        
        
        
    }

    void PlayAgainClicked()
    {
        Application.LoadLevel(Application.loadedLevel);        
    }

    internal void HomeButtonClicked()
    {
        Time.timeScale = 1;
        pauseMenuPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);        
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.DismissForward);

        Invoke("HomeClicked", 1f);
    }

    void HomeClicked()
    {
        Time.timeScale = 1f;
        Application.LoadLevel(0);
    }

    int nextLevelToLoad = 1;
    
    int nextLevel = 0;

    public static int GetTotalScore()
    {
        int distanceScore = (int)LevelStats.distanceTravelled * GameVariables.scorePerMeterTravelled;
        int coinScore = LevelStats.numberOfCoinsCollected * GameVariables.scorePerSmallCoinCollected;
        int fuelScore = LevelStats.numberOfFuelsCollected * GameVariables.scorePerFuelCollected;

        int totalScore = distanceScore + coinScore + fuelScore;


        return totalScore;

    }

    public void ShowGameFinishedPopup()
    {      

        Invoke("DisplayGameFinishPopup", 2f);

        Game.totalNumberOfCoinsCollected += LevelStats.numberOfCoinsCollected;

        if (Game.isFeatherRewarded[Game.currentLoadedLevelForStats] == 0)
        {
            LevelStats.rewardFeather = true;
            Game.isFeatherRewarded[Game.currentLoadedLevelForStats] = 1;
            Game.totalNumberOfFeathersCollected += GameVariables.featherRewards[Game.currentZoneIndex];            
        }
        

        print(GetTotalScore());
        print(Game.levelsBestScore[Game.currentLoadedLevelForStats]);

        if (Game.levelsBestScore[Game.currentLoadedLevelForStats] < GetTotalScore())
            Game.levelsBestScore[Game.currentLoadedLevelForStats] = GetTotalScore();


        int nextZoneLevelIndex = -1;

        if (Game.currentZonelevelIndex == 0)
            nextZoneLevelIndex = 1;
        else if (Game.currentZonelevelIndex == 1)
            nextZoneLevelIndex = 2;
        else if (Game.currentZonelevelIndex == 2)
            nextZoneLevelIndex = 3;
        else if (Game.currentZonelevelIndex == 3)
            nextZoneLevelIndex = -1;

        if (nextZoneLevelIndex == -1)
        {
            nextLevelToLoad = 0;
        }
        else if (nextZoneLevelIndex == 3) //next is challenge level
        {
            int currentZoneNumber = Game.currentZoneIndex + 1;

            if (Game.numberOfZoneUnlocked < currentZoneNumber)
                Game.numberOfZoneUnlocked = currentZoneNumber + 1;

            nextLevelToLoad = 0; 
        }
        else
        {
            Game.numberOfExploredLevels[Game.currentZoneIndex] = nextZoneLevelIndex;
            nextLevelToLoad = Game.currentLoadedLevelForStats + Game.level1BuildSettingIndex + 1;

            Game.currentZonelevelIndex = nextZoneLevelIndex;
        }

        Game.SaveGameSettings();

    }


    internal void ShowGameOverPopup()
    {
        Invoke("DisplayGameOverPopup", 1f);

        Game.totalNumberOfCoinsCollected += LevelStats.numberOfCoinsCollected;               

        if (Game.levelsBestScore[Game.currentLoadedLevelForStats] < GetTotalScore())
            Game.levelsBestScore[Game.currentLoadedLevelForStats] = GetTotalScore();


        Game.SaveGameSettings();
    }

    void DisplayGameOverPopup()
    {
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        gameOverPopupScript.ShowGameOverPopup();
    }

    void DisplayGameFinishPopup()
    {
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInForward);

        gameFinishPopupScript.ShowGameFinishPopup();
        
       
    }

    internal void NextLevelButtonClicked()
    { 
        
        gameFinishPanel.StartTransition(UIPanelManager.SHOW_MODE.BringInBack);
        faderPanel.StartTransition(UIPanelManager.SHOW_MODE.DismissForward);
        
        Invoke("LoadLevel", 1f);
    }


    void LoadLevel()
    {
        Application.LoadLevel(nextLevelToLoad);
    }

    private void AudioSettings()
    {
        musics = GameObject.FindGameObjectsWithTag("Music");
        Game.SetSoundSettings();

        if (!Game.isSoundOn)
        {
            soundButton.SetState(1);
        }

        if (Game.isMusicOn)
        {
            for (int i = 0; i < musics.Length; i++)
            {
                musics[i].GetComponent<AudioSource>().volume = Game.musicVolume;
            }

        }
        else
        {
            for (int i = 0; i < musics.Length; i++)
            {
                musics[i].GetComponent<AudioSource>().volume = 0f;
            }
            musicButton.SetState(1);
        }
    }

    void MusicONOFFButtonClicked()
    {
        if (Game.isMusicOn)
        {
            musicButton.SetState(1);
            Game.isMusicOn = false;
        }
        else
        {
            musicButton.SetState(0);
            Game.isMusicOn = true;
        }

        if (Game.isMusicOn)
        {
            for (int i = 0; i < musics.Length; i++)
            {
                musics[i].GetComponent<AudioSource>().volume = Game.musicVolume;
            }
            
        }
        else
        {
            for (int i = 0; i < musics.Length; i++)
            {
                musics[i].GetComponent<AudioSource>().volume = 0f;
            }
        }
    }

    void SoundONOFFButtonClicked()
    {
        if (Game.isSoundOn)
        {
            soundButton.SetState(1);
            Game.isSoundOn = false;
            Game.soundEffectVolume = 0;
        }
        else
        {
            soundButton.SetState(0);
            Game.isSoundOn = true;
            Game.soundEffectVolume = 1;
        }
        Game.SetSoundSettings();

        if (Game.isMusicOn)
        {
            for (int i = 0; i < musics.Length; i++)
            {
                musics[i].GetComponent<AudioSource>().volume = Game.musicVolume;
            }
        }
        else
        {
            for (int i = 0; i < musics.Length; i++)
            {
                musics[i].GetComponent<AudioSource>().volume = 0f;
            }
        } 
    }


    public TextMesh coinText;

    internal void UpdateCoinCount()
    {
        coinText.text = LevelStats.numberOfCoinsCollected.ToString();
    }

    public UIButton speedBoosterButton;
    public UIButton magnetBoosterButton;
    public UIButton shieldBoosterButton;

    void EnableAllBoosterIcons()
    {
        speedBoosterButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
        magnetBoosterButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
        shieldBoosterButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
    }

    void DisableAllBoosterIcons()
    {
        speedBoosterButton.SetControlState(UIButton.CONTROL_STATE.DISABLED);
        magnetBoosterButton.SetControlState(UIButton.CONTROL_STATE.DISABLED);
        shieldBoosterButton.SetControlState(UIButton.CONTROL_STATE.DISABLED);
    }

    internal void EnableBoosterIcon()
    {
        EnableAllBoosterIcons();

        speedBoosterButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
    }

    internal void EnableMagnetIcon()
    {
        EnableAllBoosterIcons();

        magnetBoosterButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
    }

    internal void EnableShieldIcon()
    {
        EnableAllBoosterIcons();

        shieldBoosterButton.SetControlState(UIButton.CONTROL_STATE.NORMAL);
    }

    void SpeedBoosterClicked()
    {
        if (Kiwi.isSpeedBoosterOn)
            return;

        DisableAllBoosterIcons();
        

        kiwiScript.ActivateBooster();
    }

    void MagnetBoosterClicked()
    {
        if (Kiwi.isMagnetOn)
            return;

        DisableAllBoosterIcons();

        kiwiScript.ActivateMagnet();
    }

    void ShieldBoosterClicked()
    {
        if (Kiwi.isSpeedBoosterOn)
            return;

        DisableAllBoosterIcons();

        kiwiScript.ActivateSheild();
    }
}
