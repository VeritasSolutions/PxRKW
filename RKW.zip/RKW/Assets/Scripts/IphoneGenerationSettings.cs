using UnityEngine;
using System.Collections;

public class IphoneGenerationSettings : MonoBehaviour {

    public GameObject frame;

    public GameObject[] rightItems;
    public GameObject[] leftItems;

    public GameObject []objectsToScale;
    float rightShift = .45f;
	void Start () 
    {
        #if UNITY_IPHONE
        if (iPhoneSettings.generation == iPhoneGeneration.iPad1Gen)
            IPadSettings();
#endif

    }

    private void IPadSettings()
    {
        if(frame)
            frame.transform.localScale = new Vector3(.9f, frame.transform.localScale.y, frame.transform.localScale.z);
        for (int i = 0; i < rightItems.Length; i++)
        {
            print("shifted");
            rightItems[i].transform.position = new Vector3(rightItems[i].transform.position.x + rightShift, rightItems[i].transform.position.y, rightItems[i].transform.position.z);
        }

        for (int i = 0; i < leftItems.Length; i++)
        {
            print("shifted");
            leftItems[i].transform.position = new Vector3(leftItems[i].transform.position.x - rightShift, leftItems[i].transform.position.y, leftItems[i].transform.position.z);
        }

        for (int i = 0; i < objectsToScale.Length; i++)
        {
            objectsToScale[i].transform.localScale = new Vector3(.9f,  objectsToScale[i].transform.localScale.y,  objectsToScale[i].transform.localScale.z);
        }
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
