using UnityEngine;
using System.Collections;

public class KiwiCameraPoint : MonoBehaviour 
{
    Transform kiwiTransform;
    Transform myTransform;
    public float speed = 1f;

    FuelMeter fuelMeter;
	
	void Start () 
    {
        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
        kiwiTransform = transform.parent;
        myTransform = transform;
	
	}

    float kiwiSpeedToStartMoving = 7f;

    float moveTowardsCenterSpeed = 2f;
    float comeBackToInitialSpeed = 1f;
	
	
	void FixedUpdate () 
    {
        if (KiwiSpeedController.kiwiCurrentSpeed < kiwiSpeedToStartMoving && fuelMeter.remainingFuel <= 0)
        {
            float xPos = -3.5f + 3.5f * KiwiSpeedController.kiwiCurrentSpeed / kiwiSpeedToStartMoving;
            Vector3 targetPos = new Vector3(xPos, myTransform.position.y, myTransform.position.z);

            myTransform.localPosition = Vector3.Lerp(myTransform.localPosition, targetPos, moveTowardsCenterSpeed * Time.deltaTime);
        }
        else
        {
            myTransform.localPosition = Vector3.Lerp(myTransform.localPosition, new Vector3(-3.5f, myTransform.position.y, myTransform.position.z), comeBackToInitialSpeed * Time.deltaTime);
        }

	
	}
}
