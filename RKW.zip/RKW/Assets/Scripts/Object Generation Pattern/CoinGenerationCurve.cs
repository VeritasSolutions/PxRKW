using UnityEngine;
using System.Collections;

public class CoinGenerationCurve : MonoBehaviour 
{
    float oneScreenWidth = 10.8f; // 10.8
    float screenHeight = 7.2f; // 7.2

    public GameObject coinPrefab;

    public int numberOfCoins = 40;

    public GameObject coinStartingPoint;

    public enum PatternType
    {
        None,
        PositiveSineCurve,
        NegativeSineCurve,
        PositiveAngleCurve,
        NegativeAngleCurve,
        straightLine,
    }

    public PatternType patternType = PatternType.PositiveSineCurve;

	void Start () 
    {
        if (patternType == PatternType.PositiveSineCurve)
            GenerateSineCoin(1);
        else if (patternType == PatternType.NegativeSineCurve)
            GenerateSineCoin(-1);
        else if (patternType == PatternType.PositiveAngleCurve)
            GenerateAngleCoin(1);
        else if (patternType == PatternType.NegativeAngleCurve)
            GenerateAngleCoin(-1);
        else if (patternType == PatternType.straightLine)
            GenerateStraightLine();
        else
            Destroy(coinStartingPoint);
	
	}

    void GenerateStraightLine()
    {
        float curveWidth = ((2 * numberOfCoins - 1) * 30) / 960.0f * oneScreenWidth;
        float curveHeight = 0;

        float x = coinStartingPoint.transform.localPosition.x;
        float y = coinStartingPoint.transform.localPosition.y;

        //  Vector3 pos = new Vector3(x, y, 0);
        int counter = 1;

        int tempSign = 1;
        int i = 0;


        for (; i < numberOfCoins; i++)
        {
            x = -curveWidth * tempSign * (float)i / (float)(numberOfCoins - 1);

            y = x * curveHeight / curveWidth;

            GameObject tempCoin = (GameObject)Instantiate(coinPrefab, Vector3.zero, Quaternion.identity);
            tempCoin.name = (counter++).ToString();
            tempCoin.transform.parent = transform;
            tempCoin.transform.localPosition = new Vector3(coinStartingPoint.transform.localPosition.x + x, coinStartingPoint.transform.localPosition.y + y, 0);

        }

        Destroy(coinStartingPoint);

    }

    void GenerateAngleCoin(int sign)
    {
        sign = -sign;
       // int numberOfCoins = 20;
        int numberOfCoinsVertically = 5;

        float curveWidth = (( 2 * numberOfCoins -1 ) * 30) / 960.0f  * oneScreenWidth;
        float curveHeight = (numberOfCoinsVertically * 30f / 640f) * screenHeight;

        float x = 0;
        float y = 0;

        int counter = 1;

        int tempSign = 1;
        int i = 0;

        for (int j = 0; j < 2; j++)
        {
            for (; i < numberOfCoins/2; i++)
            {
                x = -curveWidth * tempSign * (float)i / (float)(numberOfCoins - 1);
               
                y = sign * x * curveHeight / curveWidth;

                GameObject tempCoin = (GameObject)Instantiate(coinPrefab, Vector3.zero, Quaternion.identity);
                tempCoin.name = (counter++).ToString();
                tempCoin.transform.parent = transform;
                tempCoin.transform.localPosition = new Vector3(x, y, 0);

            }
            tempSign = -1 * tempSign;
            x = 0;
            y = 0;
            i = 1;
        }
        
    }



    void GenerateSineCoin(int sign)
    {
        sign = -sign;
      //  int numberOfCoins = 40;
        int numberOfCoinsVertically = 15;

        float curveWidth = ((2 * numberOfCoins - 1) * 30) / 960.0f * oneScreenWidth;
        float curveHeight = (numberOfCoinsVertically * 30f / 640f) * screenHeight / 2f;

        float x = 0;
        float y = 0;

        float step = 360.0f / (numberOfCoins -1);

        Vector3 pos = new Vector3(x,y,0);
        int counter =1;
        int tempSign = 1;
        int i = 0;
        for (int j = 0; j < 2; j++)
        {
            for (; i < numberOfCoins/2; i++)
            {
                x = -curveWidth * tempSign * (float)i / (float)(numberOfCoins - 1);
                float angle = Mathf.Deg2Rad * (i * step);
                y = tempSign * sign * curveHeight * Mathf.Sin(angle);

                GameObject tempCoin = (GameObject)Instantiate(coinPrefab, Vector3.zero, Quaternion.identity);
                tempCoin.name = (counter++).ToString();
                tempCoin.transform.parent = transform;
                tempCoin.transform.localPosition = new Vector3(x, y, 0);

            }
            tempSign = -1 * tempSign;
            x = 0;
            y = 0;
            i = 1;
        }
    }
	
}
