using UnityEngine;
using System.Collections;

public class InputScriptOld : MonoBehaviour {

    public Kiwi flyingBirdScript;
    public Rigidbody flyingBirdRigidBody;

    public AudioSource flockingAudio;

    bool pressed = false;
    public float gravity =  5f;

    public float verticalAcceleration= 10f;

    FuelMeter fuelMeter;

    void Start()
    {
        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
        if (Game.goToTouchPosition)
        {
            GetComponent<InputScript>().enabled = true;
            Destroy(this);
        }
        else
        {            
            Destroy(GetComponent<InputScript>());
        }

        Physics.gravity = new Vector3(0, -gravity, 0);
        
    }

    void Update()
    {
        foreach (Touch evt in Input.touches)
        {
            if (evt.phase == TouchPhase.Ended)
                OnMouseUp();

            else if (evt.phase == TouchPhase.Began)
                OnMouseDown();

        }
       
    }

    public float backToZeroSpeed = 10f;


    void FixedUpdate()
    {

        if (flyingBirdRigidBody.velocity.y < -maxDownVelocity)
            flyingBirdRigidBody.velocity = new Vector3(flyingBirdRigidBody.velocity.x, -maxDownVelocity, flyingBirdRigidBody.velocity.z);

        if (Game.gameState == Game.GameState.Finish)
            return;

        if (Kiwi.isInsideAirCurrent)
        {
            return;
        }

        if (BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyGoingUp || BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingUp)
        {
            return;
        }

        

        if (pressed)
        {
            ScreenPressed();
        }
        else
        {
            ScreenNotPressed();
        }
       
    }

    public float maxUpVelocity = 2f;
    public float maxDownVelocity = 2f;

    void ScreenPressed()
    {
        if (fuelMeter.remainingFuel <= 0 || Kiwi.isJetPackOn == false)
            return;

        if(flyingBirdRigidBody.velocity.y < maxUpVelocity )
            flyingBirdRigidBody.AddForce(new Vector3(0, verticalAcceleration, 0), ForceMode.Acceleration);
    }

    void ScreenNotPressed()
    {
        if (flyingBirdRigidBody.velocity.y > 0)
            flyingBirdRigidBody.velocity = Vector3.Lerp(flyingBirdRigidBody.velocity, new Vector3(0, 0, 0), backToZeroSpeed * Time.deltaTime);
               
    }








    void OnMouseDown()
    {
      //  flockingAudio.Play();

        //flyingBirdScript.StartFlying();
        flyingBirdRigidBody.AddForce(new Vector3(0, 1, 0), ForceMode.VelocityChange);

        pressed = true;
    }

    void OnMouseUp()
    {
        if (!pressed)
            return;


        pressed = false;

       // flyingBirdRigidBody.velocity = new Vector3(0f, flyingBirdRigidBody.velocity.y * .5f, 0f);
    }
}
