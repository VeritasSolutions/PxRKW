using UnityEngine;
using System.Collections;

public class WaveCurve : MonoBehaviour {

    private IRageSpline rageSpline;

    float initialYPosOfNode;

    void Awake()
    {
        // Store the instance of RageSpline to avoid calling it every frame for speed/convenience.
        // Cast to IRageSpline for cleaner API access
        rageSpline = GetComponent(typeof(RageSpline)) as IRageSpline;
    }

    float[] initialXPos;



    void Start()
    {
        initialXPos = new float[rageSpline.GetPointCount()];

        if (rageSpline.GetPointCount() > 0)
            initialYPosOfNode = rageSpline.GetPosition(0).y;

        for (int i = 0; i < rageSpline.GetPointCount(); i++)
        {
            initialXPos[i] = rageSpline.GetPosition(i).x;


        }

        InvokeRepeating("Animate", 0f, .05f);
        
    }

    float deltaY = .5f;
    float deltaX = 5;

    float xDisplacement;
    float yDisplacement;

    void Animate()
    {
       
        int sign = 1;
        for (int index = 1; index < rageSpline.GetPointCount() - 1; index++)
        {
            
            sign = -sign;

            xDisplacement = Mathf.PingPong(Time.time, deltaX);
            

            yDisplacement = Mathf.PingPong(Time.time, deltaY);


            Vector3 shakeVector = new Vector3(initialXPos[index] + xDisplacement, yDisplacement * sign, 0f);
            rageSpline.SetPoint(index, shakeVector);
        }

        rageSpline.RefreshMesh(true, true, true);

    }
}
