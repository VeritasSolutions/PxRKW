using UnityEngine;
using System.Collections;

public class FlyObject : MonoBehaviour 
{

    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Left Outer" || other.name == "Left Inner")
            Destroy(gameObject);
    }

}
