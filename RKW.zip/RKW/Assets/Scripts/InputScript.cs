using UnityEngine;
using System.Collections;

public class InputScript : MonoBehaviour 
{   

    Kiwi kiwiScript;
    Rigidbody kiwiRigidBody;

    Transform kiwiTransform;

    public AudioSource flockingAudio;

    bool upPressed = false;
    bool downPressed = false;

    Transform centerObject;

    float groundLevel;

    FuelMeter fuelMeter;
    float birdVerticalAcceleration;

    float birdVerticalUPAcceleration ;
    float birdVerticalDownAcceleration;

    float centerPoint;

    Camera mainCamera;

    void Start()
    {
        kiwiScript = GameObject.Find("Kiwi").GetComponent<Kiwi>();
        kiwiTransform = kiwiScript.transform;
        kiwiRigidBody = kiwiTransform.rigidbody;

        birdVerticalAcceleration = GameVariables.rocket1Acceleration * Rocket.agility[Rocket.currentRocketIndex];

        mainCamera = Camera.mainCamera;

        birdVerticalUPAcceleration = birdVerticalAcceleration + (-Physics.gravity.y);
        birdVerticalDownAcceleration = birdVerticalAcceleration - (-Physics.gravity.y);

       // print(birdVerticalUPAcceleration);
      //  print(birdVerticalDownAcceleration);

        groundLevel = GameObject.Find("Ground Level").transform.position.y;
        centerObject = GameObject.Find("Center").transform;

        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
        

        centerPoint = Screen.height / 2f;
        
    }

    void Update()
    {

        foreach (Touch evt in Input.touches)
        {
            if (evt.phase == TouchPhase.Ended)
                OnMouseUp();

            else if (evt.phase == TouchPhase.Began)
                OnMouseDown();
                        
        }

    }
   

    void FixedUpdate()
    {
        if (Game.gameState == Game.GameState.Finish)
            return;

        if (Kiwi.isInsideAirCurrent)
        {            
            return;
        }

        if (fuelMeter.remainingFuel <= 0 || kiwiTransform.position.y < groundLevel || Kiwi.isJetPackOn == false)
        {
            kiwiRigidBody.useGravity = true;
        }        

        if (upPressed)
        {
            ScreenUpTouching();            
        }
        else if (downPressed)
        {
            ScreenDownTouching();
        }
        else
        {
            ScreenNotTouching();
        }
    }

    private void ScreenUpTouching()
    {
        if ((mainCamera.WorldToScreenPoint(kiwiTransform.transform.position).y + 25f > clickedHeight))
        {
            OnMouseUp();
            return;
        }


        if (fuelMeter.remainingFuel <= 0 || Kiwi.isJetPackOn == false)
        {
            if (Kiwi.isRolling == false)
            {
                if (BirdStateScript.birdState == BirdStateScript.BirdState.None)
                {
                    kiwiRigidBody.AddForce(new Vector3(0, birdVerticalUPAcceleration * .5f, 0), ForceMode.Force);
                }
                else if (BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingDown)
                    kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), .08f); //.08
            }
        }
        else
            kiwiRigidBody.AddForce(new Vector3(0, birdVerticalUPAcceleration, 0), ForceMode.Acceleration);
    }

    private void ScreenDownTouching()
    {
        if ((mainCamera.WorldToScreenPoint(kiwiTransform.transform.position).y - 25f < clickedHeight))
        {
            OnMouseUp();
            return;
        }

        kiwiRigidBody.AddForce(new Vector3(0, -birdVerticalDownAcceleration, 0), ForceMode.Acceleration);

    }

    private void ScreenNotTouching()
    {

        if (fuelMeter.remainingFuel <= 0 || Kiwi.isJetPackOn == false)
        {
            if (BirdStateScript.birdState == BirdStateScript.BirdState.None)
                kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), .1f);

            else if (BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyGoingUp || BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingUp)
            {
                // kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), 0f);
            }

            else if (BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingDown)
            {
                kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), .05f);
            }

        }
        else
        {
            if (BirdStateScript.birdState == BirdStateScript.BirdState.None)
                kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), .25f);

            else if (BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyGoingUp || BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingUp)
            {

            }

            else if (BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingDown)
            {
                kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), .05f);
            }

        }
    }

    Vector3 targetPos;

    float clickedHeight;
    

    void OnMouseDown()
    {
        if (Game.gameState != Game.GameState.Playing)
        {
            upPressed = false;
            downPressed = false;
            return;
        }

        if (BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyNotGoingUp)
            BirdStateScript.birdState = BirdStateScript.BirdState.None;
       

        if (Kiwi.isInsideAirCurrent || BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyGoingUp || BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingUp)
            return;
        
      
        Vector3 tempPos = Camera.mainCamera.ScreenToWorldPoint(Input.mousePosition);

        clickedHeight = tempPos.y;

        clickedHeight = Input.mousePosition.y;

        if (clickedHeight > Camera.mainCamera.WorldToScreenPoint(kiwiTransform.transform.position).y)
        {            
          //  print("UP Clicked");
            kiwiRigidBody.useGravity = true;
            downPressed = false;
            upPressed = true;

            kiwiRigidBody.AddForce(new Vector3(0, .5f, 0), ForceMode.Impulse);
        }
        else
        {
        //  print("Down Clicked");
          kiwiRigidBody.useGravity = true;
          upPressed = false;
          downPressed = true;

          kiwiRigidBody.AddForce(new Vector3(0, -.5f, 0), ForceMode.Impulse);
        }
        
    }

    void OnMouseUp()
    {
        if (Game.gameState != Game.GameState.Playing)
            return;

       
        upPressed = false;
        downPressed = false;

        if (fuelMeter.remainingFuel <= 0 || Kiwi.isJetPackOn == false)
        {            
            return;
        }

        if (BirdStateScript.birdState == BirdStateScript.BirdState.BelowSkyGoingUp || BirdStateScript.birdState == BirdStateScript.BirdState.AboveSkyGoingUp)
        {            
            return;
        }
        
        kiwiRigidBody.useGravity = false;
    }

    
}
