using UnityEngine;
using System.Collections;

public class EndingKiwiMovement : MonoBehaviour 
{
    float speed = .5f;
    Transform myTransform;
    Rigidbody myRigidBody;

    Transform mainCameraTransform;
    Transform enviromentTransform;

    Vector3 targetCamera = Vector3.zero;
    Vector3 targetEnvironment = Vector3.zero;
    bool isCalled = false;

   
    FuelMeter fuelMeter;

    float kiwiSpeedToStartMoving = 7f;

    float birdInitialXPosition;

   
	
	void Start () 
    {
        birdInitialXPosition = transform.position.x;
        
        
        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();

        myTransform = transform;
        myRigidBody = rigidbody;

        mainCameraTransform = Camera.mainCamera.transform;
        enviromentTransform = GameObject.Find("Environment").transform;
        

      //  this.enabled = false;
        
	
	}

    float  moveTowardsCenterSpeed = 2f;
    float comeBackToInitialSpeed = 1f;
   

    void FixedUpdate()
    {

        if (Game.gameState == Game.GameState.GameOver || Game.gameState == Game.GameState.Finish)
        {           
            return;
        }

        if (Kiwi.isInsideAirCurrent || Kiwi.justCameOutOfAirCurrent)
        {            
            return;
        }

        if (KiwiSpeedController.kiwiCurrentSpeed < kiwiSpeedToStartMoving && fuelMeter.remainingFuel <= 0)
        {
            float xPos = birdInitialXPosition * KiwiSpeedController.kiwiCurrentSpeed / kiwiSpeedToStartMoving;
            Vector3 targetPos = new Vector3(xPos, myTransform.position.y, myTransform.position.z);

            myTransform.position = Vector3.Lerp(myTransform.position, targetPos, moveTowardsCenterSpeed * Time.deltaTime);
        }
        else
        {
            myTransform.position = Vector3.Lerp(myTransform.position, new Vector3(birdInitialXPosition, myTransform.position.y, myTransform.position.z), comeBackToInitialSpeed * Time.deltaTime);
        }


    }

}
