using UnityEngine;
using System.Collections;

public class InputScriptAcceleration : MonoBehaviour 
{
    public Kiwi kiwiScript;
    public Rigidbody kiwiRigidBody;

    Transform kiwiTransform;

    public AudioSource flockingAudio;

    bool upPressed = false;
    bool downPressed = false;

    Transform centerObject;

    float rocketForce = 0;

    float groundLevel;

    FuelMeter fuelMeter;



    public static float rocket1Acceleration = 10f;

    float birdVerticalAcceleration;

    float birdVerticalUPAcceleration;
    float birdVerticalDownAcceleration;

    float centerPoint;

    Camera mainCamera;

    bool USEITWEEN = false;

    void Start()
    {
        birdVerticalAcceleration = rocket1Acceleration * Rocket.agility[Rocket.currentRocketIndex];

        mainCamera = Camera.mainCamera;

        birdVerticalUPAcceleration = birdVerticalAcceleration + (-Physics.gravity.y);
        birdVerticalDownAcceleration = birdVerticalAcceleration - (-Physics.gravity.y);

        // print(birdVerticalUPAcceleration);
        //  print(birdVerticalDownAcceleration);

        groundLevel = GameObject.Find("Ground Level").transform.position.y;
        centerObject = GameObject.Find("Center").transform;

        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
        kiwiTransform = kiwiScript.transform;

        centerPoint = Screen.height / 2f;

    }

    float accelerometerScale = 2f;

    void Update()
    {

        float vertical = Input.acceleration.x * accelerometerScale;

        float thresold = .1f;

            if(vertical > thresold)
                kiwiRigidBody.AddForce(new Vector3(0,birdVerticalAcceleration,0),ForceMode.Acceleration);
            else if(vertical < - thresold)
                kiwiRigidBody.AddForce(new Vector3(0,-birdVerticalAcceleration,0),ForceMode.Acceleration);
            else
                kiwiRigidBody.velocity = Vector3.Lerp(kiwiRigidBody.velocity, new Vector3(kiwiRigidBody.velocity.x, 0, kiwiRigidBody.velocity.z), .25f); //.25

    }
}
