using UnityEngine;
using System.Collections;

public class Kiwi : MonoBehaviour 
{    

    public PackedSprite mySprite;

    public GameUIController gameUIController;

    public GameObject starParticlePrefab;

    public GameObject superCoinParticlesPrefab;

    public GameObject birdParticlePrefab;    
    
    public static bool isMagnetOn = false;    

    public GameObject jetFlame;
    public ParticleEmitter smallParticles;
    public ParticleEmitter bigParticles;
    

    public GameObject boosterEffectImage;

    public GameObject magnet;
    public GameObject magneticCollider;
    public GameObject magneticColliderImage;
    public GameObject shield;


    Transform myTransform;
    Rigidbody myRigidBody;

    internal FuelMeter fuelMeter;

    public static bool isSpeedBoosterOn = false;
    public static bool isShieldOn = false;
    public static bool isInControlOfAirCurrent = false;
    public static bool isInsideAirCurrent = false;
    public static bool isJetPackOn = true;

    public KiwiSpeedController kiwiSpeedController;
    public SmoothRandomPosition smoothRandomPositonScript;
    AirCurrentLevelCollider airCurrentLevelCollider;

    public UIPanel kiwiFadePanel;

    int numberOFStartParticlesOnScreen = 0;

    

    public static bool isRollingWithoutFuel = false;
    public static bool isRolling = false;

    int currentLevelIndex;


    Frame frameScript;
      

    StarParticlesAudioManager starParticlesAudioManager;


    BlockGenerationNew blockGenerationScript;
   

    void Awake()
    {
        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
    }

    float distanceUpdateInterval = .1f;

    void Start()
    {
        airCurrentLevelCollider = GameObject.Find("Air Current Collider").GetComponent<AirCurrentLevelCollider>();
        blockGenerationScript = GameObject.Find("Block Generation").GetComponent<BlockGenerationNew>();

        starParticlesAudioManager = GameObject.Find("Star Particles Audio Sources").GetComponent<StarParticlesAudioManager>();
      //  magneticCollider.active = false;
      //  gameFinishKiwiMovementScript = GetComponent<GameFinishKiwiMovement>();

        frameScript = GameObject.Find("Environment Frame").GetComponent<Frame>();

        if (Game.currentZoneIndex == -1)
        {
            Game.currentZoneIndex = 0;
            Game.currentZonelevelIndex = 0;
        }
        

        isInsideAirCurrent = false;
        isInControlOfAirCurrent = false;
        isSpeedBoosterOn = false;
        isShieldOn = false;
        isJetPackOn = true;
        

        isRolling = false;
        


        myTransform = transform;
        myRigidBody = rigidbody;

        isMagnetOn = false;
        
        magnet.active = false;

        InvokeRepeating("UpdateDistanceTravelled", 0f, distanceUpdateInterval);
        
    }

    internal void StartCheckingJetPackParticles()
    {
        InvokeRepeating("CheckJetPackParticles", 0, .2f);
    }

    void CheckJetPackParticles()
    {
        if (fuelMeter.remainingFuel <= 0)
        {
            smallParticles.emit = false;
            bigParticles.emit = false;
        }
        else if (isJetPackOn)
            smallParticles.emit = true;
    }

    public static bool justCameOutOfAirCurrent = false;

    
    void FixedUpdate()
    {
        if (Game.gameState == Game.GameState.Finish)
        {           
            myTransform.Translate(new Vector3(-1,0,0) * KiwiSpeedController.kiwiCurrentSpeed * Time.deltaTime);
            myRigidBody.velocity = Vector3.Lerp(myRigidBody.velocity, new Vector3(myRigidBody.velocity.x, 0, 0), 8 * Time.deltaTime);
        }
        else
        {
            myTransform.position -= new Vector3(KiwiSpeedController.kiwiCurrentSpeed * Time.deltaTime, 0, 0);
           //  myTransform.Translate(Vector3.left * KiwiSpeedController.kiwiCurrentSpeed * Time.deltaTime);
        }

        if (Kiwi.isInsideAirCurrent)
        {
            return;
        }

        if (justCameOutOfAirCurrent == false)  //prevent kiwi to align horizontal when it comes out of air current
        {
            float angle = myRigidBody.velocity.y * 4;
            
            myTransform.eulerAngles = new Vector3(0, 0, -angle);
        }
    }

    void UpdateDistanceTravelled()
    {        
        //if (LevelStats.levelComplete == true && Game.gameState != Game.GameState.Finish)
        //{
            
        //    if (CameraZoom.isCameraInOriginalState == true)
        //    {
        //        kiwiSpeedController.rigidbody.useGravity = false;

                  
        //          Game.gameState = Game.GameState.Finish;
        //          gameUIController.ShowGameFinishedPopup();
        //          CancelInvoke("UpdateDistanceTravelled");
        //          return;
        //    }
        //}
        if (Game.gameState == Game.GameState.Playing || Game.gameState == Game.GameState.GameOver)
        {
            LevelStats.distanceTravelled += (KiwiSpeedController.kiwiCurrentSpeed * distanceUpdateInterval) * 10;

            //if (LevelStats.distanceTravelled >= Game.distanceToCompleteZone[Game.currentLoadedLevelForStats] && Game.distanceToCompleteZone[Game.currentLoadedLevelForStats] != -1)
            //{
            //    LevelStats.levelComplete = true;
            //}
        }

    }

    void EnableIsRolling()
    {
        isRolling = true;
    }

    void OnTriggerExit(Collider other)
    {
        if (Game.gameState != Game.GameState.Playing)
            return;

        if (other.name == "Ground Region")
        {
            CancelInvoke("EnableIsRolling");
            isRolling = false;
            
        }
    }


    void OnTriggerEnter(Collider other)
    {

        if (Game.gameState != Game.GameState.Playing)
            return;

        GameObject starParticles;

        if (other.name == "Block Center Collider")
        {
            if (blockGenerationScript.emptyBlockGenerated && CameraZoom.isCameraInOriginalState == true)
            {
                kiwiSpeedController.rigidbody.useGravity = false;

                Game.gameState = Game.GameState.Finish;
                gameUIController.ShowGameFinishedPopup();
            }
            else
            {
                blockGenerationScript.GenerateBlock();
            }
        }

        if (other.name == "Ground Region")
        {
            Invoke("EnableIsRolling",.2f);
           
        }

        else if (other.name == "Air Current Collider")
        {
            airCurrentLevelCollider.StartCameraMovementAndZoom();
        }

        else if (other.tag == "Enemy")
        {
            // iTween.ShakePosition(Camera.mainCamera.gameObject, new Vector3(.1f, .1f, 0f), .5f);

            if (Kiwi.isShieldOn)
            {
                // Destroy(other.gameObject);
                return;
            }

            if (Kiwi.isSpeedBoosterOn)
            {
                DeActivateBooster();
            }
            else
                fuelMeter.DecreaseFuel(25);

            Destroy(other.gameObject);

        }

        else if (other.tag == "Coin")
        {

            //  LevelStats.otherScore += GameVariables.scorePerSmallCoinCollected;
            LevelStats.numberOfCoinsCollected++;
            gameUIController.UpdateCoinCount();
            if (numberOFStartParticlesOnScreen < 5)
            {
                Vector3 pos = new Vector3(transform.position.x, transform.position.y, transform.position.z + 1);
                starParticles = (GameObject)Instantiate(starParticlePrefab, pos, Quaternion.identity);
                numberOFStartParticlesOnScreen++;
                starParticlesAudioManager.PlayStarSound(numberOFStartParticlesOnScreen);

                Invoke("DecreaseNumberOFStarParticles", .5f);
                Destroy(starParticles, .45f);
            }
            Destroy(other.gameObject);
        }

        else if (other.tag == "Upper Coin")
        {
            //  LevelStats.otherScore += GameVariables.scorePerSmallCoinCollected;
            LevelStats.numberOfCoinsCollected++;
            gameUIController.UpdateCoinCount();
            if (numberOFStartParticlesOnScreen < 5)
            {
                Vector3 pos = new Vector3(transform.position.x, transform.position.y, transform.position.z + 1);
                starParticles = (GameObject)Instantiate(starParticlePrefab, pos, Quaternion.identity);
                numberOFStartParticlesOnScreen++;
                starParticlesAudioManager.PlayStarSound(numberOFStartParticlesOnScreen);

                Invoke("DecreaseNumberOFStarParticles", .5f);
                Destroy(starParticles, .45f);
            }
            other.gameObject.GetComponent<Coin>().Disable();
        }

        else if (other.tag == "Super Coin")
        {

            //  LevelStats.otherScore += GameVariables.scorePerSuperCoinCollected;
            LevelStats.numberOfCoinsCollected += GameVariables.numberOfCoinsPerSuperCoin;
            gameUIController.UpdateCoinCount();

            starParticles = (GameObject)Instantiate(superCoinParticlesPrefab, transform.position, Quaternion.identity);

            starParticlesAudioManager.PlayStarSound(numberOFStartParticlesOnScreen);

            Destroy(other.gameObject);
        }

        else if (other.tag == "JetPack")
        {
            //  LevelStats.otherScore += GameVariables.scorePerFuelCollected;
            LevelStats.numberOfFuelsCollected++;
            fuelMeter.AddFuel(GameVariables.amountOfFuelInFuelPack);
            Destroy(other.gameObject);
            //ActivateJet();
        }

        else if (other.tag == "Magnet")
        {
            Destroy(other.gameObject);
            ActivateMagnet();
        }

    }

    private void DecreaseNumberOFStarParticles()
    {
        numberOFStartParticlesOnScreen--;
    }

    internal void ActivateSheild()
    {

        if (isMagnetOn)
            CancelInvoke("DeactivateMagnet");

        isShieldOn = true;
        shield.active = true;
        Invoke("DeactivateSheild", GameVariables.boosterSheildDuration);

    }

    void DeactivateSheild()
    {
        shield.active = false;
        isShieldOn = false;
        gameUIController.EnableShieldIcon();

    }

    internal void ActivateMagnet()
    {

        if (isMagnetOn)
            CancelInvoke("DeactivateMagnet");


        if (magneticColliderImage)
            magneticColliderImage.active = true;

        magneticCollider.active = true;
        isMagnetOn = true;
        magnet.active = true;
        Invoke("DeactivateMagnet", GameVariables.boosterMagnetDuration);

    }

    void DeactivateMagnet()
    {
        if (magneticColliderImage)
            magneticColliderImage.active = false;

        magneticCollider.active = false;
        magnet.active = false;
        isMagnetOn = false;
        gameUIController.EnableMagnetIcon();
        
    }

    public void ActivateBooster()
    {
        if (isSpeedBoosterOn)
            return;

        Kiwi.isSpeedBoosterOn = true;
        jetFlame.active = true;
        smallParticles.emit = false;
        bigParticles.emit = true;

        boosterEffectImage.active = true;

      //  smoothRandomPositonScript.enabled = true;

        kiwiSpeedController.ActivateBooster();
        Invoke("DeActivateBooster", GameVariables.boosterSpeedDuration);
    }

    void DeActivateBooster()
    {
        CancelInvoke("DeActivateBooster");

        Kiwi.isSpeedBoosterOn = false;
        jetFlame.active = false;

        smallParticles.emit = true;
        bigParticles.emit = false;

        boosterEffectImage.active = false;
      
        gameUIController.EnableBoosterIcon();

        kiwiSpeedController.DeActivateBooster();
        
    }

    public void StartShutingDownJetPack()
    {
        Invoke("ShutDownJetPack", 3f);
    }

    public void ShutDownJetPack()
    {
        isJetPackOn = false;

        smallParticles.emit = false;
        bigParticles.emit = false;
        
    }

    public void EgniteJetPack()
    {
        CancelInvoke("ShutDownJetPack");

        isJetPackOn = true;

        smallParticles.emit = true;
        bigParticles.emit = false;
    }

    internal void Sprak()
    {
        smallParticles.emit = true;
        Invoke("ShutDownJetPack", .1f);

    }

   
}
