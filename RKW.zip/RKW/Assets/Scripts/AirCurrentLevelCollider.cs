using UnityEngine;
using System.Collections;

public class AirCurrentLevelCollider : MonoBehaviour 
{

    Transform kiwiTransform;
    Rigidbody kiwiRigidBody;
    Camera mainCamera;

    CameraZoom cameraZoomScript;
    BelowSkyCameraZoom belowSkyCameraZoomScript;

    CameraMovementScript cameraMovementScript;
    BirdStateScript birdStateScript;
    InputScript inputScript;
    KiwiSpeedController kiwiSpeedController;

    UpperCoinScriptNew upperCoinScriptNew;

	void Start () 
    {
        upperCoinScriptNew = GameObject.Find("UpperCoins").GetComponent<UpperCoinScriptNew>();
        kiwiTransform = GameObject.Find("Kiwi").transform;
        kiwiRigidBody = kiwiTransform.rigidbody;

        kiwiSpeedController = kiwiTransform.GetComponent<KiwiSpeedController>();

        mainCamera = Camera.mainCamera;
        cameraZoomScript = mainCamera.GetComponent<CameraZoom>();
        belowSkyCameraZoomScript = mainCamera.GetComponent<BelowSkyCameraZoom>();
        cameraMovementScript = mainCamera.GetComponent<CameraMovementScript>();
        birdStateScript = mainCamera.GetComponent<BirdStateScript>();

        inputScript = GameObject.Find("Screen Input").GetComponent<InputScript>();

        GetComponent<BoxCollider>().enabled = false;
	
	}


    internal void StartCameraMovementAndZoom()
    {
        upperCoinScriptNew.UpdatePosition();
        cameraMovementScript.enabled = true;
        cameraZoomScript.enabled = true;
        cameraZoomScript.StartZoomEffect();

        kiwiSpeedController.AddAirCurrentSpeed();

        birdStateScript.StartTrackingBirdPosition();
        
    }

    void OnTriggerExit( Collider other)
    {
        if (other.name == "Kiwi")
            GetComponent<BoxCollider>().enabled = false;
    }
}
