using UnityEngine;
using System.Collections;

public class SmoothFollow : MonoBehaviour
{
    
    Transform target;
    
    float offset = 3.5f;

    Transform myTransform;
    FuelMeter fuelMeter;
    Frame environmentFrame;

    Transform endMaskTransform;

    void Start()
    {
        environmentFrame = GameObject.Find("Environment Frame").GetComponent<Frame>();
        endMaskTransform = GameObject.Find("ZigZag Ending").transform;
        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
       // target = GameObject.Find("Kiwi Camera Pointing Object").transform;
        target = GameObject.Find("Kiwi").transform;
        myTransform = transform;

        gameObject.transform.parent = null;
       // offset = target.position.x;
    }

    void Update()
    {        
        if (!target)
            return;

        myTransform.position = new Vector3(target.position.x - offset, myTransform.position.y, myTransform.position.z);

    }

    float kiwiSpeedToStartMoving = 7f;

    float moveTowardsKiwiSpeed = 3f;

    float comeBackToCenterSpeed = 1f;

    float kiwiFinishSpeed = 7;

    void FixedUpdate()
    {
        if (Game.gameState == Game.GameState.GameOver) //When the environment is stopped
            return;

        if (Game.gameState == Game.GameState.Finish)
        {
            environmentFrame.EnableEndMask();
            if (endMaskTransform.position.x < -5f)
            {
                kiwiFinishSpeed = GameVariables.zonesFrontMountainSpeed[Game.currentZoneIndex] * KiwiSpeedController.kiwiCurrentSpeed;
                endMaskTransform.position += new Vector3(kiwiFinishSpeed * Time.deltaTime, 0, 0);
            }
            else
            {
                Frame.stopEnvironment = true;
            }

            offset -= kiwiFinishSpeed * 1.2f  * Time.deltaTime;
            return;
        }

        if (Kiwi.isInsideAirCurrent)
        {
            offset = Mathf.Lerp(offset, 0 , moveTowardsKiwiSpeed * 1.4f * Time.deltaTime);
            return;
        }
        

        if (KiwiSpeedController.kiwiCurrentSpeed < kiwiSpeedToStartMoving && fuelMeter.remainingFuel <= 0)
        {
            float newOffset = 3.5f * KiwiSpeedController.kiwiCurrentSpeed / kiwiSpeedToStartMoving;

            offset = Mathf.Lerp(offset, newOffset, moveTowardsKiwiSpeed * Time.deltaTime);
        }
        else
        {
            offset = Mathf.Lerp(offset, 3.5f, comeBackToCenterSpeed * Time.deltaTime);
        }
    }
}