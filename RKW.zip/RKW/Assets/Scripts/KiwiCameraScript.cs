using UnityEngine;
using System.Collections;

public class KiwiCameraScript : MonoBehaviour 
{
    Transform kiwiTransform;
    Transform myTransForm;

	
	void Start () 
    {
        kiwiTransform = GameObject.Find("Kiwi").transform;
        myTransForm = transform;
        InvokeRepeating("UpdatePosition", 0, .2f);
	
	}

    private void UpdatePosition()
    {
        myTransForm.position = new Vector3(kiwiTransform.position.x, myTransForm.position.y, myTransForm.position.z);
    }
	
	
}
