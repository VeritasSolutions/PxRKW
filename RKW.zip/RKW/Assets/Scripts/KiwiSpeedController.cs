using UnityEngine;
using System.Collections;

public class KiwiSpeedController : MonoBehaviour 
{
    public static float kiwiCurrentSpeed;

    public static float initialSpeed = 7f;  //7

    public float currentAirCurrentSpeed = 0;
    public float currentBoosterSpeed = 0f;

    public float miscSpeed = 0;

    float maximumBoosterSpeed = 0;

    internal float maximumAirCurrentSpeed = 15;
    internal float maximumAirCurrentSpeedBelowSky = 10;

    public float targetSpeed = 0;

    

    FuelMeter fuelMeter;

    float accelerationSpeed = 6f;
    float decelerationSpeed = .6f;

    float fuelEmptyDecelerationSpeed = .4f;

    float cameraStartMovementKiwiSpeed = 7f;

    public EndingKiwiMovement endKiwiMovementScript;

    GameUIController gameUIController;
    

    	
	void Start () 
    {
        gameUIController = GameObject.Find("GUI Stuff").GetComponent<GameUIController>();
        kiwiCurrentSpeed = 0;
        fuelMeter = GameObject.Find("Fuel Meter").GetComponent<FuelMeter>();
        targetSpeed = initialSpeed;

        maximumBoosterSpeed = GameVariables.additionalSpeedBoosterSpeed;
        
	
	}

   	
	
	void FixedUpdate() 
    {
        if(Game.gameState == Game.GameState.Finish)
            return;

        if (Game.gameState == Game.GameState.GameOver)
        {
            kiwiCurrentSpeed = Mathf.Lerp(kiwiCurrentSpeed, targetSpeed, fuelEmptyDecelerationSpeed * Time.deltaTime);
            return;
        }

        if (Kiwi.isInControlOfAirCurrent) // till kiwi touches top collider while comming down
        {
            targetSpeed = initialSpeed + currentBoosterSpeed + currentAirCurrentSpeed + miscSpeed;

            if (kiwiCurrentSpeed != targetSpeed)
            {
                if (kiwiCurrentSpeed < targetSpeed)
                    kiwiCurrentSpeed = Mathf.Lerp(kiwiCurrentSpeed, targetSpeed, accelerationSpeed * Time.deltaTime);
                else
                    kiwiCurrentSpeed = Mathf.Lerp(kiwiCurrentSpeed, targetSpeed, decelerationSpeed * Time.deltaTime);

            }
            
            return;
        }

        if (fuelMeter.remainingFuel == 0)
        {
            targetSpeed = 0;

            if (kiwiCurrentSpeed > .4f)
            {       
                    kiwiCurrentSpeed = Mathf.Lerp(kiwiCurrentSpeed, targetSpeed, fuelEmptyDecelerationSpeed * Time.deltaTime);
            }
            else
            {
                Game.gameState = Game.GameState.GameOver;
                kiwiCurrentSpeed = 0; 
                gameUIController.ShowGameOverPopup();
                               
            }
        }
        else
        {
            targetSpeed = initialSpeed + currentBoosterSpeed + currentAirCurrentSpeed + miscSpeed;

            if (kiwiCurrentSpeed != targetSpeed)
            {
                if(kiwiCurrentSpeed < targetSpeed)
                    kiwiCurrentSpeed = Mathf.Lerp(kiwiCurrentSpeed, targetSpeed, accelerationSpeed * Time.deltaTime);
                else
                    kiwiCurrentSpeed = Mathf.Lerp(kiwiCurrentSpeed, targetSpeed, decelerationSpeed * Time.deltaTime);

            }
        }
	}

    internal void ActivateBooster()
    {    
        currentBoosterSpeed = maximumBoosterSpeed;
        print(currentBoosterSpeed);
    }

    internal void DeActivateBooster()
    {        
        currentBoosterSpeed = 0;
    }

    internal void QucklyAddAirCurrentSpeed(bool half)
    {
        if (half)
            currentAirCurrentSpeed = maximumAirCurrentSpeed / 2;
        else
            currentAirCurrentSpeed = maximumAirCurrentSpeed;

        kiwiCurrentSpeed = initialSpeed + currentBoosterSpeed + currentAirCurrentSpeed;
    }

    internal void AddAirCurrentSpeedBelowSky()
    {
        CancelInvoke("SubtractAirCurrentSpeed");
        currentAirCurrentSpeed = maximumAirCurrentSpeedBelowSky;
        Invoke("SubtractAirCurrentSpeed", GameVariables.belowSkyAirCurrentDuration);
    }

    internal void AddAirCurrentSpeed()
    {
        CancelInvoke("SubtractAirCurrentSpeed");
        currentAirCurrentSpeed = maximumAirCurrentSpeed;        
    }

    internal void SubtractAirCurrentSpeed()
    {
        currentAirCurrentSpeed = 0;
    }
}
