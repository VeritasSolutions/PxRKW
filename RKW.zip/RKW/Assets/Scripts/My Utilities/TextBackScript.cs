using UnityEngine;
using System.Collections;

public class TextBackScript : MonoBehaviour {

    public GameObject textBackPrefab;

    GameObject textBackObject;
    TextMesh backTextMesh;
    TextMesh frontTextMesh;

    public Color frontColor = Color.yellow;
    public Color backColor = Color.black;

    public float sizeIncrementFactor = 1.05f;

	void Start () 
    {

        frontTextMesh = GetComponent<TextMesh>();
        
        frontTextMesh.renderer.material.color = frontColor;

        //GenerateBackText();
        
	}

    void GenerateBackText()
    {
        textBackObject = (GameObject)Instantiate(textBackPrefab, transform.position, Quaternion.identity);
        textBackObject.transform.parent = transform;

        textBackObject.transform.rotation = transform.rotation;
        textBackObject.transform.position = new Vector3(textBackObject.transform.position.x, textBackObject.transform.position.y, textBackObject.transform.position.z - .01f);

        backTextMesh = textBackObject.GetComponent<TextMesh>();

        backTextMesh.renderer.material.color = backColor;
        backTextMesh.text = frontTextMesh.text;
        backTextMesh.characterSize = frontTextMesh.characterSize * sizeIncrementFactor;

        backTextMesh.alignment = frontTextMesh.alignment;
        backTextMesh.anchor = frontTextMesh.anchor;

        InvokeRepeating("UpdateFigure", 0f, .1f);
    }
	
	
	void UpdateFigure() 
    {
        backTextMesh.text = frontTextMesh.text;
	
	}
}
