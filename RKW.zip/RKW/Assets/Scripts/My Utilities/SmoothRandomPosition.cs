using UnityEngine;
using System.Collections;

public class SmoothRandomPosition : MonoBehaviour
{

    public float speed = 1.0f;
    public Vector3 range = new Vector3(0.2f, 0.5f, 0f);

    private Perlin noise = new Perlin();
    private Vector3 position;

    void Start()
    {
        position = transform.position;
    }

    void Update()
    {
        transform.position = position + Vector3.Scale(SmoothRandom.GetVector3(speed), range);
    }

    
}
