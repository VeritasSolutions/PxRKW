using UnityEngine;
using System.Collections;
using System;
using System.Data;
using System.Data.Odbc; 
public class ExcelReader : MonoBehaviour 
{   

     public class RkwVariable
     {
         public string varName;
         public float value;

         public RkwVariable(string _varName, float _value)
         {
             varName = _varName;
             value = _value;
         }
     }

     public RkwVariable[] variables;

     ArrayList variablesList;
	
	void Awake () 
    {
        variablesList = new ArrayList();

        ReadExcel("c:" + "/rkwvariables.xls");
	}

    void ReadExcel(string filetoread)
    {
        string con = "Driver={Microsoft Excel Driver (*.xls)}; DriverId=790; Dbq=" + filetoread + ";";
        string query = "SELECT * FROM [Gameplay$]";
        OdbcConnection oCon = new OdbcConnection(con);
        OdbcCommand oCmd = new OdbcCommand(query, oCon);
        DataTable excelData = new DataTable("VariableData");
        oCon.Open();
        OdbcDataReader rData = oCmd.ExecuteReader();
        excelData.Load(rData);
        rData.Close();
        oCon.Close();


        print(excelData.Rows.Count);

        if(excelData.Rows.Count > 0)
        {
           // for (int j = 0; j < dtYourData.Columns.Count; j++)
                for (int i = 0; i < excelData.Rows.Count; i++)
                {
                //    Debug.Log(dtYourData.Columns[j].ColumnName + " : " + dtYourData.Rows[i][dtYourData.Columns[0].ColumnName].ToString());
                    // for giggles, lets see the column name then the data for that column! 
                 //  Debug.Log(excelData.Rows[i][0] + " : " + excelData.Rows[i][1]);
                   variablesList.Add(new RkwVariable(excelData.Rows[i][0].ToString(), float.Parse((excelData.Rows[i][1]).ToString())));
                 
                } 
        }

        DisplayVariables();
    
    }

    float GetValue(string varName)
    {
       

        for (int i = 0; i < variablesList.Count; i++)
        {
            if((((RkwVariable)variablesList[i]).varName) == varName)
            {
                return ((RkwVariable)variablesList[i]).value;
            }
        }

        print("Didnot find the variable");

        return -1;

    }

    private void DisplayVariables()
    {
        for (int i = 0; i < variablesList.Count; i++)
        {
          //  print(((RkwVariable)variablesList[i]).varName + " : " + ((RkwVariable)variablesList[i]).value);
        }

        AssignVariables();
    }

    private void AssignVariables()
    {
        AssignEnvironmentVariables();
        AssignBoosterVariables();
    }

    private void AssignBoosterVariables()
    {
        float value = -1;

        value = GetValue("rkw_var_booster_speed_cooldown");
        if (value != -1)
            GameVariables.boosterSpeedDuration = value;

        value = GetValue("rkw_var_booster_magnet_cooldown");
        if (value != -1)
            GameVariables.boosterMagnetDuration = value;

        value = GetValue("rkw_var_booster_shield_cooldown");
        if (value != -1)
            GameVariables.boosterSheildDuration = value;

        value = GetValue("rkw_var_booster_speed");
        if (value != -1)
            GameVariables.additionalSpeedBoosterSpeed = value;

        value = GetValue("rkw_var_booster_magnet_radius");
        if (value != -1)
            GameVariables.boosterMagnetRadius = value;

    }

    private void AssignEnvironmentVariables()
    {
        float value = -1;

        for (int i = 0; i < Game.totalNumberOfZones; i++)
        {
            value = GetValue("rkw_var_env_zone0" + (i + 1).ToString() + "_ground");
            if(value != -1)
                GameVariables.zonesGroundSpeed[i] = value;
        }

        for (int i = 0; i < Game.totalNumberOfZones; i++)
        {
            value = GetValue("rkw_var_env_zone0" + (i + 1).ToString() + "_front_mount");
            if (value != -1)
                GameVariables.zonesFrontMountainSpeed[i] = value;
        }

        for (int i = 0; i < Game.totalNumberOfZones; i++)
        {
            value = GetValue("rkw_var_env_zone0" + (i + 1).ToString() + "_back_mount");
            if (value != -1)
                GameVariables.zonesBackMountainSpeed[i] = value;
        }

        for (int i = 0; i < Game.totalNumberOfZones; i++)
        {
            value = GetValue("rkw_var_env_zone0" + (i + 1).ToString() + "_cloud");
            if (value != -1)
                GameVariables.zonesCloudSpeed[i] = value;
        }

        for (int i = 0; i < Game.totalNumberOfZones; i++)
        {
            value = GetValue("rkw_var_env_zone0" + (i + 1).ToString() + "_atmosphere");
            if (value != -1)
                GameVariables.zonesAtmosphereSpeed[i] = value;
        }
    }
}
