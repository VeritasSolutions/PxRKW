using UnityEngine;
using System.Collections;

public class MyMath : MonoBehaviour {

    public float scrollSpeed = 0.1f;
    Transform myTransform;
    PackedSprite sp;

    void Start()
    {
        myTransform = transform;
        
    }

    void Update()
    {
     //   if (!GameUIController.isPlaying || GameUIController.isGameOver)
     //       return;


        float offset = Time.time * scrollSpeed;

        renderer.material.mainTextureOffset = new Vector2(0,offset);

        

    }
	
	
}
