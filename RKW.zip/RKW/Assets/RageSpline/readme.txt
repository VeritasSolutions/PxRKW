Thank you for purchasing RageSpline!

Best way to start with RageSpline, is to check out the bundled templates:
/RageSpline/Template - Physics Game
/RageSpline/Template - Top-down Game
/RageSpline/Example Game - Uphill RageSpline

When creating your own RageSpline shapes, drag one of the 
bundled prefabs to your scene and use it as a starting point.

Important commands:
Double-click = Add new control point to selected RageSpline-object
Del or backspace = Delete selected control point
N = Switch selected control point to natural/sharp.
SHIFT = Control point multiselect. Keep holding down to move.

Product documentation: 
ragespline.com/docs

Homepage:
ragespline.com

Contact me at the Unity forums (my nickname is "keely") 
or send me an email to juha@juhakiili.com. Any feedback is appreciated!

NOTE!

Change gravity from the project settings to something like -100
if you want more realistic feel for the Physics Game template.

