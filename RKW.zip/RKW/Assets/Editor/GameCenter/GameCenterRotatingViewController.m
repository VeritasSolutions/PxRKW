    //
//  GameCenterRotatingViewController.m
//  Unity-iPhone
//
//  Created by Mike on 11/28/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import "GameCenterRotatingViewController.h"


@implementation GameCenterRotatingViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	 return YES;    
}


- (void)dealloc
{
    [super dealloc];
}


@end
