//
//  GameCenterRotatingViewController.h
//  Unity-iPhone
//
//  Created by Mike on 11/28/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GameCenterRotatingViewController : UIViewController
{

}

@end
