//
//  GameCenterMultiplayer.h
//  GameCenterTest
//
//  Created by Mike on 9/3/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GameKit/GameKit.h>


// Comment out this line to turn off logging
#define DEBUG = 1

#ifdef DEBUG
#define ALog(format, ...) NSLog(@"%@", [NSString stringWithFormat:format, ## __VA_ARGS__]);
#else
#define ALog(format, ...)
#endif


typedef enum {
    PacketTypeVoice			= 0,
    PacketTypeGameKitPacket	= 1
} PacketType;


@interface GameCenterMultiplayer : NSObject <GKMatchmakerViewControllerDelegate, GKMatchDelegate, GKFriendRequestComposeViewControllerDelegate>
{
	GKMatch *_currentMatch;
	
@private
	NSMutableDictionary *_voiceChatChannels;
}
@property (nonatomic, retain) GKMatch *currentMatch;
@property (nonatomic, retain) NSMutableDictionary *voiceChatChannels;


+ (GameCenterMultiplayer*)sharedManager;


- (void)showMatchmakerWithMinPlayers:(int)minPlayers maxPlayers:(int)maxPlayers;

- (void)showMatchmakerWithMinPlayers:(int)minPlayers maxPlayers:(int)maxPlayers
						 playerGroup:(NSUInteger)playerGroup playerAttributes:(uint32_t)playerAttributes;

- (void)showFriendRequestController;

- (NSString*)sendDataToAllPeers:(NSData*)data reliably:(BOOL)reliably;

- (NSString*)sendData:(NSData*)data toPeers:(NSArray*)peerArray reliably:(BOOL)reliably;

- (void)disconnectFromMatch;


// Voice Chat
- (BOOL)isVOIPAllowed;

- (void)enableVoiceChat:(BOOL)isEnabled;

- (void)closeAllOpenVoiceChats;

- (void)addAndStartVoiceChatChannel:(NSString*)channelName;

- (void)startVoiceChat:(BOOL)shouldStart withChannelName:(NSString*)channelName;

- (void)enableMicrophone:(BOOL)shouldEnable forChat:(NSString*)channelName;

- (void)setVolume:(float)volume forChat:(NSString*)channelName;

- (void)setMute:(BOOL)shouldMute playerId:(NSString*)playerId forChat:(NSString*)channelName;

- (void)receiveUpdates:(BOOL)shouldReceiveUpdates forChatWithChannelName:(NSString*)channelName;



// Manual matchmaking methods
- (void)findMatchProgrammaticallyWithMinPlayers:(int)minPlayers maxPlayers:(int)maxPlayers;

- (void)findMatchProgrammaticallyWithMinPlayers:(int)minPlayers maxPlayers:(int)maxPlayers
									playerGroup:(NSUInteger)playerGroup playerAttributes:(uint32_t)playerAttributes;

- (void)cancelProgrammaticMatchRequest;

- (void)findAllActivity;

@end
