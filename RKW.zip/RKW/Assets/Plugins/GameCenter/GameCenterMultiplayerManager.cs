using UnityEngine;
using System;
using System.Collections.Generic;


// Any methods that Obj-C calls back using UnitySendMessage should be present here
public class GameCenterMultiplayerManager : MonoBehaviour
{
	// Events and delegates
	public delegate void GameCenterMultiplayerErrorEventHandler( string error );
	public delegate void GameCenterMultiplayerSimpleEventHandler( string data );
	public delegate void GameCenterMultiplayerIntEventHandler( int count );
	public delegate void GameCenterMultiplayerEventHandler();
	
	// Fired when the matchmaker is cancelled by the user
	public static event GameCenterMultiplayerEventHandler matchmakerCancelled;
	
	// Fired when the matchmaker finds a match
	public static event GameCenterMultiplayerIntEventHandler matchmakerFoundMatch;
	
	// Fired when the friend request controller is dismissed
	public static event GameCenterMultiplayerEventHandler friendRequestControllerFinished;
	
	// Fired when a player connects to a match
	public static event GameCenterMultiplayerSimpleEventHandler playerConnected;
	
	// Fired when a player disconnects to a match
	public static event GameCenterMultiplayerSimpleEventHandler playerDisconnected;
	
	// Fired when connected to a player fails
	public static event GameCenterMultiplayerErrorEventHandler playerConnectionFailed;
	
	
	// Fired when a player is speaking if receiveUpdates is true for the channel
	public static event GameCenterMultiplayerSimpleEventHandler playerBeganSpeaking;
	
	// Fired when a player goes silent if receiveUpdates is true for the channel
	public static event GameCenterMultiplayerSimpleEventHandler playerStoppedSpeaking;
	
	
	// Fired when a programmatic match fails to connect
	public static event GameCenterMultiplayerErrorEventHandler findMatchFailed;
	
	// Fired when a programmatic find match connects
	public static event GameCenterMultiplayerIntEventHandler findMatchFinished;
	
	// Fired when adding players to a current match fails
	public static event GameCenterMultiplayerErrorEventHandler addPlayersToMatchFailed;
	
	// Fired when finding current activity for your game fails
	public static event GameCenterMultiplayerErrorEventHandler findActivityFailed;

	// Fired when finding activity returns successfully
	public static event GameCenterMultiplayerIntEventHandler findActivityFinished;

	// Fired when finding current activity for a group fails
	public static event GameCenterMultiplayerErrorEventHandler findActivityForGroupFailed;

	// Fired when finding activity for a group returns successfully
	public static event GameCenterMultiplayerIntEventHandler findActivityForGroupFinished;	
	
	public delegate void ScoresLoadedEventHandler( List<GameCenterScore> scores );
	
	// Fired when retrieving scores fails
	public static event GameCenterMultiplayerErrorEventHandler retrieveMatchesBestScoresFailed;
	
	// Fired when retrieving scores finishes successfully
	public static event ScoresLoadedEventHandler retrieveMathesBestScoresFinished;
	
	
    void Awake()
    {
		// Set the GameObject name to the class name for easy access from Obj-C
		gameObject.name = this.GetType().ToString();
		DontDestroyOnLoad( this );
    }
	
	
	
	#region Standard Matchmaking
	
	public void matchmakerWasCancelled( string empty )
	{
		if( matchmakerCancelled != null )
			matchmakerCancelled();
	}
	
	
	public void matchmakerFoundMatchWithExpectedPlayerCount( string playerCount )
	{
		int expectedPlayerCount = int.Parse( playerCount );
		if( matchmakerFoundMatch != null )
			matchmakerFoundMatch( expectedPlayerCount );
	}
	
	
	public void friendRequestComposeViewControllerDidFinish( string empty )
	{
		if( friendRequestControllerFinished != null )
			friendRequestControllerFinished();
	}

		
	public void playerDidConnectToMatch( string playerId )
	{
		if( playerConnected != null )
			playerConnected( playerId );
	}
	
	
	public void playerDidDisconnectFromMatch( string playerId )
	{
		if( playerDisconnected != null )
			playerDisconnected( playerId );
	}
	
	
	public void connectionWithPlayerFailed( string playerId )
	{
		if( playerConnectionFailed != null )
			playerConnectionFailed( playerId );
	}
	
	#endregion;

	
	#region Voice Chat Events
	
	public void playerIsSpeaking( string playerId )
	{
		if( playerBeganSpeaking != null )
			playerBeganSpeaking( playerId );
	}
	
	
	public void playerIsSilent( string playerId )
	{
		if( playerStoppedSpeaking != null )
			playerStoppedSpeaking( playerId );
	}
	
	#endregion;
	
	
	#region Programmatic Matchmaking Events
	
	public void findMatchProgramaticallyFailed( string error )
	{
		if( findMatchFailed != null )
			findMatchFailed( error );
	}
	
	
	public void findMatchProgramaticallyFinishedWithExpectedPlayerCount( string playerCount )
	{
		int expectedPlayerCount = int.Parse( playerCount );
		if( findMatchFinished != null )
			findMatchFinished( expectedPlayerCount );
	}
	
	
	public void addPlayersToCurrentMatchFailed( string error )
	{
		if( addPlayersToMatchFailed != null )
			addPlayersToMatchFailed( error );
	}
	
	
	public void findAllActivityFailed( string error )
	{
		if( findActivityFailed != null )
			findActivityFailed( error );
	}
	
	
	public void findAllActivityFinished( string activity )
	{
		int activityCount = int.Parse( activity );
		if( findActivityFinished != null )
			findActivityFinished( activityCount );
	}
	
	
	public void findAllActivityForPlayerGroupFailed( string error )
	{
		if( findActivityForGroupFailed != null )
			findActivityForGroupFailed( error );
	}
	
	
	public void findAllActivityForPlayerGroupFinished( string activity )
	{
		int activityCount = int.Parse( activity );
		if( findActivityForGroupFinished != null )
			findActivityForGroupFinished( activityCount );
	}
	
	
	public void retrieveMatchesBestScoresDidFail( string error )
	{
		if( retrieveMatchesBestScoresFailed != null )
			retrieveMatchesBestScoresFailed( error );
	}
	
	
	public void retrieveMatchesBestScoresDidFinish( string jsonScores )
	{
		List<GameCenterScore> scores = GameCenterScore.fromJSON( jsonScores );
		
		if( retrieveMathesBestScoresFinished != null )
			retrieveMathesBestScoresFinished( scores );
	}
	
	#endregion;
	
}
