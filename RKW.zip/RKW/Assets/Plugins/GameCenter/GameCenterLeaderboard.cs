using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class GameCenterLeaderboard
{
	public string categoryId;
	public string title;
	
	
	public static List<GameCenterLeaderboard> fromJSON( string json )
	{
		List<GameCenterLeaderboard> leaderboardList = new List<GameCenterLeaderboard>();
		
		// decode the json
		Hashtable ht = (Hashtable)MiniJSON.JsonDecode( json );
		
		// create DTO's from the Hashtable
		foreach( DictionaryEntry de in ht )
			leaderboardList.Add( new GameCenterLeaderboard( de.Value as string, de.Key as string ) );
		
		return leaderboardList;
	}
	
	
	public GameCenterLeaderboard( string categoryId, string title )
	{
		this.categoryId = categoryId;
		this.title = title;
	}
	
	
	public override string ToString()
	{
		 return string.Format( "<Leaderboard> categoryId: {0}, title: {1}", categoryId, title );
	}

}