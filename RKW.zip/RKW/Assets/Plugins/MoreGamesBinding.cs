using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;

public class MoreGamesBinding : MonoBehaviour
{

	
	[DllImport("__Internal")]
	private static extern void _moreGames();
	
	public static void MoreGames()
	{
		if(Application.platform==RuntimePlatform.IPhonePlayer)
			_moreGames();
		
	}

    [DllImport("__Internal")]
    private static extern void _RequestInterstial(); 

    public static void RequestInterstial() 
    {
        if (Application.platform == RuntimePlatform.IPhonePlayer)
            _RequestInterstial();

    }
	
	
		[DllImport("__Internal")]
	private static extern void _Display();
	
	public static void DisplayInterstial()
	{
		if(Application.platform==RuntimePlatform.IPhonePlayer)
			_Display();
		
	}
	
	
	[DllImport("__Internal")]
	private static extern void _scrollerAndPopUp();
	
	public static void ScrollerAndPopUp()
	{
		if(Application.platform==RuntimePlatform.IPhonePlayer)
			_scrollerAndPopUp();
		
	}
	
}
