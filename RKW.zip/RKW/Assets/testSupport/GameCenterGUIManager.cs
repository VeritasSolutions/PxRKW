using UnityEngine;
using System.Collections.Generic;


public class GameCenterGUIManager : MonoBehaviour
{
	// some useful ivars to hold information retrieved from GameCenter.  These will make it easier
	// to test this code with your GameCenter enabled application because they allow the sample
	// to not hardcode any values for leaderboard categoryId's.
	private List<GameCenterLeaderboard> leaderboards;
	private List<GameCenterAchievementMetadata> achievementMetadata;
	
	
	
	void Start()
	{
		// use anonymous delegates for this simple example for gathering data from GameCenter
		GameCenterManager.categoriesLoaded += delegate( List<GameCenterLeaderboard> leaderboards )
		{
			this.leaderboards = leaderboards;
		};
		
		GameCenterManager.achievementMetadataLoaded += delegate( List<GameCenterAchievementMetadata> achievementMetadata )
		{
			this.achievementMetadata = achievementMetadata;
		};
	}
	
	
	void OnGUI()
	{
		float yPos = 5.0f;
		float xPos = 10.0f;
		float width = 180.0f;
		float height = 40.0f;
		float heightPlus = 45.0f;
		
		
		if( GUI.Button( new Rect( xPos, yPos, width, height ), "Authenticate" ) )
		{
			GameCenterBinding.authenticateLocalPlayer();
		}		
		

		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Load Achievement Metadata" ) )
		{
			GameCenterBinding.retrieveAchievementMetadata();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Get Raw Achievements" ) )
		{
			GameCenterBinding.getAchievements();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Post Achievement" ) )
		{
			if( achievementMetadata != null && achievementMetadata.Count > 0 )
			{
				int percentComplete = (int)Random.Range( 2, 60 );
				Debug.Log( "sending percentComplete: " + percentComplete );
				GameCenterBinding.reportAchievement( achievementMetadata[0].identifier, percentComplete );
			}
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Show Achievements" ) )
		{
			GameCenterBinding.showAchievements();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Reset Achievements" ) )
		{
			GameCenterBinding.resetAchievements();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Multiplayer Scene" ) )
		{
			Application.LoadLevel( "GameCenterMultiplayerTestScene" );
		}
	
	
		// Second Column
		yPos = 5.0f;
		xPos = width + xPos * 2;
		
		
		if( GUI.Button( new Rect( xPos, yPos, width, height ), "Get Player Alias" ) )
		{
			string alias = GameCenterBinding.playerAlias();
			Debug.Log( "Player alias: " + alias );
		}
		
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Load Leaderboard Data" ) )
		{
			GameCenterBinding.loadLeaderboardCategoryTitles();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Post Score" ) )
		{
			// We must have a leaderboard to post the score to
			if( leaderboards != null && leaderboards.Count > 0 )
				GameCenterBinding.reportScore( Random.Range( 1, 99999 ), leaderboards[0].categoryId );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Show Leaderboards" ) )
		{
			GameCenterBinding.showLeaderboardWithTimeScope( GameCenterLeaderboardTimeScope.AllTime );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Get Raw Score Data" ) )
		{
			// We must have a leaderboard to retrieve scores from
			if( leaderboards != null && leaderboards.Count > 0 )
				GameCenterBinding.retrieveScores( false, GameCenterLeaderboardTimeScope.AllTime, 1, 25, leaderboards[0].categoryId );
			else
				Debug.Log( "Load leaderboard data before attempting to retrieve scores" );
		}

		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Get Scores for Me" ) )
		{
			// We must have a leaderboard to retrieve scores from
			if( leaderboards != null && leaderboards.Count > 0 )
				GameCenterBinding.retrieveScoresForPlayerId( GameCenterBinding.playerIdentifier(), leaderboards[0].categoryId );
			else
				Debug.Log( "Load leaderboard data before attempting to retrieve scores" );
		}
	
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Retrieve Friends" ) )
		{
			GameCenterBinding.retrieveFriends();
		}


	}


}
