using UnityEngine;
using System.Collections;


public class GameCenterMultiplayerGUIManager : MonoBehaviour
{
	public GUIText statusText;
	
	void Start()
	{
		// Listen to a few events to help update the GUIText
		GameCenterMultiplayerManager.playerConnected += playerConnected;
		GameCenterMultiplayerManager.playerDisconnected += playerDisconnected;
	}
	
	
	void OnDisable()
	{
		GameCenterMultiplayerManager.playerConnected -= playerConnected;
		GameCenterMultiplayerManager.playerDisconnected -= playerDisconnected;
	}
	
	
	#region Event listeners
	
	public void playerConnected( string playerId )
	{
		statusText.text = "player connected: " + playerId;
	}
	
	
	void playerDisconnected( string playerId )
	{
		statusText.text = "player disconnected: " + playerId;
	}
	
	#endregion;
	
	
	void OnGUI()
	{
		float yPos = 5.0f;
		float xPos = 10.0f;
		float width = 220.0f;
		float height = 40.0f;
		float heightPlus = 45.0f;
		
		
		if( GUI.Button( new Rect( xPos, yPos, width, height ), "Authenticate" ) )
		{
			GameCenterBinding.authenticateLocalPlayer();
		}		
		

		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Show Matchmaker" ) )
		{
			GameCenterMultiplayerBinding.showMatchmakerWithMinMaxPlayers( 2, 4 );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Send To All" ) )
		{
			GameCenterMultiplayerBinding.sendMessageToAllPeers( "GCTestObject", "receiveTime", Time.timeSinceLevelLoad.ToString(), false );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Disconnect" ) )
		{
			GameCenterMultiplayerBinding.disconnectFromMatch();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Show Friend Request (iOS 4.2)" ) )
		{
			GameCenterMultiplayerBinding.showFriendRequestController();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus * 2, width, height ), "Advanced Multiplayer" ) )
		{
			GameCenterMultiplayerBinding.disconnectFromMatch();
			Application.LoadLevel( "GameCenterMultiplayerTestSceneTwo" );
		}
	
	
		// Second Column
		yPos = 5.0f;
		xPos = width + xPos * 2;
		
		
		if( GUI.Button( new Rect( xPos, yPos, width, height ), "Find Match (no GUI)" ) )
		{
			GameCenterMultiplayerBinding.findMatchProgrammaticallyWithMinMaxPlayers( 2, 4 );
		}
		
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Cancel Find Match" ) )
		{
			GameCenterMultiplayerBinding.cancelProgrammaticMatchRequest();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Find Activity" ) )
		{
			GameCenterMultiplayerBinding.findAllActivity();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Enable Voicechat" ) )
		{
			GameCenterMultiplayerBinding.enableVoiceChat( true );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Start Voicechat" ) )
		{
			GameCenterMultiplayerBinding.addAndStartVoiceChatChannel( "testChannel" );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Receive VC Updates" ) )
		{
			GameCenterMultiplayerBinding.receiveUpdates( "testChannel", true );
		}

	}

}
