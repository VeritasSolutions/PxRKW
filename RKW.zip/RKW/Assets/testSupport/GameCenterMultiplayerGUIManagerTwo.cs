using UnityEngine;
using System.Collections;


// Advanced player attributes.
public enum PlayerAttributes : uint
{
	Alien = 0xFFFF0000,
	Predator = 0x0000FFFF
}


public class GameCenterMultiplayerGUIManagerTwo : MonoBehaviour
{
	public GUIText statusText;

	
	void Start()
	{
		// Listen to a few events to help update the GUIText
		GameCenterMultiplayerManager.playerConnected += playerConnected;
		GameCenterMultiplayerManager.playerDisconnected += playerDisconnected;
	}
	
	
	void OnDisable()
	{
		GameCenterMultiplayerManager.playerConnected -= playerConnected;
		GameCenterMultiplayerManager.playerDisconnected -= playerDisconnected;
	}
	
	
	#region Event listeners
	
	public void playerConnected( string playerId )
	{
		statusText.text = "player connected: " + playerId;
	}
	
	
	void playerDisconnected( string playerId )
	{
		statusText.text = "player disconnected: " + playerId;
	}
	
	#endregion;
	
	
	void OnGUI()
	{
		float yPos = 5.0f;
		float xPos = 10.0f;
		float width = 180.0f;
		float height = 40.0f;
		float heightPlus = 45.0f;
		
		
		if( GUI.Button( new Rect( xPos, yPos, width, height ), "Authenticate" ) )
		{
			GameCenterBinding.authenticateLocalPlayer();
		}		
		

		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Matchmaker for Game One" ) )
		{
			GameCenterMultiplayerBinding.showMatchmakerWithFilters( 2, 4, 1, 0 );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Matchmaker for Game Two" ) )
		{
			GameCenterMultiplayerBinding.showMatchmakerWithFilters( 2, 4, 2, 0 );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Send To All" ) )
		{
			GameCenterMultiplayerBinding.sendMessageToAllPeers( "GCTestObject", "receiveTime", Time.timeSinceLevelLoad.ToString(), false );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Disconnect" ) )
		{
			GameCenterMultiplayerBinding.disconnectFromMatch();
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Get Connected PlayerIds" ) )
		{
			string[] playersIds = GameCenterMultiplayerBinding.getAllConnectedPlayerIds();
			foreach( string p in playersIds )
				Debug.Log( "connected to: " + p );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Leaderboard Scene" ) )
		{
			GameCenterMultiplayerBinding.disconnectFromMatch();
			Application.LoadLevel( "GameCenterTestScene" );
		}
	
	
		// Second Column
		yPos = 5.0f;
		xPos = width + xPos * 2;
		
		
		if( GUI.Button( new Rect( xPos, yPos, width, height ), "Find Match as Alien" ) )
		{
			GameCenterMultiplayerBinding.findMatchProgrammaticallyWithFilters( 2, 4, 0, (uint)PlayerAttributes.Alien );
		}
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Find Match as Predator" ) )
		{
			GameCenterMultiplayerBinding.findMatchProgrammaticallyWithFilters( 2, 4, 0, (uint)PlayerAttributes.Predator );
		}
		
		
		
		if( GUI.Button( new Rect( xPos, yPos += heightPlus, width, height ), "Cancel Find Match" ) )
		{
			GameCenterMultiplayerBinding.cancelProgrammaticMatchRequest();
		}

	}
}
