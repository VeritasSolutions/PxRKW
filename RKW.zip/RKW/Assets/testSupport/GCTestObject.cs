using UnityEngine;
using System.Collections;


public class GCTestObject : MonoBehaviour
{
	public GUIText statusText;
	
	
    void Awake()
    {
		// Ensure the name of the GameObject matches the class name so we can send messages remotely to a known GO
		gameObject.name = this.GetType().ToString();
    }
	
	
	public void receiveTime( string data )
	{
		statusText.text = data;
	}
}
